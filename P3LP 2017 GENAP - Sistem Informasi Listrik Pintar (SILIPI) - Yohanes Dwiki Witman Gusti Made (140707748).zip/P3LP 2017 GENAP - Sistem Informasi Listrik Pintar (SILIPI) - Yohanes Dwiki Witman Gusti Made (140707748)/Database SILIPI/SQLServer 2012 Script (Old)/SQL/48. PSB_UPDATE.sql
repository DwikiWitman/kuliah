USE [SILIPI]
GO


BEGIN

UPDATE [dbo].[TBL_Permohonan]
   SET 
	   [id_permohonan_tambah_daya] = null
	   ,[id_kode_area] = 13
           ,[identitas_pemohon] = 'KTP-123'
           ,[nama_pemohon] = 'nama'
           ,[tanggal_lahir_pemohon] ='03/07/1995'
           ,[alamat_pemohon] ='alamat xxxx'
           ,[nomor_hp_pemohon]= '08999'
           ,[pekerjaan_pemohon] ='mahasiswa'
           ,[daya_permohonan]= 2200
           ,[jenis_sambungan] ='prabayar'
	   ,[nomor_resi] = 'xx-1234-td'
	   ,[tanggal_permohonan] = current_timestamp
           ,[tanggal_persetujuan] = current_timestamp +10
	   ,[tanggal_penolakan]= null
           ,[deskripsi] = 'telah disetujui'
          
where [id_permohonan] = 10;
 END
GO


