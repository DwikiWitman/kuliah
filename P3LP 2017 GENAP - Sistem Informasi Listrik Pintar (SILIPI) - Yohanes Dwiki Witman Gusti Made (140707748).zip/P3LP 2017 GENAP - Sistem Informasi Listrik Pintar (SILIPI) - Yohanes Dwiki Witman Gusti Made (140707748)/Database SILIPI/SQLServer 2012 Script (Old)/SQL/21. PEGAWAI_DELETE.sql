USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_Pegawai')
DROP PROCEDURE del_Pegawai
GO

CREATE PROC del_Pegawai
	@id_pegawai int	
	,@nama_pegawai varchar(20)
AS
BEGIN

DELETE FROM [dbo].[TBL_Pegawai]
WHERE	
	[id_pegawai] = @id_pegawai
	OR
	[nama_pegawai] = @nama_pegawai
END
GO

EXEC del_Pegawai
	@id_pegawai = '8',
    @nama_pegawai = 'PLa7748';
GO




