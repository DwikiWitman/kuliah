USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_TarifPasangBaru')
DROP PROCEDURE upd_TarifPasangBaru
GO

CREATE PROC upd_TarifPasangBaru
		@cari varchar(20),
		@kategori_tarif varchar(20),
		@beban int
AS
BEGIN

update [dbo].[TBL_TARIF]
set 	[KATEGORI_TARIF] = @kategori_tarif,
	[BEBAN] = @beban
where	[BEBAN] = @cari;
END
GO

EXEC upd_TarifPasangBaru
    	@cari = 2200,
	@kategori_tarif = 'R1',
    	@beban = 2500;
GO