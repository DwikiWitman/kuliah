USE [SILIPI]
GO

SELECT *
  FROM [dbo].[TBL_DetilTransaksi]
GO


