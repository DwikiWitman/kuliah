USE [SILIPI]
BEGIN
DELETE FROM [dbo].[TBL_DetilTransaksi]
      WHERE [id_detil_transaksi] = @id_detil_transaksi
END
GO


