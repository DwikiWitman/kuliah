USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_Pegawai')
DROP PROCEDURE ins_Pegawai
GO

CREATE PROC ins_Pegawai
		@id_jabatan int,
		@nama_pegawai varchar(20),
		@tanggal_lahir_pegawai date,
		@alamat_pegawai varchar(20),
		@nomor_hp_pegawai varchar(20),
		@username_pegawai varchar(20),
		@password_pegawai varchar(20)
AS
BEGIN

INSERT INTO [dbo].[TBL_Pegawai]
           (
		   [ID_JABATAN]
		   ,[nama_pegawai]
           ,[tanggal_lahir_pegawai]
           ,[alamat_pegawai]
           ,[nomor_hp_pegawai]
           ,[USERNAME_PEGAWAI]
		   ,[PASSWORD_PEGAWAI]
           )
     VALUES
           (
		    @id_jabatan
           ,@nama_pegawai
           ,@tanggal_lahir_pegawai
           ,@alamat_pegawai
           ,@nomor_hp_pegawai
           ,@username_pegawai
		   ,@password_pegawai
		   )
END
GO

DECLARE 
@i int,
@ijabatan int,
@tgl date;

SET @i = 0;
SET @ijabatan = (select [ID_JABATAN] from [dbo].[TBL_JABATAN] 
where [NAMA_JABATAN] = 'Petugas Loket');
SET @tgl = CURRENT_TIMESTAMP;

WHILE (@i < 3)
BEGIN
SET @i += 1;
EXEC ins_Pegawai
    @id_jabatan = @ijabatan,
	@nama_pegawai  = 'PLo7748',
    @tanggal_lahir_pegawai = @tgl,
    @alamat_pegawai = 'Jalan Loket',
    @nomor_hp_pegawai = '0877777',
    @username_pegawai = 'Aa1234567!',
	@password_pegawai = 'PLo7748';
END
GO