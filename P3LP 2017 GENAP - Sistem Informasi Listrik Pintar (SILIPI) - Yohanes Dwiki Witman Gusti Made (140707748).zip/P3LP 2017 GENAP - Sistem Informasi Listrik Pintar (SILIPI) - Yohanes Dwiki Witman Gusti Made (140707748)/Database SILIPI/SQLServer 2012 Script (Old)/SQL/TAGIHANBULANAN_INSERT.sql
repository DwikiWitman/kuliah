USE [listrikpintar_7837]
GO

CREATE PROC ins_TagihanBulanan
		@id_tagihanbulanan varchar(50),
		@tanggal_tagihan date,
		@total_tagihan int,
		@kwh_terpakai float,
		@status_pembayaran varchar(50)
AS
BEGIN

INSERT INTO [dbo].[TBL_TagihanBulanan]
           ([id_tagihanbulanan]
           ,[tanggal_tagihan]
           ,[total_tagihan]
           ,[kwh_terpakai]
           ,[status_pembayaran])
     VALUES
           (@id_tagihanbulanan
           ,@tanggal_tagihan
           ,@total_tagihan
           ,@kwh_terpakai
           ,@status_pembayaran)
END
GO


