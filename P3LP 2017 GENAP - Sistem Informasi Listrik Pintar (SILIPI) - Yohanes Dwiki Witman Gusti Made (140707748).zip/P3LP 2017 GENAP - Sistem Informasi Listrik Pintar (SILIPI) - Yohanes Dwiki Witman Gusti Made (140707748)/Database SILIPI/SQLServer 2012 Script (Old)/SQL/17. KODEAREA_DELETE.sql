USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_KodeArea')
DROP PROCEDURE del_KodeArea
GO

CREATE PROCEDURE del_KodeArea
			(
			@id_kode_area int,
			@id_trafo int,
			@id_desa int,
			@id_kecamatan int,
			@lokasi_area varchar(20)			
			)
AS
BEGIN
DELETE FROM [dbo].[TBL_KODEAREA]
      WHERE 
	  [ID_KODE_AREA] = @id_kode_area
	  OR
	  [ID_TRAFO] = @id_trafo
	  OR
	  [ID_DESA] = @id_desa
	  OR
	  [ID_KECAMATAN] = @id_kecamatan
	  OR
	  [LOKASI_AREA] = @lokasi_area
END
GO


EXEC del_KodeArea
     @id_kode_area = '',
	 @id_trafo = '',
	 @id_desa = '',
	 @id_kecamatan = '',
	 @lokasi_area = '';	
GO