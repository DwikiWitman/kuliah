USE [SILIPI]
GO

BEGIN

DELETE FROM [dbo].[TBL_Token]
      WHERE [nomor_token] = @nomor_token
END
GO


