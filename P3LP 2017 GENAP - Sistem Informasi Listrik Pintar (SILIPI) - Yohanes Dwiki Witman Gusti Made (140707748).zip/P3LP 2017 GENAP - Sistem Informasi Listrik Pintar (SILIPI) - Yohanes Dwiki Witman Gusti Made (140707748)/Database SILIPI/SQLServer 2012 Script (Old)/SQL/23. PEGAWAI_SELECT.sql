USE [SILIPI]
GO

SELECT *
  FROM [dbo].[TBL_Pegawai]
GO


