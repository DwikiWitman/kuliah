USE [SILIPI]
GO

DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_Member]
           (
		   [nomor_ktp]
           ,[nomor_member]
	       ,[nomor_kwh]
           ,[nama_member]
           ,[tanggal_lahir_member]
           ,[alamat_instalasi]
           ,[nomor_hp_member]
           ,[pekerjaan]
           ,[daya_listrik]
           ,[tipe_member]
		   )
     VALUES
	   (
		'KTP-123'
		,'M-123'
		,'KWH-12345'
		,'nama'
		, current_timestamp
		,'jalan xxx'
		,'08777'
		,'mahasiswa'
		,2200
		,'prabayar'
	   );
END
GO