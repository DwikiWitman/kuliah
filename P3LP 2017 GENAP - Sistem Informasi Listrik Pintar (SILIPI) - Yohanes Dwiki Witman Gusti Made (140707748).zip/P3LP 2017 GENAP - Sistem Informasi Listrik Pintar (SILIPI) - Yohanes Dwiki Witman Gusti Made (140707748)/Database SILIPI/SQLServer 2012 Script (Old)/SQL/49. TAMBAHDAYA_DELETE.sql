USE [SILIPI]
GO

BEGIN

DELETE FROM [dbo].[TBL_TambahDaya]
      WHERE [id_permohonan_tambah_daya] = 1
END
GO


