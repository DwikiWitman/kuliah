USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_Jabatan')
DROP PROCEDURE ins_Jabatan
GO

CREATE PROCEDURE ins_Jabatan
			(
			@nama_jabatan varchar(20)
			)
AS
BEGIN
INSERT INTO [dbo].[TBL_Jabatan]
          ([nama_jabatan])
     VALUES
          (@nama_jabatan)
END
GO



DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
EXEC ins_Jabatan 
     @nama_jabatan = 'Administrator';
END
GO
