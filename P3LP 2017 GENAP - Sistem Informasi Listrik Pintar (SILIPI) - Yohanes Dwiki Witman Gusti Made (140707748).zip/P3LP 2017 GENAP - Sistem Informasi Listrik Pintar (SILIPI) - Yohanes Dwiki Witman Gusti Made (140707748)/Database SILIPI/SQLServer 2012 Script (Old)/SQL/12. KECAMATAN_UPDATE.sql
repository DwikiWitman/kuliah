USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_Kecamatan')
DROP PROCEDURE upd_Kecamatan
GO

CREATE PROC upd_Kecamatan
		@cari varchar(20),
		@nama_kecamatan varchar(20)
AS
BEGIN

UPDATE 	[dbo].[TBL_Kecamatan]
SET 	[nama_kecamatan] = @nama_kecamatan
WHERE 	
		[id_kecamatan] = @cari
		OR
		[nama_kecamatan] = @cari
END
GO

EXEC upd_Kecamatan
     @cari = '1',
     @nama_kecamatan = 'Pringsewu';
GO