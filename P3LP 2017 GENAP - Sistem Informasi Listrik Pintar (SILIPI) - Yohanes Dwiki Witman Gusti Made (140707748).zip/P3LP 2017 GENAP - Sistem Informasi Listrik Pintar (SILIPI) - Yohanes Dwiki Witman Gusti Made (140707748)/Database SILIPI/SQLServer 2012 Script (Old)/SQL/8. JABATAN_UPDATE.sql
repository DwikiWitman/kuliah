USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_Jabatan')
DROP PROCEDURE upd_Jabatan
GO

CREATE PROC upd_Jabatan
		@cari varchar(20),
		@nama_jabatan varchar(20)
AS
BEGIN

UPDATE 	[dbo].[TBL_Jabatan]
SET 	[nama_jabatan] = @nama_jabatan
WHERE 	
		[id_jabatan] = @cari
		OR
		[nama_jabatan] = @cari
END
GO

EXEC upd_Jabatan
     @cari = '1',
     @nama_jabatan = 'Manager Operasional';
GO