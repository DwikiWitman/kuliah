USE [SILIPI]
GO

BEGIN
UPDATE [dbo].[TBL_DetilTransaksi]
SET 		[jenis_tagihan] = 'prabayar'
		,[channel_pembayaran] = 'loket'
		,[jumlah_token] = '4'
WHERE [id_detil_transaksi] = 1
END
GO


