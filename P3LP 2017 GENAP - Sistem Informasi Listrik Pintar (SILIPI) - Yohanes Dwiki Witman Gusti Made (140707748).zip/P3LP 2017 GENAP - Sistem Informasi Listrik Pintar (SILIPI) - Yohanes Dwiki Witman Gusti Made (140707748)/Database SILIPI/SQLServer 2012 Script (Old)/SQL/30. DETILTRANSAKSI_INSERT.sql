USE [SILIPI]
GO

DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_DetilTransaksi]
       (
         [jenis_tagihan]
		,[channel_pembayaran]
		,[jumlah_token]
	   )
     VALUES
           (
		'pasca'
        ,'bank'
		,3
	   )
END
GO