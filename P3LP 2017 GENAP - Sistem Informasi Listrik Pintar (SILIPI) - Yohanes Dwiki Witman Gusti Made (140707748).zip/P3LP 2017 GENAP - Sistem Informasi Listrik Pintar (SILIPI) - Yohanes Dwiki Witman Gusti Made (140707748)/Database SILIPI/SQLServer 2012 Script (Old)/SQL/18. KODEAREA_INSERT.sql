USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_KodeArea')
DROP PROCEDURE ins_KodeArea
GO

CREATE PROC ins_KodeArea
		@id_trafo int,
		@id_desa int,
		@id_kecamatan int,
		@lokasi_area varchar(20)
AS
BEGIN

INSERT INTO [dbo].[TBL_KodeArea]
       (
		[id_trafo]
		,[id_desa]
		,[id_kecamatan]
        ,[lokasi_area]
	   )
VALUES
       (
		@id_trafo
		,@id_desa
		,@id_kecamatan
       	,@lokasi_area
	   )
END
GO

DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
EXEC ins_KodeArea
    @id_trafo = 1,
	@id_desa = 3,
	@id_kecamatan = 1,
	@lokasi_area = 'Jl. Pringgulung xxx'
END
GO