USE [SILIPI]
GO

SELECT *
  FROM [dbo].[TBL_Member]
GO


