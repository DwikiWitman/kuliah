USE [SILIPI]
GO

BEGIN

UPDATE [dbo].[TBL_Token]
   SET [nomor_token] = @nomor_token
      ,[pulsa_token] = @pulsa_token
      ,[harga_token] = @harga_token
 WHERE [nomor_token] = @nomor_token
END
GO


