USE [SILIPI]
GO

SELECT *
  FROM [dbo].[TBL_Transaksi]
GO


