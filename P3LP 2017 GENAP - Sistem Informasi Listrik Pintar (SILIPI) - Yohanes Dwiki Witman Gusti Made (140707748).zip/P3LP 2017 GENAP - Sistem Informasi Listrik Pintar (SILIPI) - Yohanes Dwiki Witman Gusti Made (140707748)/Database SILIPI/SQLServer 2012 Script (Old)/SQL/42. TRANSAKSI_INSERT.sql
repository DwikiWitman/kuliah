USE [SILIPI]
GO

DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_Transaksi]
    (
	[id_detil_transaksi]
	,[id_tagihan_permohonan]
	,[id_tagihan_pascabayar]
	,[id_token]
	,[id_member]
	,[id_pegawai]
    ,[tanggal_transaksi]
    ,[total_pembayaran]
	)
VALUES
    (
	1
    ,null
	,null
	,1
	,3
	,9
	,CURRENT_TIMESTAMP
	,192.00
	);
END
GO