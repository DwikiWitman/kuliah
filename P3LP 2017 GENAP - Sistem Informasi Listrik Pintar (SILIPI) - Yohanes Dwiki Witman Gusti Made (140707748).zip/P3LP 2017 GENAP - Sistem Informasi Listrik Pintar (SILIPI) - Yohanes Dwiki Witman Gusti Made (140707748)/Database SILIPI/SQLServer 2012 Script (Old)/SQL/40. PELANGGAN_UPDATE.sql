USE [SILIPI]
GO

BEGIN
UPDATE [dbo].[TBL_Member]
SET         [nomor_ktp] = 'KTP-123'
           ,[nomor_member] = 'M-123'
	   ,[nomor_kwh] = 'KWH-12345'
           ,[nama_member] = 'nama'
           ,[tanggal_lahir_member] = current_timestamp
           ,[alamat_instalasi] = 'jalan xxx'
           ,[nomor_hp_member] = '08777'
           ,[pekerjaan] = 'wiraswasta'
           ,[daya_listrik] = 2200
           ,[tipe_member] = 'pascabayar'
where [id_member] = 3;
END
GO