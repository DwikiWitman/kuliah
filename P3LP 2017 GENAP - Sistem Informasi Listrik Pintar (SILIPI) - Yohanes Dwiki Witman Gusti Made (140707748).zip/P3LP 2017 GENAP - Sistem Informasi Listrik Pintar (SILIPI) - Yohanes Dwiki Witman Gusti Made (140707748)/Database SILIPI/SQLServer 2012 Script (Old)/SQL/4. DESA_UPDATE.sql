USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_Desa')
DROP PROCEDURE upd_Desa
GO

CREATE PROCEDURE upd_Desa
			(
			@cari varchar(20),
			@nama_desa varchar(20),
			@rt int,
			@rw int
			)
AS
BEGIN
UPDATE [dbo].[TBL_Desa]
SET    [NAMA_DESA] = @nama_desa
	  ,[RUKUN_TETANGGA] = @rt
	  ,[RUKUN_WARGA] = @rw
WHERE 
	  [id_desa] = @cari
	  OR
	  [NAMA_DESA] = @cari
	  OR
	  (
	  [RUKUN_TETANGGA] = @cari
	  AND
	  [RUKUN_WARGA] = @cari
	  )
END
GO


EXEC upd_Desa
     @cari = '2',
     @nama_desa = 'desa_dua',
	 @rt  = '3',
	 @rw  = '2'
GO