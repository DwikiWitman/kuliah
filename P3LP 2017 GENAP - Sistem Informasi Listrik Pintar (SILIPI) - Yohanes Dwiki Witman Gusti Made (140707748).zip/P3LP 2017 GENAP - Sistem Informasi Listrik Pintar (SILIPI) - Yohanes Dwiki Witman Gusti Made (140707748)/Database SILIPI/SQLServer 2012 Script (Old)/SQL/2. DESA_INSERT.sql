USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_Desa')
DROP PROCEDURE ins_Desa
GO

CREATE PROCEDURE ins_Desa
			(
			@nama_desa varchar(20),
			@rt int,
			@rw int
			)
AS
BEGIN
INSERT INTO [dbo].[TBL_DESA]
           (
		   [NAMA_DESA]
           ,[RUKUN_TETANGGA]
           ,[RUKUN_WARGA]
		   )
     VALUES
           (@nama_desa,
           @rt,
           @rw)
END
GO

DECLARE 
@i int,
@ndesa varchar(20);
SET @i = 0;
SET @ndesa = '';

WHILE (@i < 3)
BEGIN
SET @i += 1;
SET @ndesa = 'desa_' + CONVERT(varchar(3), @i);
EXEC ins_Desa 
     @nama_desa = @ndesa,
	 @rt= @i, 
	 @rw= @i;
/*IF NOT (@i<=3) BREAK;*/
END
GO