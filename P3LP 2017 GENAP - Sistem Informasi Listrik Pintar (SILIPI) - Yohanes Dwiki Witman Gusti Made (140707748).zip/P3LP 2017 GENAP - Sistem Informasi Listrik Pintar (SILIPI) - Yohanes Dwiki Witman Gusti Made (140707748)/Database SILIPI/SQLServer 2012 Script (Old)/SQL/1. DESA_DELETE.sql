USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_Desa')
DROP PROCEDURE del_Desa
GO

CREATE PROCEDURE del_Desa
			(
			@id_desa varchar(20),
			@nama_desa varchar(20),
			@rt int,
			@rw int
			)
AS
BEGIN
DELETE FROM [dbo].[TBL_Desa]
      WHERE 
	  [id_desa] = @id_desa
	  OR
	  [NAMA_DESA] = @nama_desa
	  OR
	  [RUKUN_TETANGGA] = @rt
	  OR
	  [RUKUN_WARGA] = @rw
END
GO


EXEC del_Desa
	 @id_desa = '1',
     @nama_desa = '',
	 @rt= '',
	 @rw= '';
GO
