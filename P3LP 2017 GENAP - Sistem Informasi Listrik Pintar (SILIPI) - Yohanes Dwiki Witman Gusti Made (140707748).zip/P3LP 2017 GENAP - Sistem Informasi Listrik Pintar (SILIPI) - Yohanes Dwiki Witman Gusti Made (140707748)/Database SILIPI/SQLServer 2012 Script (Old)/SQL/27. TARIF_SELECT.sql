USE [listrikpintar_7837]
GO

SELECT [id_tarifpb]
      ,[kategori_tarif]
      ,[Daya]
      ,[ujl_per_va]
      ,[biaya_sambung]
  FROM [dbo].[TBL_TarifPasangBaru]
GO


