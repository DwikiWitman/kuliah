USE [SILIPI]
GO

SELECT [id_jabatan]
      ,[nama_jabatan]
  FROM [dbo].[TBL_Jabatan]
GO


