USE [listrikpintar_7837]
GO

CREATE PROC upd_TagihanBulanan
		@id_tagihanbulanan varchar(50),
		@tanggal_tagihan date,
		@total_tagihan int,
		@kwh_terpakai float,
		@status_pembayaran varchar(50)
AS
BEGIN

UPDATE [dbo].[TBL_TagihanBulanan]
   SET [id_tagihanbulanan] = @id_tagihanbulanan
      ,[tanggal_tagihan] = @tanggal_tagihan
      ,[total_tagihan] = @total_tagihan
      ,[kwh_terpakai] = @kwh_terpakai
      ,[status_pembayaran] = @status_pembayaran
 WHERE [id_tagihanbulanan] = @id_tagihanbulanan
 END
GO


