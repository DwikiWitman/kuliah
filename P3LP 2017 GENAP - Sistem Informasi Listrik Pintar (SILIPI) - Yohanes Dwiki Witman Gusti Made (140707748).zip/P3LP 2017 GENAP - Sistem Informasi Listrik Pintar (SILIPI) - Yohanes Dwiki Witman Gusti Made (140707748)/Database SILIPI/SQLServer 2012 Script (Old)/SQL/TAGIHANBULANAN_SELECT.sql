USE [listrikpintar_7837]
GO

SELECT [id_tagihanbulanan]
      ,[tanggal_tagihan]
      ,[total_tagihan]
      ,[kwh_terpakai]
      ,[status_pembayaran]
  FROM [dbo].[TBL_TagihanBulanan]
GO


