USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_TarifPasangBaru')
DROP PROCEDURE del_TarifPasangBaru
GO

CREATE PROC del_TarifPasangBaru
		@kategori_tarif varchar(20),
		@beban int
AS
BEGIN

DELETE FROM [dbo].[TBL_Tarif]
WHERE 
	[KATEGORI_TARIF] = 'R1' 
	and 
	[BEBAN] = 2200;
END
GO

EXEC del_TarifPasangBaru
    @kategori_tarif = 'R1',
    @beban = 2200;
GO