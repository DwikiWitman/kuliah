USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_Trafo')
DROP PROCEDURE upd_Trafo
GO

CREATE PROC upd_Trafo
		@cari varchar(20),
		@kapasitas_daya_total int,
		@kapasitas_daya_terpakai int
AS
BEGIN

UPDATE 	[dbo].[TBL_Trafo]
SET 	[kapasitas_daya_total] = @kapasitas_daya_total,
	[kapasitas_daya_terpakai] = @kapasitas_daya_terpakai
WHERE 	
	[id_trafo] = @cari
	OR
	[kapasitas_daya_total] = @cari
	OR
	[kapasitas_daya_terpakai] = @cari
END
GO

EXEC upd_Trafo
     @cari = '1',
     @kapasitas_daya_total = 150,
     @kapasitas_daya_terpakai = 150;
GO


