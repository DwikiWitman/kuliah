USE [listrikpintar_7837]
GO

SELECT *
  FROM [dbo].[TBL_Permohonan]
GO


