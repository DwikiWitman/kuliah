USE [SILIPI]
GO

SELECT [id_trafo]
      ,[kapasitas_daya_total]
      ,[kapasitas_daya_terpakai]
  FROM [dbo].[TBL_Trafo]
GO


