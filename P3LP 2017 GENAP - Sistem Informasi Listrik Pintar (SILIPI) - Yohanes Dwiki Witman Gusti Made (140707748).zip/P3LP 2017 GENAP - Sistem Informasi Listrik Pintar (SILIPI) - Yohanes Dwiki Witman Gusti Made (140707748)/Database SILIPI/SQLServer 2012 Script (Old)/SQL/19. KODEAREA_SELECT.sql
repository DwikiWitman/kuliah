USE [SILIPI]
GO

SELECT [id_kode_area]
	,[id_trafo]
	,[id_desa]
	,[id_kecamatan]
      	,[lokasi_area]
  FROM [dbo].[TBL_KodeArea]
GO


