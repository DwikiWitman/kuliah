USE [SILIPI]
GO

BEGIN

DELETE FROM [dbo].[TBL_Member]
      WHERE [id_member] = @id_member
END
GO


