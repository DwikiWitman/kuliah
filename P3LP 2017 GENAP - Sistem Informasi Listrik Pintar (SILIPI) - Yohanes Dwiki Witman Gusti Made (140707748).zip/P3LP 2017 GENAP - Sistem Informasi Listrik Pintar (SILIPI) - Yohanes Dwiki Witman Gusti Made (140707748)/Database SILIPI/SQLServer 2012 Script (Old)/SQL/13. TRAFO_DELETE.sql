USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_Trafo')
DROP PROCEDURE del_Trafo
GO

CREATE PROCEDURE del_Trafo
			(
			@id_trafo int,
			@kapasitas_daya_total int,
			@kapasitas_daya_terpakai int			
			)
AS
BEGIN
DELETE FROM [dbo].[TBL_TRAFO]
      WHERE 
	  [ID_TRAFO] = @id_trafo
	  OR
	  [KAPASITAS_DAYA_TOTAL] = @kapasitas_daya_total
	  OR
	  [KAPASITAS_DAYA_TERPAKAI] = @kapasitas_daya_terpakai
END
GO


EXEC del_Trafo
	 @id_trafo = '',
	 @kapasitas_daya_total = '',
     @kapasitas_daya_terpakai = '';
GO

