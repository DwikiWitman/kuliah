USE [SILIPI]
GO

SELECT [id_kecamatan]
      ,[nama_kecamatan]
  FROM [dbo].[TBL_Kecamatan]
GO


