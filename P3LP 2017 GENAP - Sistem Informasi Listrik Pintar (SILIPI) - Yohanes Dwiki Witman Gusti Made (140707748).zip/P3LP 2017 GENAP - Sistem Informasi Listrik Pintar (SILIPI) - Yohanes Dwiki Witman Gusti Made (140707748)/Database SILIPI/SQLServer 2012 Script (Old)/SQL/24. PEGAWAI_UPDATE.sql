USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_Pegawai')
DROP PROCEDURE upd_Pegawai
GO

CREATE PROC upd_Pegawai
		@cari varchar(20),
		@id_jabatan int,
		@nama_pegawai varchar(20),
		@tanggal_lahir_pegawai date,
		@alamat_pegawai varchar(20),
		@nomor_hp_pegawai varchar(20),
		@username_pegawai varchar(20),
		@password_pegawai varchar(20)
AS
BEGIN

UPDATE [dbo].[TBL_Pegawai]
SET		   [ID_JABATAN] = @id_jabatan
		   ,[nama_pegawai] = @nama_pegawai
           ,[tanggal_lahir_pegawai] = @tanggal_lahir_pegawai
           ,[alamat_pegawai] = @alamat_pegawai
           ,[nomor_hp_pegawai] = @nomor_hp_pegawai
           ,[USERNAME_PEGAWAI] = @username_pegawai
		   ,[PASSWORD_PEGAWAI] = @password_pegawai
           
WHERE [nama_pegawai] = @cari;
END
GO

DECLARE 
@i int,
@ijabatan int,
@tgl date;

SET @i = 0;
SET @ijabatan = (select [ID_JABATAN] from [dbo].[TBL_JABATAN] where [NAMA_JABATAN] = 'Manager Operasional');
SET @tgl = CURRENT_TIMESTAMP;

BEGIN
EXEC upd_Pegawai
	@cari = 'PLo7748',
    @id_jabatan = @ijabatan,
	@nama_pegawai  = 'PLo7748',
    @tanggal_lahir_pegawai = @tgl,
    @alamat_pegawai = 'Jalan Loket',
    @nomor_hp_pegawai = '0877777',
    @username_pegawai = 'Aa1234567!',
	@password_pegawai = 'PLo7748';
END
GO