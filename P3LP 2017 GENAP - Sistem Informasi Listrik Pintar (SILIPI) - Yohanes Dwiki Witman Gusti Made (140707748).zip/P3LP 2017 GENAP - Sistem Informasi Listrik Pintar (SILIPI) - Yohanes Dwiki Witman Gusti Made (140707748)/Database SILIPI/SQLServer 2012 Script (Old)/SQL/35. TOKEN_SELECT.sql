USE [SILIPI]
GO

SELECT *
  FROM [dbo].[TBL_Token]
GO


