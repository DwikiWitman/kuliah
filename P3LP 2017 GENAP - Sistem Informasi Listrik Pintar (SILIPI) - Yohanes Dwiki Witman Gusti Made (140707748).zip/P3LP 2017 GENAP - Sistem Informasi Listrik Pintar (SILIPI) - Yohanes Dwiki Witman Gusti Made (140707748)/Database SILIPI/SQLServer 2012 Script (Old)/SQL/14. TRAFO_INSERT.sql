USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_Trafo')
DROP PROCEDURE ins_Trafo
GO

CREATE PROCEDURE ins_Trafo
			(
			@kapasitas_daya_total int,
			@kapasitas_daya_terpakai int			
			)
AS
BEGIN
INSERT INTO [dbo].[TBL_TRAFO]
          (
			[KAPASITAS_DAYA_TOTAL]
			,[KAPASITAS_DAYA_TERPAKAI]
		  )
     VALUES
          (
			@kapasitas_daya_total,
			@kapasitas_daya_terpakai
		  )
END
GO



DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
EXEC ins_Trafo
	 @kapasitas_daya_total = 500,
     @kapasitas_daya_terpakai = 500;
END
GO