USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_Jabatan')
DROP PROCEDURE del_Jabatan
GO

CREATE PROCEDURE del_Jabatan
			(
			@id_jabatan int,
			@nama_jabatan varchar(20)			
			)
AS
BEGIN
DELETE FROM [dbo].[TBL_JABATAN]
      WHERE 
	  [ID_JABATAN] = @id_jabatan
	  OR
	  [NAMA_JABATAN] = @nama_jabatan
END
GO


EXEC del_Jabatan
	 @id_jabatan = '1',
     @nama_jabatan = '';
GO
