USE [SILIPI]
GO

BEGIN
DELETE FROM [dbo].[TBL_Transaksi]
      WHERE [id_transaksi] = @id_transaksi
END
GO


