USE [SILIPI]
GO
/*
CREATE PROC ins_TarifPasangBaru
		@kategori_tarif int,
		@beban int,
		@biaya_UJL int,
		@biaya_sambung int
AS
BEGIN

INSERT INTO [dbo].[TBL_TARIF]
           (
            [kategori_tarif]
           ,[beban]
           ,[biaya_ujl]
           ,[biaya_sambung]
		   ,[is_tarif_psb]
		   )
     VALUES
           (
            @kategori_tarif
           ,@beban
           ,@biaya_ujl
           ,@biaya_sambung
		   ,1
		   )
END
GO

EXEC ins_TarifPasangBaru
    @kategori_tarif = 1,
    @beban = 1,
	@biaya_UJL = 1,
	@biaya_sambung = 1;
END
*/


BEGIN
insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R1',1300,101,300);

insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R2',2200,101,300);

insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R2',3500,113,350);

insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R2',4400,113,350);

insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R2',6600,113,350);

insert into [dbo].[TBL_TARIF] ([KATEGORI_TARIF],[BEBAN],[BIAYA_UJL],[BIAYA_SAMBUNG])
values ('R3',10000,250,800);
END
GO