USE [SILIPI]
GO

BEGIN

UPDATE [dbo].[TBL_TambahDaya]
SET [nomor_member] = 'M-123'
	,[daya_listrik_baru] =2500
     
WHERE [id_permohonan_tambah_daya] = 1;
END
GO




