USE [SILIPI]
GO

DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_Permohonan]
           (
	   [id_permohonan_tambah_daya]
	   ,[id_kode_area]
           ,[identitas_pemohon]
           ,[nama_pemohon]
           ,[tanggal_lahir_pemohon]
           ,[alamat_pemohon]
           ,[nomor_hp_pemohon]
           ,[pekerjaan_pemohon]
           ,[daya_permohonan]
           ,[jenis_sambungan]
	   ,[nomor_resi]
	   ,[tanggal_permohonan]
           ,[tanggal_persetujuan]
	   ,[tanggal_penolakan]
           ,[deskripsi]
           )
     VALUES
           (
		null
		,13
		,'KTP-123'
		,'nama'
		,'03/07/1995'
		,'alamat xxxx'
		,'08999'
		,'mahasiswa'
		,2200
		,'prabayar'
		,null
		,current_timestamp
		,null
		,null
		,'belum diverifikasi'	
	   )
END
GO
