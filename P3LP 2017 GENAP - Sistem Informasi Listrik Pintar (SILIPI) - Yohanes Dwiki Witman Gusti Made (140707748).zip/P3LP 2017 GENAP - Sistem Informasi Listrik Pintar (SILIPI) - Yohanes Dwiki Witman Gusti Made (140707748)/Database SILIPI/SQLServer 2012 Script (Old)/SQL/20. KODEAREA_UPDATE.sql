USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'upd_KodeArea')
DROP PROCEDURE upd_KodeArea
GO

CREATE PROC upd_KodeArea
		@cari varchar(20),
		@id_trafo int,
		@id_desa int,
		@id_kecamatan int,
		@lokasi_area varchar(20)
AS
BEGIN

UPDATE 	[dbo].[TBL_KodeArea]
SET	[id_trafo] = @id_trafo,
	[id_desa] = @id_desa,
	[id_kecamatan] = @id_kecamatan,
	[lokasi_area] = @lokasi_area
WHERE 	[id_kode_area] = @cari
	OR
	[id_trafo] = @cari
	OR
	[id_desa] = @cari
	OR
	[id_kecamatan] = @cari
	OR
	[lokasi_area] = @cari
END
GO

EXEC upd_KodeArea
	@cari = 1,
    @id_trafo = 2,
	@id_desa = 3,
	@id_kecamatan = 3,
	@lokasi_area = 'Jl. Pringgulung xxx'
GO