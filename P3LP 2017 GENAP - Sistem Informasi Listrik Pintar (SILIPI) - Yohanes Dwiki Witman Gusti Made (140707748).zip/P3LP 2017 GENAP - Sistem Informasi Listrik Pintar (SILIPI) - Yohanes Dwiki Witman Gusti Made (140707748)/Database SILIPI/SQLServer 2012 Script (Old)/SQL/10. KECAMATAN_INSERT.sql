USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'ins_Kecamatan')
DROP PROCEDURE ins_Kecamatan
GO

CREATE PROCEDURE ins_Kecamatan
			(
			@nama_kecamatan varchar(20)
			)
AS
BEGIN
INSERT INTO [dbo].[TBL_KECAMATAN]
          ([nama_kecamatan])
     VALUES
          (@nama_kecamatan)
END
GO



DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
EXEC ins_Kecamatan 
     @nama_kecamatan = 'Pringgolan';
END
GO
