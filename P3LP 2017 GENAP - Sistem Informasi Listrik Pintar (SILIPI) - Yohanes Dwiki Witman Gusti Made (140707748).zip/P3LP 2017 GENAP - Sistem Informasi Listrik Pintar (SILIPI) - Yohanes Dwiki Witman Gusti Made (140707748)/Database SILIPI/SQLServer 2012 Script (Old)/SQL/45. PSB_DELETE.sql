USE [SILIPI]
GO


BEGIN

DELETE FROM [dbo].[TBL_Permohonan]
      WHERE [id_permohonan] = 1
END
GO


