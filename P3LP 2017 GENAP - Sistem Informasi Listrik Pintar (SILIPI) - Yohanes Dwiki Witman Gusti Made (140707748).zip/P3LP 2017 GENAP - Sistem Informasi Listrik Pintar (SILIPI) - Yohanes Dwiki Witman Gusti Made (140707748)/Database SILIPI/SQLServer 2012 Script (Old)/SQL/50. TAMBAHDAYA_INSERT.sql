USE [SILIPI]
GO
GO
DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_TambahDaya]
           (
           [nomor_member]
	   ,[daya_listrik_baru])
     VALUES
           ('M-123',2500)
END
GO


