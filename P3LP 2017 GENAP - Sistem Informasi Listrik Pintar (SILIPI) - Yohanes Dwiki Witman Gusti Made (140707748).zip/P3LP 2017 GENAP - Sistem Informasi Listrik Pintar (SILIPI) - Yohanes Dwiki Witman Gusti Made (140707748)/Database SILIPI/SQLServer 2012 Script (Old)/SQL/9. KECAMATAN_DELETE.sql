USE [SILIPI]
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'del_Kecamatan')
DROP PROCEDURE del_Kecamatan
GO

CREATE PROCEDURE del_Kecamatan
			(
			@id_kecamatan int,
			@nama_kecamatan varchar(20)			
			)
AS
BEGIN
DELETE FROM [dbo].[TBL_KECAMATAN]
      WHERE 
	  [ID_KECAMATAN] = @id_kecamatan
	  OR
	  [NAMA_KECAMATAN] = @nama_kecamatan
END
GO


EXEC del_Kecamatan
     @id_kecamatan = '1',
     @nama_kecamatan = '';
GO