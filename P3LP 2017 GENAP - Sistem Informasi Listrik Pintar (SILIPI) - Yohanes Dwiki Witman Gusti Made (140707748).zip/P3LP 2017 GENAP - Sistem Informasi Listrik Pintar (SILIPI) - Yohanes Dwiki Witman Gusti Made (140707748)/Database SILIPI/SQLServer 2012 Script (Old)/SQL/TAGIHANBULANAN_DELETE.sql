USE [listrikpintar_7837]
GO

CREATE PROC del_TagihanBulanan
		@id_tagihanbulanan varchar(50)
AS
BEGIN

DELETE FROM [dbo].[TBL_TagihanBulanan]
      WHERE [id_tagihanbulanan] = @id_tagihanbulanan
END
GO


