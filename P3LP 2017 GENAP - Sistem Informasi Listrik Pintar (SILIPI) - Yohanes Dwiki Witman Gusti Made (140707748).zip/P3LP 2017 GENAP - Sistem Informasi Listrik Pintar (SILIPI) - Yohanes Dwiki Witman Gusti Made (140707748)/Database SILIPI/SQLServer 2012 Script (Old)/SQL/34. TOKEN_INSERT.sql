USE [SILIPI]
GO
DECLARE 
@i int;
SET @i = 0;

WHILE (@i < 3)
BEGIN
SET @i += 1;
INSERT INTO [dbo].[TBL_Token]
           ([nomor_token]
           ,[pulsa_token]
           ,[harga_token])
     VALUES
           (@nomor_token
           ,@pulsa_token
           ,@harga_token)
END
GO


