USE [SILIPI]
GO

BEGIN
UPDATE [dbo].[TBL_Transaksi]
SET	 [id_detil_transaksi] = 1
	,[id_tagihan_permohonan] = null
	,[id_tagihan_pascabayar] = null
	,[id_token] = 1
	,[id_member] = 3
	,[id_pegawai] = 9
    	,[tanggal_transaksi] = CURRENT_TIMESTAMP
    	,[total_pembayaran] = 180000.00
 WHERE [id_transaksi] = 10 
END
GO


