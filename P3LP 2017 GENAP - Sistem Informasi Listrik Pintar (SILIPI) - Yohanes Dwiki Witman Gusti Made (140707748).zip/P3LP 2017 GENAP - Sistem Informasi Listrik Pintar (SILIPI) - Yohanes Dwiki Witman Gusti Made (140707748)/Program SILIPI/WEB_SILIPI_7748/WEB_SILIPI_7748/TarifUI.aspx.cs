﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WEB_SILIPI_7748.CONTROL;

namespace WEB_SILIPI_7748
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        TarifControl tarifControl = new TarifControl();
        DataTable data_tarif;

        protected void Page_Load(object sender, EventArgs e)
        {
            data_tarif = tarifControl.getDataTarif();
        }

        protected void btnTarifPSB_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            DataTable data_tarifPSB = data_tarif;

            foreach (DataControlField col in GridView1.Columns)
            {
                if
                (
                    col.HeaderText == "ID_TARIF" ||
                    col.HeaderText == "IS_TARIF_PASCABAYAR" ||
                    col.HeaderText == "BIAYA_BEBAN" ||
                    col.HeaderText == "BIAYA_PEMAKAIAN"
                )
                {
                    col.Visible = false;
                }
                else
                    col.Visible = true;
            }
        }

        protected void btnTarifPascabayar_Click(object sender, EventArgs e)
        {
            GridView1.Visible = true;
            DataTable data_tarifPascabayar = data_tarif;

            foreach (DataControlField col in GridView1.Columns)
            {
                if
                (
                    col.HeaderText == "ID_TARIF" ||
                    col.HeaderText == "BIAYA_UJL" ||
                    col.HeaderText == "BIAYA_SAMBUNG" ||
                    col.HeaderText == "IS_TARIF_PSB"
                )
                {
                    col.Visible = false;
                }
                else
                    col.Visible = true;
            }

        }

        protected void linkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomeUI.aspx");
        }
    }
}