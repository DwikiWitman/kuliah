﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WEB_SILIPI_7748.DataSetTableAdapters;

namespace WEB_SILIPI_7748.CONTROL
{
    public class TarifControl
    {
        TBL_TARIFTableAdapter table_tarif = new TBL_TARIFTableAdapter();

        public DataTable getDataTarif()
        {
            return table_tarif.GetData();
        }

        public DataTable getDataTarifPSB()
        {
            return table_tarif.GetDataTarifPSB();
        }

        public DataTable getDataTarifPascabayar()
        {
            return table_tarif.GetDataTarifPascabayar();
        }
    }
}