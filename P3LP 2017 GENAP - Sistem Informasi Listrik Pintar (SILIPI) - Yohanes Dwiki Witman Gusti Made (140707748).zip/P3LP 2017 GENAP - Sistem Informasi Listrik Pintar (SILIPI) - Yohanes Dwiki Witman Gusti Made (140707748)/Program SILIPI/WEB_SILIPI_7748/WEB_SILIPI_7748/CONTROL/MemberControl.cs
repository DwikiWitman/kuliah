﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using WEB_SILIPI_7748.DataSetTableAdapters;

namespace WEB_SILIPI_7748.CONTROL
{
    public class MemberControl
    {
        TBL_MEMBERTableAdapter table_member = new TBL_MEMBERTableAdapter();

        public DataTable getDataMember()
        {
            return table_member.GetData();
        }
        public int getDataIDMemberByNomorMember(string nomor_member)
        {
            return table_member.GetIDMemberByNomorMember(nomor_member).Value;
        }

    }
}