﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WEB_SILIPI_7748.CONTROL;

namespace WEB_SILIPI_7748
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void cmbBulan_SelectedIndexChanged(object sender, EventArgs e)
        {
            MemberControl memberControl = new MemberControl();
            int id_member = memberControl.getDataIDMemberByNomorMember(txtCari.Text);
            string bulan = cmbBulan.Text;

            ObjectDataSource1.SelectParameters["BULAN_TAGIHAN"].DefaultValue = bulan;
            ObjectDataSource1.SelectParameters["ID_MEMBER"].DefaultValue = id_member.ToString();
            ObjectDataSource1.DataBind();

        }

        protected void txtCari_TextChanged(object sender, EventArgs e)
        {
            MemberControl memberControl = new MemberControl();
            int id_member = memberControl.getDataIDMemberByNomorMember(txtCari.Text);
            string bulan = cmbBulan.Text;

            ObjectDataSource1.SelectParameters["BULAN_TAGIHAN"].DefaultValue = bulan;
            ObjectDataSource1.SelectParameters["ID_MEMBER"].DefaultValue = id_member.ToString();
            ObjectDataSource1.DataBind();
        }

        protected void btnCek_Click(object sender, EventArgs e)
        {
            MemberControl memberControl = new MemberControl();
            int id_member = memberControl.getDataIDMemberByNomorMember(txtCari.Text);
            string bulan = cmbBulan.Text;

            if (id_member.ToString() =="")
            {
                this.lblHasil.Text = "Tidak ada tagihan.";
            }
            else
                this.lblHasil.Text = "";
            
            ObjectDataSource1.SelectParameters["BULAN_TAGIHAN"].DefaultValue = bulan;
            ObjectDataSource1.SelectParameters["ID_MEMBER"].DefaultValue = id_member.ToString();
            ObjectDataSource1.DataBind();

        }
    }
}