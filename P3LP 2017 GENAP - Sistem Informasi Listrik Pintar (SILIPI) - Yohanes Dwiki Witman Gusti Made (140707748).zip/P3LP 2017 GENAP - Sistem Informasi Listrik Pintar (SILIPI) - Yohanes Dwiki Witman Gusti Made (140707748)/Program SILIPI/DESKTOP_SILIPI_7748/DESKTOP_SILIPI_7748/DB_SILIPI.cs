﻿namespace DESKTOP_SILIPI_7748 {
    
    
    public partial class DB_SILIPI {
        partial class TBL_PERMOHONANDataTable
        {
        }
    
        partial class TBL_MEMBERDataTable
        {
        }
    }
}


namespace DESKTOP_SILIPI_7748.DB_SILIPITableAdapters {
    
    
    public partial class TBL_TARIFTableAdapter {
    }
}
