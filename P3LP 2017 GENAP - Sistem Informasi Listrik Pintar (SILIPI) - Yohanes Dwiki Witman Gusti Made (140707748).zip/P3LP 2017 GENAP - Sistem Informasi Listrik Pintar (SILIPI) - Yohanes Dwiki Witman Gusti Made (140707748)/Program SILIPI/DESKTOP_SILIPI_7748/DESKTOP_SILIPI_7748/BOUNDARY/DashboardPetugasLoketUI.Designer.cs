﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class DashboardPetugasLoketUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanelWord_Top = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanelWord_Utama = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelWord_Middle = new System.Windows.Forms.TableLayoutPanel();
            this.buttonPengubahanStatusPemasangan = new System.Windows.Forms.Button();
            this.buttonPembelianToken = new System.Windows.Forms.Button();
            this.buttonPembayaranTagihanPascabayar = new System.Windows.Forms.Button();
            this.buttonPencatatanTagihanPascabayar = new System.Windows.Forms.Button();
            this.buttonCetakMember = new System.Windows.Forms.Button();
            this.buttonCetakKartuMember = new System.Windows.Forms.Button();
            this.tableLayoutPanelWord_IdentitasPegawai = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.labelNama = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelJabatan = new System.Windows.Forms.Label();
            this.labelWaktu = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonKelolaPSB = new System.Windows.Forms.Button();
            this.buttonBayarTagihan = new System.Windows.Forms.Button();
            this.tableLayoutPanelBottomBar = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanelIcon_Middle = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxPengelolaanPegawai2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxIndetitasPegawai = new System.Windows.Forms.PictureBox();
            this.pictureBoxPengelolaanPegawai = new System.Windows.Forms.PictureBox();
            this.pictureBoxPengelolaanPegawai3 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanelIcon_Utama = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxControl = new System.Windows.Forms.PictureBox();
            this.pictureBoxWindows = new System.Windows.Forms.PictureBox();
            this.btnPermohonanPDL = new System.Windows.Forms.Button();
            this.buttonBayarTagihanPDL = new System.Windows.Forms.Button();
            this.tableLayoutPanelWord_Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanelWord_Utama.SuspendLayout();
            this.tableLayoutPanelWord_Middle.SuspendLayout();
            this.tableLayoutPanelWord_IdentitasPegawai.SuspendLayout();
            this.tableLayoutPanelBottomBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.tableLayoutPanelIcon_Middle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIndetitasPegawai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai3)).BeginInit();
            this.tableLayoutPanelIcon_Utama.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindows)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Trajan Pro", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label7.Location = new System.Drawing.Point(6, 663);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(377, 67);
            this.label7.TabIndex = 8;
            this.label7.Text = "SILIPI - DESKTOP © 2017";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanelWord_Top
            // 
            this.tableLayoutPanelWord_Top.ColumnCount = 2;
            this.tableLayoutPanelWord_Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.98695F));
            this.tableLayoutPanelWord_Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.01305F));
            this.tableLayoutPanelWord_Top.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanelWord_Top.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanelWord_Top.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_Top.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanelWord_Top.Name = "tableLayoutPanelWord_Top";
            this.tableLayoutPanelWord_Top.RowCount = 1;
            this.tableLayoutPanelWord_Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWord_Top.Size = new System.Drawing.Size(377, 94);
            this.tableLayoutPanelWord_Top.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Trajan Pro", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(134, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(240, 94);
            this.label6.TabIndex = 8;
            this.label6.Text = "Identitas Pegawai";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_id;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanelWord_Utama
            // 
            this.tableLayoutPanelWord_Utama.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelWord_Utama.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanelWord_Utama.ColumnCount = 1;
            this.tableLayoutPanelWord_Utama.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Utama.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanelWord_Utama.Controls.Add(this.tableLayoutPanelWord_Middle, 0, 1);
            this.tableLayoutPanelWord_Utama.Controls.Add(this.tableLayoutPanelWord_Top, 0, 0);
            this.tableLayoutPanelWord_Utama.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanelWord_Utama.Location = new System.Drawing.Point(70, 0);
            this.tableLayoutPanelWord_Utama.Name = "tableLayoutPanelWord_Utama";
            this.tableLayoutPanelWord_Utama.RowCount = 3;
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 67F));
            this.tableLayoutPanelWord_Utama.Size = new System.Drawing.Size(389, 733);
            this.tableLayoutPanelWord_Utama.TabIndex = 11;
            this.tableLayoutPanelWord_Utama.Visible = false;
            // 
            // tableLayoutPanelWord_Middle
            // 
            this.tableLayoutPanelWord_Middle.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelWord_Middle.ColumnCount = 1;
            this.tableLayoutPanelWord_Middle.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonPengubahanStatusPemasangan, 0, 10);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonPembelianToken, 0, 9);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonPembayaranTagihanPascabayar, 0, 8);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonPencatatanTagihanPascabayar, 0, 7);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonCetakMember, 0, 4);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonCetakKartuMember, 0, 3);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.tableLayoutPanelWord_IdentitasPegawai, 0, 0);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonKelolaPSB, 0, 1);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonBayarTagihan, 0, 2);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.btnPermohonanPDL, 0, 5);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonBayarTagihanPDL, 0, 6);
            this.tableLayoutPanelWord_Middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_Middle.Location = new System.Drawing.Point(6, 109);
            this.tableLayoutPanelWord_Middle.Name = "tableLayoutPanelWord_Middle";
            this.tableLayoutPanelWord_Middle.RowCount = 11;
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999275F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999275F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999275F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999275F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.0001F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999099F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.999279F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.00027F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.00143F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.00272F));
            this.tableLayoutPanelWord_Middle.Size = new System.Drawing.Size(377, 548);
            this.tableLayoutPanelWord_Middle.TabIndex = 3;
            // 
            // buttonPengubahanStatusPemasangan
            // 
            this.buttonPengubahanStatusPemasangan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPengubahanStatusPemasangan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonPengubahanStatusPemasangan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPengubahanStatusPemasangan.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonPengubahanStatusPemasangan.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonPengubahanStatusPemasangan.Location = new System.Drawing.Point(3, 502);
            this.buttonPengubahanStatusPemasangan.Name = "buttonPengubahanStatusPemasangan";
            this.buttonPengubahanStatusPemasangan.Size = new System.Drawing.Size(371, 43);
            this.buttonPengubahanStatusPemasangan.TabIndex = 7;
            this.buttonPengubahanStatusPemasangan.Text = "Pengubahan Status Pemasangan";
            this.buttonPengubahanStatusPemasangan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPengubahanStatusPemasangan.UseVisualStyleBackColor = true;
            this.buttonPengubahanStatusPemasangan.Click += new System.EventHandler(this.buttonPengubahanStatusPemasangan_Click);
            // 
            // buttonPembelianToken
            // 
            this.buttonPembelianToken.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPembelianToken.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonPembelianToken.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPembelianToken.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonPembelianToken.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonPembelianToken.Location = new System.Drawing.Point(3, 461);
            this.buttonPembelianToken.Name = "buttonPembelianToken";
            this.buttonPembelianToken.Size = new System.Drawing.Size(371, 35);
            this.buttonPembelianToken.TabIndex = 6;
            this.buttonPembelianToken.Text = "Pembelian Token";
            this.buttonPembelianToken.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPembelianToken.UseVisualStyleBackColor = true;
            this.buttonPembelianToken.Click += new System.EventHandler(this.buttonPembelianToken_Click);
            // 
            // buttonPembayaranTagihanPascabayar
            // 
            this.buttonPembayaranTagihanPascabayar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPembayaranTagihanPascabayar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonPembayaranTagihanPascabayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPembayaranTagihanPascabayar.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonPembayaranTagihanPascabayar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonPembayaranTagihanPascabayar.Location = new System.Drawing.Point(3, 420);
            this.buttonPembayaranTagihanPascabayar.Name = "buttonPembayaranTagihanPascabayar";
            this.buttonPembayaranTagihanPascabayar.Size = new System.Drawing.Size(371, 35);
            this.buttonPembayaranTagihanPascabayar.TabIndex = 5;
            this.buttonPembayaranTagihanPascabayar.Text = "Pembayaran Tagihan Pascabayar.";
            this.buttonPembayaranTagihanPascabayar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPembayaranTagihanPascabayar.UseVisualStyleBackColor = true;
            this.buttonPembayaranTagihanPascabayar.Click += new System.EventHandler(this.buttonPembayaranTagihanPascabayar_Click);
            // 
            // buttonPencatatanTagihanPascabayar
            // 
            this.buttonPencatatanTagihanPascabayar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPencatatanTagihanPascabayar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonPencatatanTagihanPascabayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPencatatanTagihanPascabayar.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonPencatatanTagihanPascabayar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonPencatatanTagihanPascabayar.Location = new System.Drawing.Point(3, 379);
            this.buttonPencatatanTagihanPascabayar.Name = "buttonPencatatanTagihanPascabayar";
            this.buttonPencatatanTagihanPascabayar.Size = new System.Drawing.Size(371, 35);
            this.buttonPencatatanTagihanPascabayar.TabIndex = 4;
            this.buttonPencatatanTagihanPascabayar.Text = "Pencatatan Tagihan Pascabayar.";
            this.buttonPencatatanTagihanPascabayar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPencatatanTagihanPascabayar.UseVisualStyleBackColor = true;
            this.buttonPencatatanTagihanPascabayar.Click += new System.EventHandler(this.buttonPencatatanTagihanPascabayar_Click);
            // 
            // buttonCetakMember
            // 
            this.buttonCetakMember.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCetakMember.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonCetakMember.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCetakMember.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonCetakMember.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonCetakMember.Location = new System.Drawing.Point(3, 256);
            this.buttonCetakMember.Name = "buttonCetakMember";
            this.buttonCetakMember.Size = new System.Drawing.Size(371, 35);
            this.buttonCetakMember.TabIndex = 3;
            this.buttonCetakMember.Text = "Cetak Kartu Member.";
            this.buttonCetakMember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCetakMember.UseVisualStyleBackColor = true;
            this.buttonCetakMember.Click += new System.EventHandler(this.buttonCetakKartuMember_Click);
            // 
            // buttonCetakKartuMember
            // 
            this.buttonCetakKartuMember.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonCetakKartuMember.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonCetakKartuMember.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCetakKartuMember.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonCetakKartuMember.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonCetakKartuMember.Location = new System.Drawing.Point(3, 215);
            this.buttonCetakKartuMember.Name = "buttonCetakKartuMember";
            this.buttonCetakKartuMember.Size = new System.Drawing.Size(371, 35);
            this.buttonCetakKartuMember.TabIndex = 2;
            this.buttonCetakKartuMember.Text = "Pembayaran Tagihan PSB.";
            this.buttonCetakKartuMember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCetakKartuMember.UseVisualStyleBackColor = true;
            this.buttonCetakKartuMember.Click += new System.EventHandler(this.buttonBayarTagihan_Click);
            // 
            // tableLayoutPanelWord_IdentitasPegawai
            // 
            this.tableLayoutPanelWord_IdentitasPegawai.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnCount = 2;
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 278F));
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelNama, 1, 0);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelUsername, 1, 1);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelJabatan, 1, 2);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelWaktu, 1, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanelWord_IdentitasPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_IdentitasPegawai.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Name = "tableLayoutPanelWord_IdentitasPegawai";
            this.tableLayoutPanelWord_IdentitasPegawai.RowCount = 4;
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.Size = new System.Drawing.Size(371, 124);
            this.tableLayoutPanelWord_IdentitasPegawai.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LimeGreen;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(5, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 30);
            this.label5.TabIndex = 7;
            this.label5.Text = "Time";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelNama
            // 
            this.labelNama.AutoSize = true;
            this.labelNama.BackColor = System.Drawing.Color.LimeGreen;
            this.labelNama.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelNama.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNama.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelNama.Location = new System.Drawing.Point(115, 2);
            this.labelNama.Name = "labelNama";
            this.labelNama.Size = new System.Drawing.Size(105, 28);
            this.labelNama.TabIndex = 0;
            this.labelNama.Text = "labelNama";
            this.labelNama.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelUsername.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsername.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelUsername.Location = new System.Drawing.Point(115, 32);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(145, 28);
            this.labelUsername.TabIndex = 1;
            this.labelUsername.Text = "labelUsername";
            this.labelUsername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelJabatan
            // 
            this.labelJabatan.AutoSize = true;
            this.labelJabatan.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelJabatan.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJabatan.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelJabatan.Location = new System.Drawing.Point(115, 62);
            this.labelJabatan.Name = "labelJabatan";
            this.labelJabatan.Size = new System.Drawing.Size(123, 28);
            this.labelJabatan.TabIndex = 2;
            this.labelJabatan.Text = "labelJabatan";
            this.labelJabatan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelWaktu
            // 
            this.labelWaktu.AutoSize = true;
            this.labelWaktu.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelWaktu.Font = new System.Drawing.Font("Trajan Pro", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWaktu.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelWaktu.Location = new System.Drawing.Point(115, 92);
            this.labelWaktu.Name = "labelWaktu";
            this.labelWaktu.Size = new System.Drawing.Size(106, 30);
            this.labelWaktu.TabIndex = 3;
            this.labelWaktu.Text = "labelWaktu";
            this.labelWaktu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LimeGreen;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(5, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nama";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LimeGreen;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(5, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 28);
            this.label3.TabIndex = 5;
            this.label3.Text = "Username";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LimeGreen;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(5, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 28);
            this.label4.TabIndex = 6;
            this.label4.Text = "Jabatan";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonKelolaPSB
            // 
            this.buttonKelolaPSB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonKelolaPSB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonKelolaPSB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKelolaPSB.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonKelolaPSB.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonKelolaPSB.Location = new System.Drawing.Point(3, 133);
            this.buttonKelolaPSB.Name = "buttonKelolaPSB";
            this.buttonKelolaPSB.Size = new System.Drawing.Size(371, 35);
            this.buttonKelolaPSB.TabIndex = 0;
            this.buttonKelolaPSB.Text = "Pengelolaan Permohonan PSB.";
            this.buttonKelolaPSB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonKelolaPSB.UseVisualStyleBackColor = true;
            this.buttonKelolaPSB.Click += new System.EventHandler(this.buttonKelolaPSB_Click);
            // 
            // buttonBayarTagihan
            // 
            this.buttonBayarTagihan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBayarTagihan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonBayarTagihan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBayarTagihan.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonBayarTagihan.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonBayarTagihan.Location = new System.Drawing.Point(3, 174);
            this.buttonBayarTagihan.Name = "buttonBayarTagihan";
            this.buttonBayarTagihan.Size = new System.Drawing.Size(371, 35);
            this.buttonBayarTagihan.TabIndex = 1;
            this.buttonBayarTagihan.Text = "Buat dan Cetak Tagihan PSB.";
            this.buttonBayarTagihan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonBayarTagihan.UseVisualStyleBackColor = true;
            this.buttonBayarTagihan.Click += new System.EventHandler(this.buttonCetakTagihan_Click);
            // 
            // tableLayoutPanelBottomBar
            // 
            this.tableLayoutPanelBottomBar.AutoSize = true;
            this.tableLayoutPanelBottomBar.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelBottomBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tableLayoutPanelBottomBar.ColumnCount = 2;
            this.tableLayoutPanelBottomBar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.07245F));
            this.tableLayoutPanelBottomBar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.927552F));
            this.tableLayoutPanelBottomBar.Controls.Add(this.pictureBoxExit, 1, 0);
            this.tableLayoutPanelBottomBar.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanelBottomBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanelBottomBar.Location = new System.Drawing.Point(459, 663);
            this.tableLayoutPanelBottomBar.Name = "tableLayoutPanelBottomBar";
            this.tableLayoutPanelBottomBar.RowCount = 1;
            this.tableLayoutPanelBottomBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelBottomBar.Size = new System.Drawing.Size(895, 70);
            this.tableLayoutPanelBottomBar.TabIndex = 12;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBoxExit.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBoxExit.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_door_enter;
            this.pictureBoxExit.Location = new System.Drawing.Point(844, 3);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(48, 64);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxExit.TabIndex = 7;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            this.pictureBoxExit.MouseLeave += new System.EventHandler(this.pictureBoxExit_MouseLeave);
            this.pictureBoxExit.MouseHover += new System.EventHandler(this.pictureBoxExit_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Trajan Pro", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(835, 70);
            this.label1.TabIndex = 6;
            this.label1.Text = "Sistem Informasi Listrik Pintar";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanelIcon_Middle
            // 
            this.tableLayoutPanelIcon_Middle.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelIcon_Middle.ColumnCount = 1;
            this.tableLayoutPanelIcon_Middle.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai2, 0, 2);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxIndetitasPegawai, 0, 0);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai, 0, 1);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai3, 0, 3);
            this.tableLayoutPanelIcon_Middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelIcon_Middle.Location = new System.Drawing.Point(3, 103);
            this.tableLayoutPanelIcon_Middle.Name = "tableLayoutPanelIcon_Middle";
            this.tableLayoutPanelIcon_Middle.RowCount = 4;
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.Size = new System.Drawing.Size(64, 557);
            this.tableLayoutPanelIcon_Middle.TabIndex = 3;
            // 
            // pictureBoxPengelolaanPegawai2
            // 
            this.pictureBoxPengelolaanPegawai2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai2.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai2.Location = new System.Drawing.Point(3, 281);
            this.pictureBoxPengelolaanPegawai2.Name = "pictureBoxPengelolaanPegawai2";
            this.pictureBoxPengelolaanPegawai2.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxPengelolaanPegawai2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai2.TabIndex = 5;
            this.pictureBoxPengelolaanPegawai2.TabStop = false;
            // 
            // pictureBoxIndetitasPegawai
            // 
            this.pictureBoxIndetitasPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxIndetitasPegawai.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_users_man_woman;
            this.pictureBoxIndetitasPegawai.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxIndetitasPegawai.Name = "pictureBoxIndetitasPegawai";
            this.pictureBoxIndetitasPegawai.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxIndetitasPegawai.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxIndetitasPegawai.TabIndex = 3;
            this.pictureBoxIndetitasPegawai.TabStop = false;
            this.pictureBoxIndetitasPegawai.Click += new System.EventHandler(this.pictureBoxControl_Click);
            this.pictureBoxIndetitasPegawai.MouseLeave += new System.EventHandler(this.pictureBoxIndetitasPegawai_MouseLeave);
            this.pictureBoxIndetitasPegawai.MouseHover += new System.EventHandler(this.pictureBoxIndetitasPegawai_MouseHover);
            // 
            // pictureBoxPengelolaanPegawai
            // 
            this.pictureBoxPengelolaanPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai.Location = new System.Drawing.Point(3, 142);
            this.pictureBoxPengelolaanPegawai.Name = "pictureBoxPengelolaanPegawai";
            this.pictureBoxPengelolaanPegawai.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxPengelolaanPegawai.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai.TabIndex = 4;
            this.pictureBoxPengelolaanPegawai.TabStop = false;
            this.pictureBoxPengelolaanPegawai.MouseLeave += new System.EventHandler(this.pictureBoxPengelolaanPegawai_MouseLeave);
            this.pictureBoxPengelolaanPegawai.MouseHover += new System.EventHandler(this.pictureBoxPengelolaanPegawai_MouseHover);
            // 
            // pictureBoxPengelolaanPegawai3
            // 
            this.pictureBoxPengelolaanPegawai3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai3.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai3.Location = new System.Drawing.Point(3, 420);
            this.pictureBoxPengelolaanPegawai3.Name = "pictureBoxPengelolaanPegawai3";
            this.pictureBoxPengelolaanPegawai3.Size = new System.Drawing.Size(58, 134);
            this.pictureBoxPengelolaanPegawai3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai3.TabIndex = 6;
            this.pictureBoxPengelolaanPegawai3.TabStop = false;
            // 
            // tableLayoutPanelIcon_Utama
            // 
            this.tableLayoutPanelIcon_Utama.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelIcon_Utama.ColumnCount = 1;
            this.tableLayoutPanelIcon_Utama.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.tableLayoutPanelIcon_Middle, 0, 1);
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.pictureBoxControl, 0, 0);
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.pictureBoxWindows, 0, 2);
            this.tableLayoutPanelIcon_Utama.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanelIcon_Utama.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelIcon_Utama.Name = "tableLayoutPanelIcon_Utama";
            this.tableLayoutPanelIcon_Utama.RowCount = 3;
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelIcon_Utama.Size = new System.Drawing.Size(70, 733);
            this.tableLayoutPanelIcon_Utama.TabIndex = 10;
            // 
            // pictureBoxControl
            // 
            this.pictureBoxControl.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBoxControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxControl.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_right_circle;
            this.pictureBoxControl.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxControl.Name = "pictureBoxControl";
            this.pictureBoxControl.Size = new System.Drawing.Size(64, 94);
            this.pictureBoxControl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxControl.TabIndex = 5;
            this.pictureBoxControl.TabStop = false;
            this.pictureBoxControl.Click += new System.EventHandler(this.pictureBoxControl_Click);
            this.pictureBoxControl.MouseLeave += new System.EventHandler(this.pictureBoxControl_MouseLeave);
            this.pictureBoxControl.MouseHover += new System.EventHandler(this.pictureBoxControl_MouseHover);
            // 
            // pictureBoxWindows
            // 
            this.pictureBoxWindows.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxWindows.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_logo_apple;
            this.pictureBoxWindows.Location = new System.Drawing.Point(3, 666);
            this.pictureBoxWindows.Name = "pictureBoxWindows";
            this.pictureBoxWindows.Size = new System.Drawing.Size(64, 64);
            this.pictureBoxWindows.TabIndex = 6;
            this.pictureBoxWindows.TabStop = false;
            // 
            // btnPermohonanPDL
            // 
            this.btnPermohonanPDL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnPermohonanPDL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnPermohonanPDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPermohonanPDL.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.btnPermohonanPDL.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnPermohonanPDL.Location = new System.Drawing.Point(3, 297);
            this.btnPermohonanPDL.Name = "btnPermohonanPDL";
            this.btnPermohonanPDL.Size = new System.Drawing.Size(371, 35);
            this.btnPermohonanPDL.TabIndex = 8;
            this.btnPermohonanPDL.Text = "Pengelolaan Permohonan PDL";
            this.btnPermohonanPDL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPermohonanPDL.UseVisualStyleBackColor = true;
            this.btnPermohonanPDL.Click += new System.EventHandler(this.btnPermohonanPDL_Click);
            // 
            // buttonBayarTagihanPDL
            // 
            this.buttonBayarTagihanPDL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonBayarTagihanPDL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonBayarTagihanPDL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBayarTagihanPDL.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonBayarTagihanPDL.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonBayarTagihanPDL.Location = new System.Drawing.Point(3, 338);
            this.buttonBayarTagihanPDL.Name = "buttonBayarTagihanPDL";
            this.buttonBayarTagihanPDL.Size = new System.Drawing.Size(371, 35);
            this.buttonBayarTagihanPDL.TabIndex = 9;
            this.buttonBayarTagihanPDL.Text = "Buat dan Cetak Tagihan PDL.";
            this.buttonBayarTagihanPDL.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonBayarTagihanPDL.UseVisualStyleBackColor = true;
            this.buttonBayarTagihanPDL.Click += new System.EventHandler(this.buttonBayarTagihanPDL_Click);
            // 
            // DashboardPetugasLoketUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1354, 733);
            this.Controls.Add(this.tableLayoutPanelBottomBar);
            this.Controls.Add(this.tableLayoutPanelWord_Utama);
            this.Controls.Add(this.tableLayoutPanelIcon_Utama);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.IsMdiContainer = true;
            this.Name = "DashboardPetugasLoketUI";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardPetugasLoketUI";
            this.Load += new System.EventHandler(this.DashboardPetugasLoketUI_Load);
            this.tableLayoutPanelWord_Top.ResumeLayout(false);
            this.tableLayoutPanelWord_Top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanelWord_Utama.ResumeLayout(false);
            this.tableLayoutPanelWord_Utama.PerformLayout();
            this.tableLayoutPanelWord_Middle.ResumeLayout(false);
            this.tableLayoutPanelWord_IdentitasPegawai.ResumeLayout(false);
            this.tableLayoutPanelWord_IdentitasPegawai.PerformLayout();
            this.tableLayoutPanelBottomBar.ResumeLayout(false);
            this.tableLayoutPanelBottomBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.tableLayoutPanelIcon_Middle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIndetitasPegawai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai3)).EndInit();
            this.tableLayoutPanelIcon_Utama.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindows)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Top;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Utama;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Middle;
        private System.Windows.Forms.Button buttonCetakKartuMember;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_IdentitasPegawai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelNama;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label labelJabatan;
        private System.Windows.Forms.Label labelWaktu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonKelolaPSB;
        private System.Windows.Forms.Button buttonBayarTagihan;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBottomBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBoxControl;
        private System.Windows.Forms.PictureBox pictureBoxWindows;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai3;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai2;
        private System.Windows.Forms.PictureBox pictureBoxIndetitasPegawai;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelIcon_Middle;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelIcon_Utama;
        private System.Windows.Forms.Button buttonCetakMember;
        private System.Windows.Forms.Button buttonPencatatanTagihanPascabayar;
        private System.Windows.Forms.Button buttonPembayaranTagihanPascabayar;
        private System.Windows.Forms.Button buttonPembelianToken;
        private System.Windows.Forms.Button buttonPengubahanStatusPemasangan;
        private System.Windows.Forms.Button btnPermohonanPDL;
        private System.Windows.Forms.Button buttonBayarTagihanPDL;
    }
}