﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class TarifUI : Form
    {
        TarifControl TControl = new TarifControl();
        PegawaiEntity data_pegawai = new PegawaiEntity();

        /* 
         *  SINGLETON FORM 
         */
        private static TarifUI instance;
        public static TarifUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new TarifUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public TarifUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public TarifUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            this.data_pegawai = data_pegawai;
        }

        private void TarifUI_Load(object sender, EventArgs e)
        {
            TampilDataTarifPSB(this.dataGridView1);
            TampilDataTarifBulanan(this.dataGridView2);
            //uC_Pegawai1.setFlag(1);
            //uC_Pegawai1.Visible = false;
        }

        public void TampilDataTarifPSB(DataGridView data)
        {
            data.DataSource = TControl.getDataTarifPSB();
            DataTable DT = TControl.getDataTarifPSB();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            //data.Columns.RemoveAt(0);  // remove col 0 di datagridview
            //data.Columns.RemoveAt(1);  // remove col 1 di fatagridview
            //data.Columns[0].Visible = false; // hide col 0 di datagridview

            data.Columns[0].HeaderText = "ID Tarif";
            data.Columns[1].HeaderText = "Kategori Tarif";
            data.Columns[2].HeaderText = "Beban";
            data.Columns[3].HeaderText = "Biaya UJL";
            data.Columns[4].HeaderText = "Biaya Sambung";
            data.Columns[5].HeaderText = "Tarif PSB?";

            data.Columns[0].Width = 86;
            data.Columns[1].Width = 200;
            data.Columns[2].Width = 100;
            data.Columns[3].Width = 100;
            data.Columns[4].Width = 150;
            data.Columns[5].Width = 100;

            data.Columns[6].Visible = false;
            data.Columns[7].Visible = false;
            data.Columns[8].Visible = false;
        }

        public void TampilDataTarifBulanan(DataGridView data)
        {
            data.DataSource = TControl.getDataTarifBulanan();
            DataTable DT2 = TControl.getDataTarifBulanan();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT2.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT2.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT2.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource2.DataSource = listTbl;
            bindingNavigator2.BindingSource = bindingSource2;
            data.DataSource = (DT2.Rows.Count > 0 ? listTbl[bindingSource2.Position] : DT2);

            //data.Columns.RemoveAt(0);  // remove col 0 di datagridview
            //data.Columns.RemoveAt(1);  // remove col 1 di fatagridview
            //data.Columns[0].Visible = false; // hide col 0 di datagridview

            data.Columns[0].HeaderText = "ID Tarif";
            data.Columns[1].HeaderText = "Kategori Tarif";
            data.Columns[2].HeaderText = "Beban";
            data.Columns[6].HeaderText = "Biaya Beban";
            data.Columns[7].HeaderText = "Biaya Pemakaian";
            data.Columns[8].HeaderText = "Tarif Bulanan?";

            data.Columns[0].Width = 86;
            data.Columns[1].Width = 200;
            data.Columns[2].Width = 100;
            data.Columns[6].Width = 100;
            data.Columns[7].Width = 150;
            data.Columns[8].Width = 100;

            data.Columns[3].Visible = false;
            data.Columns[4].Visible = false;
            data.Columns[5].Visible = false;

        }

        public void EnableAfterInsert(int page)  // 1 = pagePSB, 2= pageBulanan
        {
            tabControl1.Enabled = true;
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            btnTambah.Enabled = true;
            edCari.Enabled = true;
            edCariPasca.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            TampilDataTarifPSB(this.dataGridView1);
            TampilDataTarifBulanan(this.dataGridView2);

            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }

            if (dataGridView2.RowCount > 0)
            {
                dataGridView2.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView2, 0);
            }
        }

        public void EnableAfterEdit(int page) // 1 = pagePSB, 2= pageBulanan
        {
            tabControl1.Enabled = true;
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            btnTambah.Enabled = true;
            edCari.Enabled = true;
            edCariPasca.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            if(page == 1) 
            {           
                edCari.Enabled = true;            
                dataGridView1.Enabled = true;
                TampilDataTarifPSB(this.dataGridView1);
          
                if (tabControl1.SelectedTab == tabPagePSB)
                {
                    dataGridView1.Rows[0].Selected = false;
                    dataGridView1.Rows[int.Parse(txtRow.Text)].Selected = true;
                    txtID.Text = getKolomEdit(dataGridView1, int.Parse(txtRow.Text));
                }
            }

            if (page == 2)
            {
                edCariPasca.Enabled = true;
                dataGridView2.Enabled = true;
                TampilDataTarifBulanan(this.dataGridView2);
                if (tabControl1.SelectedTab == tabPageBulanan)
                {
                    dataGridView2.Rows[0].Selected = false;
                    dataGridView2.Rows[int.Parse(txtRow.Text)].Selected = true;
                    txtID.Text = getKolomEdit(dataGridView2, int.Parse(txtRow.Text));
                }
            }
        }

        public void EnableAfterDelete()
        {
            tabControl1.Enabled = true;
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            this.btnTambah.Enabled = true;
            edCari.Enabled = true;
            edCariPasca.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            TampilDataTarifPSB(this.dataGridView1);
            TampilDataTarifBulanan(this.dataGridView2);

            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }

            if (dataGridView2.RowCount > 0)
            {
                dataGridView2.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView2, 0);
            }
        }
           
        private string getKolom(DataGridView dg, int i)
        {
            try
            {
                return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
            }
            catch (Exception e) { return e.ToString(); };
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePSB)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageBulanan)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePSB)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageBulanan)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePSB)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageBulanan)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        public void DisableMainForm()
        {
            tabControl1.Enabled = false;
            dataGridView1.Enabled = false;
            dataGridView2.Enabled = false;
            edCari.Enabled = false;
            edCariPasca.Enabled = false;
            this.btnTambah.Enabled = false;
            this.btnHapus.Enabled = false;
            this.btnUbah.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataTarifPSB(dataGridView1);
        }

        private void bindingSource2_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataTarifBulanan(dataGridView2);
        }

        private void btnKeluar_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePSB)
            {  
                uC_Tarif1.selectTabPagePSB();
            }
            else if (tabControl1.SelectedTab == tabPageBulanan)
            {
                uC_Tarif1.selectTabPageBulanan();
            }
            
            uC_Tarif1.Visible = true;
            uC_Tarif1.btnTambah.Text = "Tambahkan";
            uC_Tarif1.btnTambahPasca.Text = "Tambahkan";
            uC_Tarif1.setFlag(1);
            DisableMainForm();
        }
          
        private void btnUbah_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih tarif terlebih dahulu!");
                if (tabControl1.SelectedTab == tabPagePSB)
                    dataGridView1.Focus();
                else
                    dataGridView2.Focus();
            }
            else
            {
                
                if(tabControl1.SelectedTab == tabPagePSB)
                {
                    uC_Tarif1.selectTabPagePSB();
                    uC_Tarif1.setFlag(2);
                    uC_Tarif1.btnTambah.Text = "Ubah";

                    int id_tarif = int.Parse(txtID.Text);
                    string kategori_tarif = getKolom(dataGridView1, 1); 
                    int beban = int.Parse(getKolom(dataGridView1, 2));
                    int biaya_ujl = int.Parse(getKolom(dataGridView1, 3));
                    int biaya_sambung = int.Parse(getKolom(dataGridView1, 4));
                
                    uC_Tarif1.fillFormPSB(id_tarif, kategori_tarif, beban, biaya_ujl, biaya_sambung);
                }
                else if(tabControl1.SelectedTab == tabPageBulanan)
                {
                    uC_Tarif1.selectTabPageBulanan();
                    uC_Tarif1.setFlag(2);
                    uC_Tarif1.btnTambahPasca.Text = "Ubah";

                    int id_tarif = int.Parse(txtID.Text);
                    string kategori_tarif = getKolom(dataGridView2, 1); 
                    int beban = int.Parse(getKolom(dataGridView2, 2));
                    int biaya_beban = int.Parse(getKolom(dataGridView2, 6));
                    int biaya_pemakaian = int.Parse(getKolom(dataGridView2, 7));
                
                    uC_Tarif1.fillFormBulanan(id_tarif, kategori_tarif, beban, biaya_beban, biaya_pemakaian);
                }

                uC_Tarif1.Visible = true;
                txtID.Clear();
                DisableMainForm();
            }
        }
        
      
        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih tarif terlebih dahulu!");
                if (tabControl1.SelectedTab == tabPagePSB)
                    dataGridView1.Focus();
                else
                    dataGridView2.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Apakah anda yakin menghapus tarif ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    TControl.deleteDataTarif(int.Parse(txtID.Text));
                    EnableAfterDelete();
                }
            }
        }

        private void edCariPSB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = TControl.searchDataTarifPSB(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                if (tabControl1.SelectedTab == tabPagePSB) {
                    TampilDataTarifPSB(this.dataGridView1);            
                }
                else {
                    dataGridView1.Focus();          
                }
            }
        }

        private void edCariBulanan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView2.DataSource = TControl.searchDataTarifBulanan(edCariPasca.Text);
            }

            if (edCariPasca.Text.Length == 1)
            {
                if (tabControl1.SelectedTab == tabPageBulanan)
                {
                    TampilDataTarifBulanan(this.dataGridView2);
                }
                else
                {
                    dataGridView2.Focus();  
                }
            }
        }

        private void uC_Tarif1_VisibleChanged(object sender, EventArgs e)
        {
            /*
             * uC_Tarif1.Location = new Point(
            this.ClientSize.Width / 2 - uC_Tarif1.Size.Width / 2,
            this.ClientSize.Height / 2 - uC_Tarif1.Size.Height / 2);
            uC_Tarif1.Anchor = AnchorStyles.None;
             * */
            uC_Tarif1.Dock = DockStyle.Fill;
        } 
    }
}
