﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class PermohonanPDLUI : Form
    {
        PermohonanPSBControl permohonanControl = new PermohonanPSBControl();
        MemberControl memberControl = new MemberControl();
        PegawaiEntity Pegawai = new PegawaiEntity();
        Random rnd = new Random();

        /* 
         *  SINGLETON FORM 
         */
        private static PermohonanPDLUI instance;
        public static PermohonanPDLUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new PermohonanPDLUI();
                return instance;
            }
        }

        public void setPegawai(PegawaiEntity data_pegawai) { this.Pegawai = data_pegawai; }

        public PermohonanPDLUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */



        public PermohonanPDLUI(PegawaiEntity Pegawai)
        {
            InitializeComponent();
            this.Pegawai = Pegawai;
            WindowState = FormWindowState.Maximized;
        }

        private void PermohonanPDLUI_Load(object sender, EventArgs e)
        {
            TampilDataMember(this.dataGridView1);
            TampilDataVerifikasiPDL(this.dataGridView2);
            uC_PermohonanPDL1.Visible = false;
        }

        public void TampilDataMember(DataGridView data)
        {
            data.DataSource = memberControl.getDataMember();
            DataTable DT = memberControl.getDataMember();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_MEMBER, NOMOR_KTP, NOMOR_MEMBER, NOMOR_KWH, NAMA_MEMBER, TANGGAL_LAHIR_MEMBER, ALAMAT_INSTALASI, NOMOR_HP_MEMBER, PEKERJAAN, DAYA_LISTRIK, TIPE_MEMBER, STATUS";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_MEMBER";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }

        public void TampilDataVerifikasiPDL(DataGridView data)
        {
            data.DataSource = permohonanControl.getDataPermohonanPSB_BelumTerverifikasi();
            DataTable DT = permohonanControl.getDataPermohonanPSB_BelumTerverifikasi();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource2.DataSource = listTbl;
            bindingNavigator2.BindingSource = bindingSource2;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA, IDENTITAS_PEMOHON, NAMA_PEMOHON, TANGGAL_LAHIR, ALAMAT_PEMOHON, NOMOR_HP_PEMOHON, PEKERJAAN_PEMOHON, DAYA_PERMOHONAN, JENIS_SAMBUNGAN, NOMOR_RESI, TANGGAL_PERMOHONAN, TANGGAL_PERSETUJUAN, TANGGAL_PENOLAKAN, DESKRIPSI";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }

        }

        public void EnableAfterInsert()
        {
            tabControl1.Enabled = true;
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            this.btnTambah.Enabled = true;
            edCari.Enabled = true;
            edCariPasca.Enabled = true;
            this.btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            TampilDataMember(this.dataGridView1);
            TampilDataVerifikasiPDL(this.dataGridView2);

            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }

            if (dataGridView2.RowCount > 0)
            {
                dataGridView2.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView2, 0);
            }
        }

        /*
        public void EnableAfterEdit(int page) // 1 = pagePSB, 2= pageBulanan
        {
            tabControl1.Enabled = true;
            btnTambah.Enabled = true;
            btnHapus.Enabled = true;
            btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            if (page == 1)
            {
                edCari.Enabled = true;
                dataGridView1.Enabled = true;
                TampilDataTarifPSB(this.dataGridView1);

                if (tabControl1.SelectedTab == tabPagePSB)
                {
                    dataGridView1.Rows[0].Selected = false;
                    dataGridView1.Rows[int.Parse(txtRow.Text)].Selected = true;
                    txtID.Text = getKolomEdit(dataGridView1, int.Parse(txtRow.Text));
                }
            }

            if (page == 2)
            {
                edCariPasca.Enabled = true;
                dataGridView2.Enabled = true;
                TampilDataTarifBulanan(this.dataGridView2);
                if (tabControl1.SelectedTab == tabPageBulanan)
                {
                    dataGridView2.Rows[0].Selected = false;
                    dataGridView2.Rows[int.Parse(txtRow.Text)].Selected = true;
                    txtID.Text = getKolomEdit(dataGridView2, int.Parse(txtRow.Text));
                }
            }
        }
        */

        /*
        public void EnableAfterDelete()
        {
            tabControl1.Enabled = true;
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            this.btnTambah.Enabled = true;
            edCari.Enabled = true;
            edCariPasca.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;
            this.btnKeluar.Enabled = true;

            TampilDataTarifPSB(this.dataGridView1);
            TampilDataTarifBulanan(this.dataGridView2);

            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }

            if (dataGridView2.RowCount > 0)
            {
                dataGridView2.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView2, 0);
            }
        }
        */
          
        private string getKolom(DataGridView dg, int i)
        {
            try
            {
                return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
            }
            catch (Exception e) { return e.ToString(); };
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePDL)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageVerifikasi)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePDL)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageVerifikasi)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePDL)
            {
                txtID.Text = getKolom(dataGridView1, 0);
                txtRow.Text = getRow(dataGridView1);
            }
            else if (tabControl1.SelectedTab == tabPageVerifikasi)
            {
                txtID.Text = getKolom(dataGridView2, 0);
                txtRow.Text = getRow(dataGridView2);
            }
        }

        public void DisableMainForm()
        {
            tabControl1.Enabled = false;
            dataGridView1.Enabled = false;
            dataGridView2.Enabled = false;
            edCari.Enabled = false;
            edCariPasca.Enabled = false;
            this.btnTambah.Enabled = false;
            this.btnUbah.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataMember(dataGridView1);
        }

        private void bindingSource2_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataVerifikasiPDL(dataGridView2);
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePDL)
            {
                if (txtID.Text == "")
                {
                    MessageBox.Show("Silahkan pilih Member ! ", "Information");
                }
                else
                {
                    uC_PermohonanPDL1.Visible = true;
                    uC_PermohonanPDL1.BringToFront();
                    uC_PermohonanPDL1.btnTambah.Text = "Tambahkan";
                    //
                    string nomor_pelanggan = "";

                    DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
                    foreach (DataRow row in data_member.Rows)
                    {
                        nomor_pelanggan = row["NOMOR_MEMBER"].ToString();
                        break;
                    }

                    uC_PermohonanPDL1.setNomorPelanggan(nomor_pelanggan);
                    DisableMainForm();
                }
            }

            else if (tabControl1.SelectedTab == tabPageVerifikasi)
            {
                DialogResult dr = MessageBox.Show("Are you sure want to verificate this \n(Yes to accept, No to Decline, Cancel to Back) ?", "Warning", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    string resi = this.ResiTerima();

                    PermohonanPSBEntity permohonanPSB = new PermohonanPSBEntity(resi, DateTime.Now, GlobalEntity.deskripsiPermohonan_2, int.Parse(txtID.Text));
                    permohonanControl.updateDataPenerimaanPSB(permohonanPSB);
                    TampilDataVerifikasiPDL(this.dataGridView2);
                }

                else if(dr == DialogResult.No)
                {
                    string resi = this.ResiTolak();

                    PermohonanPSBEntity permohonan = new PermohonanPSBEntity(resi, DateTime.Now, GlobalEntity.deskripsiPermohonan_3, int.Parse(txtID.Text));
                    permohonanControl.updateDataPenolakanPSB(permohonan);
                    TampilDataVerifikasiPDL(this.dataGridView2);
                }
                
            }

        }

        public string ResiTerima()
        {
            string s = string.Empty;

            s = "TR" + "-" +
                DateTime.Now.ToString("dd") +
                DateTime.Now.ToString("MM") +
                DateTime.Now.ToString("yy") +
                "-" + rnd.Next(000, 999);
            return s;
        }

        public string ResiTolak()
        {
            string s = string.Empty;

            s = "TL" + "-" +
                DateTime.Now.ToString("dd") +
                DateTime.Now.ToString("MM") +
                DateTime.Now.ToString("yy") +
                "-" + rnd.Next(000, 999);
            return s;
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void uC_PermohonanPDL1_VisibleChanged(object sender, EventArgs e)
        {
            uC_PermohonanPDL1.Dock = DockStyle.Fill;
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = memberControl.searchDataMember(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataMember(this.dataGridView1);
            }
        }
    }
}
