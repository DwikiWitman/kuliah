﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class PembayaranTagihanPSBUI : Form
    {
        PegawaiEntity pegawaiEntity = new PegawaiEntity();
        TagihanPSBControl tagihanPSBControl = new TagihanPSBControl();
        PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();

        /* 
         *  SINGLETON FORM 
         */
        private static PembayaranTagihanPSBUI instance;
        public static PembayaranTagihanPSBUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new PembayaranTagihanPSBUI();
                return instance;
            }
        }

        public void setPegawai(PegawaiEntity data_pegawai) { this.pegawaiEntity = data_pegawai; }

        public PembayaranTagihanPSBUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public PembayaranTagihanPSBUI(PegawaiEntity pegawaiEntity)
        {
            InitializeComponent();
            this.pegawaiEntity = pegawaiEntity;
            WindowState = FormWindowState.Maximized;
        }

        private void PembayaranTagihanPSBUI_Load(object sender, EventArgs e)
        {
            TampilDataTagihanPSB(this.dataGridView1);
            uC_PembayaranTagihanPSB1.Visible = false;
            uC_PembayaranTagihanPSB1.Enabled = false;
        }

        public void EnableAfterPay()
        {
            dataGridView1.Enabled = true;
            this.btnBayar.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataTagihanPSB(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        public void TampilDataTagihanPSB(DataGridView data)
        {
            data.DataSource = tagihanPSBControl.getDataTagihanPSB();
            DataTable DT = tagihanPSBControl.getDataTagihanPSB();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_TAGIHAN_PERMOHONAN, ID_PERMOHONAN, ID_PEGAWAI, ID_TARIF, TOTAL_TAGIHAN_PERMOHONAN, STATUS_TAGIHAN_PERMOHOHAN, TANGGAL_TAGIHAN_PERMOHONAN, NOMOR_RESI";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_TAGIHAN_PERMOHONAN, ID_PERMOHONAN, ID_PEGAWAI, ID_TARIF";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }


        public void TampilDataPemohonPSB(DataGridView data)
        {
            int id_permohonanpsb = tagihanPSBControl.getDataIDPermohonanByIDTagihanPSB(int.Parse(txtID.Text));
            data.DataSource = permohonanPSBControl.getDataPermohonanPSB_ByID(id_permohonanpsb);

            var columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA, IDENTITAS_PEMOHON, NAMA_PEMOHON, TANGGAL_LAHIR_PEMOHON, ALAMAT_PEMOHON, NOMOR_HP_PEMOHON, PEKERJAAN_PEMOHON, DAYA_PERMOHONAN, JENIS_SAMBUNGAN, NOMOR_RESI, TANGGAL_PERMOHONAN, TANGGAL_PERSETUJUAN, DESKRIPSI";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA, NOMOR_RESI, TANGGAL_PENOLAKAN";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }


        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView2.DataSource = null;
            else
                TampilDataPemohonPSB(dataGridView2);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView2.DataSource = null;
            else
                TampilDataPemohonPSB(dataGridView2);
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnBayar.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataTagihanPSB(dataGridView1);
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = tagihanPSBControl.getDataTagihanPSB_ByNomorResi(edCari.Text);
            }

            if (edCari.Text.Length <= 0)
            {
                TampilDataTagihanPSB(this.dataGridView1);
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log out?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                LoginUI utama = new LoginUI();
                utama.ShowDialog();
                this.Dispose();
            }
        }

        private void edCari_TextChanged(object sender, EventArgs e)
        {
            if (edCari.Text.Length <= 0)
            {
                TampilDataTagihanPSB(this.dataGridView1);
            }
        }


        private void btnBayar_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih tagihan terlebih dahulu!", "Information");
                dataGridView1.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to pay this bill? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    int id_permohonanpsb = tagihanPSBControl.getDataIDPermohonanByIDTagihanPSB(int.Parse(txtID.Text));
                    DataTable data_permohonan = permohonanPSBControl.getDataPermohonanPSB_ByID(id_permohonanpsb);
                    DataTable data_tagihan = tagihanPSBControl.getDataTagihanPSB_ByIDTagihan(int.Parse(txtID.Text));

                    uC_PembayaranTagihanPSB1.Enabled = true;
                    uC_PembayaranTagihanPSB1.Visible = true;
                    uC_PembayaranTagihanPSB1.setDataTagihanPSB(pegawaiEntity, data_permohonan, data_tagihan);
                    uC_PembayaranTagihanPSB1.BringToFront();

                }
            }
        }

        private void uC_PembayaranTagihanPSB1_VisibleChanged(object sender, EventArgs e)
        {
            /*
            uC_PembayaranTagihanPSB1.Location = new Point(
            this.ClientSize.Width / 2 - uC_PembayaranTagihanPSB1.Size.Width / 2,
            this.ClientSize.Height / 2 - uC_PembayaranTagihanPSB1.Size.Height / 2);
            uC_PembayaranTagihanPSB1.Anchor = AnchorStyles.None;
             */
            uC_PembayaranTagihanPSB1.Dock = DockStyle.Fill;
        }

        
    }
}
