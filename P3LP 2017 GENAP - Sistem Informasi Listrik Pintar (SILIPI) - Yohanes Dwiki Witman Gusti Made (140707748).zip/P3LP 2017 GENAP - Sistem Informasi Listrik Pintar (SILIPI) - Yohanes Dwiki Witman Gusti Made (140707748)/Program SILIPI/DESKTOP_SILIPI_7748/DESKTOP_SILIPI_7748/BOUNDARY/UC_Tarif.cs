﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_Tarif : UserControl
    {
        TarifControl TControl = new TarifControl();
        int flagperintah = 0;
        int tabPages = 0; 
        // tabPages 1 artinya tabPSB, 2 artinya tabBulanan
        // selectedindex = 0 artinya Pages pertama (tabPSB), sedangkan selectedindex = 1 artinya Pages kedua (tabBulanan)

        public void setFlag(int flag)
        {
            flagperintah = flag;
        }

        public UC_Tarif()
        {
            InitializeComponent();
        }

        public void selectTabPageBulanan()
        {
            //tabPagePSB.Enabled = false;
            tabPages = 2;
            tabControl1.SelectedTab = tabPageBulanan;
        }

        public void selectTabPagePSB()
        {
            //tabPageBulanan.Enabled = false; 
            tabPages = 1;
            tabControl1.SelectedTab = tabPagePSB;
        }

        public int whichTabPage() //1=tabpagepsb , 2=tabpagebulanan
        {
            int page = 0;
            if (tabControl1.SelectedTab == tabPagePSB)
                page = 1;
            else if (tabControl1.SelectedTab == tabPageBulanan)
                page = 2;

            return page;
        }

        private bool cektxtPSB()
        {
            bool temp = true;
            if (edKategoriPSB.Text == "")
            {
                errorProvider1.SetError(edKategoriPSB, "Silahkan isi Nama Kategori Tarif");
                edKategoriPSB.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edKategoriPSB, "");

            if (edBebanPSB.Text == "")
            {
                errorProvider1.SetError(edBebanPSB, "Silahkan isi Beban (VA)");
                edBebanPSB.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edBebanPSB, "");

            if (edUJLPSB.Text == "")
            {
                errorProvider1.SetError(edUJLPSB, "Silahkan isi Biaya UJL (per VA)");
                edUJLPSB.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edUJLPSB, "");

            if (edBiayaSambungPSB.Text == "")
            {
                errorProvider1.SetError(edBiayaSambungPSB, "Silahkan isi Biaya Penyambungan (per VA)");
                edBiayaSambungPSB.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edBiayaSambungPSB, "");

            return temp;
        }

        private bool cektxtBulanan()
        {
            bool temp = true;
            if (edKategoriBulanan.Text == "")
            {
                errorProvider1.SetError(edKategoriBulanan, "Silahkan isi Nama Kategori Tarif");
                edKategoriBulanan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edKategoriBulanan, "");

            if (edBebanBulanan.Text == "")
            {
                errorProvider1.SetError(edBebanBulanan, "Silahkan isi Beban (watt)");
                edBebanBulanan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edBebanBulanan, "");

            if (edBiayaBebanBulanan.Text == "")
            {
                errorProvider1.SetError(edBiayaBebanBulanan, "Silahkan isi Biaya Beban (per 1000 VA)");
                edBiayaBebanBulanan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edBiayaBebanBulanan, "");

            if (edBiayaPemakaianBulanan.Text == "")
            {
                errorProvider1.SetError(edBiayaPemakaianBulanan, "Silahkan isi Biaya Pemakaian (per 1 kwh)");
                edBiayaPemakaianBulanan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edBiayaPemakaianBulanan, "");

            return temp;
        }

        private void clearFormPSB()
        {
            edKategoriPSB.Clear();
            edBebanPSB.Clear();
            edUJLPSB.Clear();
            edBiayaSambungPSB.Clear();
            errorProvider1.Clear();
            tabPagePSB.Enabled = true;
            //tabControl1.SelectedIndex = 0;
        }

        private void clearFormBulanan()
        {
            edKategoriBulanan.Clear();
            edBebanBulanan.Clear();
            edBiayaBebanBulanan.Clear();
            edBiayaPemakaianBulanan.Clear();
            errorProvider1.Clear();
            tabPageBulanan.Enabled = true;
            //tabControl1.SelectedIndex = 0;
        }

        private void edNomor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        public void fillFormPSB(int ID_TARIF, string KATEGORI_TARIF, int BEBAN, int BIAYA_UJL, int BIAYA_SAMBUNG)
        {
            tabPageBulanan.Enabled = false;
            edID.Text = ID_TARIF.ToString();
            edKategoriPSB.Text = KATEGORI_TARIF;
            edBebanPSB.Text = BEBAN.ToString(); ;
            edUJLPSB.Text = BIAYA_UJL.ToString(); ;
            edBiayaSambungPSB.Text = BIAYA_SAMBUNG.ToString(); ;
        }

        public void fillFormBulanan(int ID_TARIF, string KATEGORI_TARIF, int BEBAN, int BIAYA_BEBAN, int BIAYA_PEMAKAIAN)
        {
            tabPagePSB.Enabled = false;
            edID.Text = ID_TARIF.ToString();
            edKategoriBulanan.Text = KATEGORI_TARIF;
            edBebanBulanan.Text = BEBAN.ToString(); ;
            edBiayaBebanBulanan.Text = BIAYA_BEBAN.ToString(); ;
            edBiayaPemakaianBulanan.Text = BIAYA_PEMAKAIAN.ToString(); ;
        }

        private void btnUlang_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPagePSB)
                this.clearFormPSB();
            else if (tabControl1.SelectedTab == tabPageBulanan)
                this.clearFormBulanan();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {   
            this.clearFormPSB();
            this.clearFormBulanan();

            this.Hide();
            TarifUI myParent = (TarifUI)this.Parent;

            if (tabControl1.SelectedTab == tabPagePSB)
            {
                if (btnTambah.Text == "Tambahkan")
                {
                    myParent.EnableAfterInsert(whichTabPage());
                }
                else
                    myParent.EnableAfterEdit(whichTabPage());
            }
            
            if (tabControl1.SelectedTab == tabPageBulanan)
            {
                if (btnTambahPasca.Text == "Tambahkan")
                {
                    myParent.EnableAfterInsert(whichTabPage());
                }
                else
                    myParent.EnableAfterEdit(whichTabPage());
            }
        }

        private void btnTambahEditPSB_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagperintah == 1)
                {
                    if (cektxtPSB() == true)
                    {
                        errorProvider1.Clear();
                        TarifEntity tarif = new TarifEntity(edKategoriPSB.Text, int.Parse(edBebanPSB.Text), int.Parse(edUJLPSB.Text), int.Parse(edBiayaSambungPSB.Text), 1, -1, -1, -1);
                        TControl.entryDataTarifPSB(tarif);
                        clearFormPSB();
                        this.Hide();
                        TarifUI myParent = (TarifUI)this.Parent;
                        myParent.EnableAfterInsert(whichTabPage());
                    }
                }

                else
                {

                    if (cektxtPSB() == true)
                    {
                        errorProvider1.Clear();

                        TarifEntity tarif = new TarifEntity(int.Parse(edID.Text), edKategoriPSB.Text, int.Parse(edBebanPSB.Text), int.Parse(edUJLPSB.Text), int.Parse(edBiayaSambungPSB.Text), 1, -1, -1, -1);

                        DialogResult dr = MessageBox.Show("Apakah anda yakin mengupdate tarif ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dr == DialogResult.Yes)
                        {
                            TControl.editDataTarifPSB(tarif);
                        }
                        clearFormPSB();
                        this.Hide();
                        TarifUI myParent = (TarifUI)this.Parent;
                        myParent.EnableAfterEdit(whichTabPage());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabPages == 1)
            {
                tabControl1.SelectedIndex = 0;
                tabControl1.SelectedTab = tabPagePSB;
            }

            if (tabPages == 2)
            {
                tabControl1.SelectedIndex = 1;
                tabControl1.SelectedTab = tabPageBulanan;
            }
        }

        private void btnTambahEditBulanan_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagperintah == 1)
                {
                    if (cektxtBulanan() == true)
                    {
                        errorProvider1.Clear();
                        TarifEntity tarif = new TarifEntity(edKategoriBulanan.Text, int.Parse(edBebanBulanan.Text), -1, -1, -1, int.Parse(edBiayaBebanBulanan.Text), int.Parse(edBiayaPemakaianBulanan.Text), 1);
                        TControl.entryDataTarifBulanan(tarif);
                        clearFormBulanan();
                        this.Hide();
                        TarifUI myParent = (TarifUI)this.Parent;
                        myParent.EnableAfterInsert(whichTabPage());
                    }
                }

                else
                {

                    if (cektxtBulanan() == true)
                    {
                        errorProvider1.Clear();

                        TarifEntity tarif = new TarifEntity(int.Parse(edID.Text), edKategoriBulanan.Text, int.Parse(edBebanBulanan.Text), -1, -1, -1, int.Parse(edBiayaBebanBulanan.Text), int.Parse(edBiayaPemakaianBulanan.Text), 1);

                        DialogResult dr = MessageBox.Show("Apakah anda yakin mengupdate tarif ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dr == DialogResult.Yes)
                        {
                            TControl.editDataTarifBulanan(tarif);
                        }
                        clearFormBulanan();
                        this.Hide();
                        TarifUI myParent = (TarifUI)this.Parent;
                        myParent.EnableAfterEdit(whichTabPage());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
         

    }
}
