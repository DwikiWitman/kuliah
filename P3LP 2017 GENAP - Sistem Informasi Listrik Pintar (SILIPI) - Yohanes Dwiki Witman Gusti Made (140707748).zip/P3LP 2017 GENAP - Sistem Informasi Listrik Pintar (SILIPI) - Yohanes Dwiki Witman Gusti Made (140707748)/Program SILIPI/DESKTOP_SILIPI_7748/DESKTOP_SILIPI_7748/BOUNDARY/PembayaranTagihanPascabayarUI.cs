﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class PembayaranTagihanPascabayarUI : Form
    {
       PegawaiEntity pegawaiEntity = new PegawaiEntity();
       TagihanPascbayarControl tagihanPascabayarControl = new TagihanPascbayarControl();
       MemberControl memberControl = new MemberControl();
       int selected_id_tagihanpascabayar = 0;

        /* 
         *  SINGLETON FORM 
         */
        private static PembayaranTagihanPascabayarUI instance;
        public static PembayaranTagihanPascabayarUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new PembayaranTagihanPascabayarUI();
                return instance;
            }
        }

        public void setPegawai(PegawaiEntity data_pegawai) { this.pegawaiEntity = data_pegawai; }

        public PembayaranTagihanPascabayarUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public PembayaranTagihanPascabayarUI(PegawaiEntity pegawaiEntity)
        {
            InitializeComponent();
            this.pegawaiEntity = pegawaiEntity;
            WindowState = FormWindowState.Maximized;
        }

        private void PembayaranTagihanPSBUI_Load(object sender, EventArgs e)
        {
            TampilDataMember(this.dataGridView1);
            uC_PembayaranTagihanPascabayar1.Visible = false;
        }

        public void EnableAfterPay()
        {
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            this.btnBayar.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataMember(this.dataGridView1);
            txtID.Text = "0";
        }

        public void TampilDataMember(DataGridView data)
        {
            data.DataSource = memberControl.getDataMemberPascabayar();
            DataTable DT = memberControl.getDataMemberPascabayar();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_MEMBER, NOMOR_KTP, NOMOR_MEMBER, NOMOR_KWH, NAMA_MEMBER, TANGGAL_LAHIR_MEMBER, ALAMAT_INSTALASI, NOMOR_HP_MEMBER, PEKERJAAN, DAYA_LISTRIK, TIPE_MEMBER, STATUS";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_MEMBER";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }

        
        public void TampilDataTagihanPascabayar(DataGridView data)
        {
            data.DataSource = tagihanPascabayarControl.getDataTagihanPascabayar_ByIDMember(int.Parse(txtID.Text));
            DataTable DT = tagihanPascabayarControl.getDataTagihanPascabayar_ByIDMember(int.Parse(txtID.Text));
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_TAGIHAN_PASCABAYAR, ID_MEMBER, ID_TARIF, KWH_SEBELUM, KWH_SESUDAH, BULAN_TAGIHAN, TAHUN_TAGIHAN, TOTAL_TAGIHAN_PASCABAYAR, STATUS_TAGIHAN_PASCABAYAR";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_TAGIHAN_PASCABAYAR, ID_MEMBER, ID_TARIF";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }


        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            //id_tagihan = int.Parse(getKolom(dataGridView2, 0));
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView2.DataSource = null;
            else
                TampilDataTagihanPascabayar(dataGridView2);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            //id_tagihan = int.Parse(getKolom(dataGridView2, 0));
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView2.DataSource = null;
            else
                TampilDataTagihanPascabayar(dataGridView2);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string tagihan = getKolom(dataGridView2, 0);
            this.selected_id_tagihanpascabayar = int.Parse(tagihan);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string tagihan = getKolom(dataGridView2, 0);
            this.selected_id_tagihanpascabayar = int.Parse(tagihan);
        }
        
        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnBayar.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataTagihanPascabayar(dataGridView1);
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = memberControl.searchDataMemberPascabayar(edCari.Text);
                this.dataGridView2.DataSource = tagihanPascabayarControl.searchDataTagihanPascabayar_ByNomorPelanggan_ByNomorKwh(edCari.Text);
            }

            if (edCari.Text.Length <= 0)
            {
                TampilDataMember(this.dataGridView1);
                TampilDataTagihanPascabayar(this.dataGridView2);
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log out?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                LoginUI utama = new LoginUI();
                utama.ShowDialog();
                this.Dispose();
            }
        }

        private void edCari_TextChanged(object sender, EventArgs e)
        {
            if (edCari.Text.Length <= 0)
            {
                TampilDataTagihanPascabayar(this.dataGridView1);
            }
        }


        private void btnBayar_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih member terlebih dahulu!", "Information");
                dataGridView1.Focus();
            }
            else if (selected_id_tagihanpascabayar == 0)
            {
                MessageBox.Show("Silahkan pilih tagihan yang akan dibayar terlebih dahulu!", "Information");
                dataGridView2.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to pay this bill? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
                    DataTable data_tagihan_pascabayar = tagihanPascabayarControl.getDataTagihanPascabayar_ByID(selected_id_tagihanpascabayar);
                   
                    uC_PembayaranTagihanPascabayar1.Enabled = true;
                    uC_PembayaranTagihanPascabayar1.Visible = true;
                    uC_PembayaranTagihanPascabayar1.setDataTagihanPascabayar(pegawaiEntity, data_member, data_tagihan_pascabayar);
                    uC_PembayaranTagihanPascabayar1.BringToFront();

                }
            }
        }

        private void uC_PembayaranTagihanPascabayar1_VisibleChanged(object sender, EventArgs e)
        {
            /*
            uC_PembayaranTagihanPascabayar1.Location = new Point(
            this.ClientSize.Width / 2 - uC_PembayaranTagihanPascabayar1.Size.Width / 2,
            this.ClientSize.Height / 2 - uC_PembayaranTagihanPascabayar1.Size.Height / 2);
            uC_PembayaranTagihanPascabayar1.Anchor = AnchorStyles.None;
             */
            uC_PembayaranTagihanPascabayar1.Dock = DockStyle.Fill; 
        }

    }
}
