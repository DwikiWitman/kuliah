﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class BillingMemberUI : Form
    {
        public BillingMemberUI()
        {
            InitializeComponent();
        }
    }
}
