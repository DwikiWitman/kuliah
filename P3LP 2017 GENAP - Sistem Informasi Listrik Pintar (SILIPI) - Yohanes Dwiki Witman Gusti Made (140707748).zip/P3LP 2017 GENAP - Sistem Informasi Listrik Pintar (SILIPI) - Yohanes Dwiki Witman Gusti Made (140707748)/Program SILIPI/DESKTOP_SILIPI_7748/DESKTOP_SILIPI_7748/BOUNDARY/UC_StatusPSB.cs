﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.CONTROL;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_StatusPSB : UserControl
    {
        DataTable data_member;
        int id_member=0;

        public UC_StatusPSB()
        {
            InitializeComponent();
        }

        public void setDataMember(DataTable data_member)
        {
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblNomorKWH.Text = row["NOMOR_KWH"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            StatusPSBUI myParent = (StatusPSBUI)this.Parent;
            myParent.EnableAfterUpdate();
            this.Visible = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cmbStatus.Text == "")
            {
                MessageBox.Show("Silahkan pilih status pemasangan saat ini!", "Information");
                cmbStatus.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to update status member? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    MemberControl memberControl = new MemberControl();
                    memberControl.updateDataStatusPemasangan(cmbStatus.Text,id_member);

                    MessageBox.Show("Operation update was succesful!", "Information");

                    StatusPSBUI myParent = (StatusPSBUI)this.Parent;
                    myParent.EnableAfterUpdate();
                    this.Enabled = false;
                    this.Visible = false;
                    this.Hide();
                }
            }
        }
    }
}
