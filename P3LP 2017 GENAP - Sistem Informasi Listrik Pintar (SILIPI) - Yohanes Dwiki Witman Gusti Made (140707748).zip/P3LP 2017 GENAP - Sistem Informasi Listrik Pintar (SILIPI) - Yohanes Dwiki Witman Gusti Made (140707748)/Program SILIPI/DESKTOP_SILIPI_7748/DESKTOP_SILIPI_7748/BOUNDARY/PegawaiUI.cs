﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class PegawaiUI : Form
    {
        PegawaiControl PControl = new PegawaiControl();
        PegawaiEntity data_pegawai = new PegawaiEntity();
        /* 
         *  SINGLETON FORM 
         */
        private static PegawaiUI instance;
        public static PegawaiUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new PegawaiUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public PegawaiUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */
        public PegawaiUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.data_pegawai = data_pegawai;
        }

        
        private void PegawaiUI_Load(object sender, EventArgs e)
        {
            TampilDataPegawai(this.dataGridView1);
            uC_Pegawai1.setFlag(1);
            uC_Pegawai1.Visible = false;
        }

        public void TampilDataPegawai(DataGridView data)
        {
            data.DataSource = PControl.getDataFinePegawai();            
            DataTable DT = PControl.getDataFinePegawai();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            //data.Columns.RemoveAt(0);  // remove id_pegawai di datagridview
            //data.Columns.RemoveAt(1);  // remove id_jabatan di fatagridview
            //data.Columns[0].Visible = false;

            data.Columns[0].HeaderText = "ID Pegawai";
            data.Columns[1].HeaderText = "ID Jabatan";
            data.Columns[2].HeaderText = "Nama Lengkap";
            data.Columns[3].HeaderText = "Tgl Lahir";
            data.Columns[4].HeaderText = "Alamat";
            data.Columns[5].HeaderText = "Nomor";
            data.Columns[6].HeaderText = "Username";
            data.Columns[7].HeaderText = "Password";
            data.Columns[8].HeaderText = "Jabatan";
            
            data.Columns[0].Width = 86;
            data.Columns[1].Width = 86;
            data.Columns[2].Width = 200;
            data.Columns[3].Width = 200;
            data.Columns[4].Width = 200;
            data.Columns[5].Width = 95;
            data.Columns[6].Width = 95;
            data.Columns[7].Width = 95;
            data.Columns[8].Width = 95;
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 7 && e.Value != null)
            {
                e.Value = new String('*', e.Value.ToString().Length);
            }
        }

        public void EnableAfterInsert()
        {
            dataGridView1.Enabled = true;
            this.btnTambah.Enabled = true;
            edCari.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;

            TampilDataPegawai(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        public void EnableAfterEdit()
        {
            edCari.Enabled = true;
            dataGridView1.Enabled = true;
            btnTambah.Enabled = true;
            btnHapus.Enabled = true;
            btnUbah.Enabled = true;

            TampilDataPegawai(this.dataGridView1);
            dataGridView1.Rows[0].Selected = false;
            dataGridView1.Rows[int.Parse(txtRow.Text)].Selected = true;
            txtID.Text = getKolomEdit(dataGridView1, int.Parse(txtRow.Text));
        }

        public void EnableAfterDelete()
        {
            dataGridView1.Enabled = true;
            this.btnTambah.Enabled = true;
            edCari.Enabled = true;
            this.btnHapus.Enabled = true;
            this.btnUbah.Enabled = true;

            TampilDataPegawai(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            uC_Pegawai1.Visible = true;
            uC_Pegawai1.BringToFront();
            uC_Pegawai1.btnTambah.Text = "Tambahkan";
            uC_Pegawai1.setFlag(1);
            DisableMainForm();
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnTambah.Enabled = false;
            this.btnHapus.Enabled = false;
            this.btnUbah.Enabled = false;
        }

        private void btnUbah_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih pegawai terlebih dahulu!");
                dataGridView1.Focus();
            }
            else
            {
                uC_Pegawai1.setFlag(2);
                uC_Pegawai1.BringToFront();
                uC_Pegawai1.btnTambah.Text = "Ubah";

                int id_pegawai = int.Parse(txtID.Text);
                int jabatan = int.Parse(getKolom(dataGridView1, 1));
                string nama = getKolom(dataGridView1, 2);
                DateTime tgl_lahir = DateTime.Parse(getKolom(dataGridView1, 3));
                string alamat = getKolom(dataGridView1, 4);
                string hp = getKolom(dataGridView1, 5);
                string username = getKolom(dataGridView1, 6);
                string password = getKolom(dataGridView1, 7);
                
                uC_Pegawai1.fillForm(id_pegawai, jabatan, nama, tgl_lahir, alamat, hp, username, password);
                uC_Pegawai1.Visible = true;
                txtID.Clear();
                DisableMainForm();
            }
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataPegawai(dataGridView1);
        }

        private void btnKeluar_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih pegawai terlebih dahulu!");
                dataGridView1.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Apakah anda yakin menghapus pegawai ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    PControl.deleteDataPegawai(int.Parse(txtID.Text));
                    EnableAfterDelete();
                }
            }
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = PControl.searchDataPegawai(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataPegawai(this.dataGridView1);
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure want to log out?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                LoginUI utama = new LoginUI();
                utama.ShowDialog();
                this.Dispose();
            }
        }

        private void uC_Pegawai1_VisibleChanged(object sender, EventArgs e)
        {
            uC_Pegawai1.Location = new Point(
            this.ClientSize.Width / 2 - uC_Pegawai1.Size.Width / 2,
            this.ClientSize.Height / 2 - uC_Pegawai1.Size.Height / 2);
            uC_Pegawai1.Anchor = AnchorStyles.None;
        }
    }
}