﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.CONTROL;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_DetilTransaksi : UserControl
    {
        PegawaiEntity data_pegawai = new PegawaiEntity();
        DataTable data_member;
        int id_member=0, id_tagihanpascabayar = 0, id_tagihanpsb = 0;

        public UC_DetilTransaksi()
        {
            InitializeComponent();
        }

        public void setDataDetilTransaksiPascabayar(PegawaiEntity data_pegawai, DataTable data_member, DataTable data_tagihanpascabayar, DataTable data_transaksi)
        {
            this.data_pegawai = data_pegawai;
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblNomorKWH.Text = row["NOMOR_KWH"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }


            lbl1.Text = "BULAN_TAGIHAN";
            lbl2.Text = "TAHUN_TAGIHAN";
            lbl3.Text = "KWH_SEBELUM";
            lbl4.Text = "KWH_SESUDAH";
            lbl5.Text = "BEBAN / 1000 VA (Rp.)";
            lbl6.Text = "PEMAKAIAN / VA (Rp.)";
            lbl7.Text = "TOTAL_PEMBAYARAN";
            lbl8.Text = "TANGGAL_PEMBAYARAN";


            TarifControl tarifControl = new TarifControl();

            DataTable data_tarif = tarifControl.getDataTarifPascabayar_ByBeban(int.Parse(lblDayaListrik.Text));
            int biaya_beban = 0, biaya_kwh = 0;

            foreach (DataRow row in data_tagihanpascabayar.Rows)
            {
                id_tagihanpascabayar = int.Parse(row["ID_TAGIHAN_PASCABAYAR"].ToString());
                lbl11.Text = row["BULAN_TAGIHAN"].ToString();
                lbl22.Text = row["TAHUN_TAGIHAN"].ToString();
                lbl33.Text = row["KWH_SEBELUM"].ToString();
                lbl44.Text = row["KWH_SESUDAH"].ToString();
                break;
            }

            foreach (DataRow row in data_transaksi.Rows)
            {
                lbl77.Text = row["TOTAL_PEMBAYARAN"].ToString();
                lbl88.Text = row["TANGGAL_TRANSAKSI"].ToString();
                break;
            }

            foreach (DataRow row in data_tarif.Rows)
            {  
                biaya_beban = int.Parse(row["BIAYA_BEBAN"].ToString());
                biaya_kwh = int.Parse(row["BIAYA_PEMAKAIAN"].ToString());
                break;
            }

            lbl55.Text = ((int.Parse(lblDayaListrik.Text) / 1000) * biaya_beban).ToString();
            lbl66.Text = ((int.Parse(lbl44.Text) - int.Parse(lbl33.Text)) * biaya_beban).ToString();
            
        }



        public void setDataDetilTransaksiPSB(PegawaiEntity data_pegawai, DataTable data_member, DataTable data_tagihanpsb, DataTable data_transaksi)
        {
            this.data_pegawai = data_pegawai;
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblNomorKWH.Text = row["NOMOR_KWH"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }


            lbl1.Text = "TANGGAL_TAGIHAN";
            lbl2.Text = "BIAYA_UJL";
            lbl3.Text = "BIAYA_SAMBUNG";
            lbl4.Text = "TANGGAL_TRANSAKSI";
            lbl5.Text = "TOTAL_PEMBAYARAN";
            lbl6.Text = "STATUS_TAGIHAN";
            lbl7.Text = "";
            lbl77.Text = "";
            lbl8.Text = "";
            lbl88.Text = "";


            TarifControl tarifControl = new TarifControl();

            DataTable data_tarif = tarifControl.getDataTarifPSB_ByBeban(int.Parse(lblDayaListrik.Text));
            int biaya_ujl = 0, biaya_sambung = 0;

            foreach (DataRow row in data_tagihanpsb.Rows)
            {
                id_tagihanpsb = int.Parse(row["ID_TAGIHAN_PERMOHONAN"].ToString());
                lbl11.Text = row["TANGGAL_TAGIHAN_PERMOHONAN"].ToString();
                lbl66.Text = row["STATUS_TAGIHAN_PERMOHOHAN"].ToString();
                break;
            }

            foreach (DataRow row in data_transaksi.Rows)
            {
                lbl55.Text = row["TOTAL_PEMBAYARAN"].ToString();
                lbl44.Text = row["TANGGAL_TRANSAKSI"].ToString();
                break;
            }

            foreach (DataRow row in data_tarif.Rows)
            {
                biaya_ujl = int.Parse(row["BIAYA_UJL"].ToString());
                biaya_sambung = int.Parse(row["BIAYA_SAMBUNG"].ToString());
                break;
            }

            lbl22.Text = (int.Parse(lblDayaListrik.Text)  * biaya_ujl).ToString();
            lbl33.Text = (int.Parse(lblDayaListrik.Text) * biaya_sambung).ToString();

        }




        public void setDataDetilTransaksiToken(PegawaiEntity data_pegawai, DataTable data_member, DataTable data_token, DataTable data_transaksi)
        {
            this.data_pegawai = data_pegawai;
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblNomorKWH.Text = row["NOMOR_KWH"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }


            lbl1.Text = "NOMOR_TOKEN";
            lbl2.Text = "NOMINAL_TOKEN";
            lbl3.Text = "HARGA_TOKEN";
            lbl4.Text = "JUMLAH_TOKEN";
            lbl5.Text = "JENIS";
            lbl6.Text = "TOTAL_PEMBAYARAN";
            lbl7.Text = "CHANNEL_PEMBAYARAN";
            lbl8.Text = "TANGGAL_TRANSAKSI";


            foreach (DataRow row in data_token.Rows)
            {
                lbl11.Text = row["NOMOR_TOKEN"].ToString();
                lbl22.Text = row["NOMINAL_TOKEN"].ToString();
                lbl33.Text = row["HARGA_TOKEN"].ToString();
                break;
            }

            int id_detiltransaksi = 0;
            DetilTransaksiControl detilTransaksiControl = new DetilTransaksiControl();
            
            foreach (DataRow row in data_transaksi.Rows)
            {
                id_detiltransaksi = int.Parse(row["ID_DETIL_TRANSAKSI"].ToString());
                lbl66.Text = row["TOTAL_PEMBAYARAN"].ToString();
                lbl88.Text = row["TANGGAL_TRANSAKSI"].ToString();
                break;
            }

            DataTable data_detiltransaksi = detilTransaksiControl.getDataDetilTransaksiByID(id_detiltransaksi);
            foreach (DataRow row in data_detiltransaksi.Rows)
            {
                lbl55.Text = row["JENIS_TAGIHAN"].ToString();
                lbl77.Text = row["CHANNEL_PEMBAYARAN"].ToString();
                lbl44.Text = row["JUMLAH_TOKEN"].ToString();
                break;
            }

        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            LaporanPSBPDLUI myParent = (LaporanPSBPDLUI)this.Parent;
            myParent.EnableAfterLook();
            this.Visible = false;
        }

        private void edAngkaMeteran_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
