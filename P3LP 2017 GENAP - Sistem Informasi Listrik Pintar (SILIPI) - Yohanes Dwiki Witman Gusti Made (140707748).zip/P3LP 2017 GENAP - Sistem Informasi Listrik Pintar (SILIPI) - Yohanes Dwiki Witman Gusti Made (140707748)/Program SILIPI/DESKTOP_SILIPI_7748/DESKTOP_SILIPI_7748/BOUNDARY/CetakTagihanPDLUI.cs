﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class CetakTagihanPDLUI : Form
    {
        PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();
        PermohonanPDLControl permohonanPDLControl = new PermohonanPDLControl();
        TagihanPSBControl tagihanPSBControl = new TagihanPSBControl();
        TarifControl tarifControl = new TarifControl();
        MemberControl memberControl = new MemberControl();
        PegawaiEntity data_pegawai = new PegawaiEntity();

        /* 
         *  SINGLETON FORM 
         */
        private static CetakTagihanPDLUI instance;
        public static CetakTagihanPDLUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new CetakTagihanPDLUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public CetakTagihanPDLUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public CetakTagihanPDLUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.data_pegawai = data_pegawai;
        }

        private void CetakTagihanPDLUI_Load(object sender, EventArgs e)
        {
            TampilDataPemohonTerverifikasi(this.dataGridView1);
            uC_CetakTagihanPDL1.Visible = false;
            uC_CetakTagihanPDL1.Enabled = false;
        }

        public void TampilDataPemohonTerverifikasi(DataGridView data)
        {
            data.DataSource = permohonanPSBControl.getDataPenerimaanPDL();
            DataTable DT = permohonanPSBControl.getDataPenerimaanPDL();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA, IDENTITAS_PEMOHON, NAMA_PEMOHON, TANGGAL_LAHIR, ALAMAT_PEMOHON, NOMOR_HP_PEMOHON, PEKERJAAN_PEMOHON, DAYA_PERMOHONAN, JENIS_SAMBUNGAN, NOMOR_RESI, TANGGAL_PERMOHONAN, TANGGAL_PERSETUJUAN, TANGGAL_PENOLAKAN, DESKRIPSI, NOMOR_MEMBER";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_PERMOHONAN, ID_PERMOHONAN_TAMBAH_DAYA, ID_KODE_AREA, TANGGAL_PENOLAKAN";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }

        }

        public void EnableAfterPrint()
        {
            dataGridView1.Enabled = true;
            this.btnPrint.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataPemohonTerverifikasi(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnPrint.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                uC_CetakTagihanPDL1.Enabled = true;
                uC_CetakTagihanPDL1.Dispose();     
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataPemohonTerverifikasi(dataGridView1);
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = permohonanPSBControl.searchDataPermohonanPDL(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataPemohonTerverifikasi(this.dataGridView1);
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log out?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                LoginUI utama = new LoginUI();
                utama.ShowDialog();
                this.Dispose();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih pemohon terlebih dahulu!", "Information");
                dataGridView1.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to make a receipt to the selected person?            The receipt will be stored to the database after the receipt is generated.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    int daya_permohonan = 0;
                    int id_permohonan = 0;
                    int id_tarif = 0;
                    int biaya_ujl = 0;
                    int biaya_sambung = 0;
                    int id_permohonan_tambah_daya = 0;
                    double total_ujl = 0.0;
                    double total_penyambungan = 0.0;
                    double total_tagihan = 0.0;
                    string nomor_pelanggan = "";


                    DataTable data_permohonan = new DataTable();
                    data_permohonan = permohonanPSBControl.getDataPermohonanPSB_ByID(int.Parse(txtID.Text));
                    
                    foreach (DataRow row in data_permohonan.Rows)
                    {
                        id_permohonan = int.Parse(row["ID_PERMOHONAN"].ToString());
                        id_permohonan_tambah_daya = int.Parse(row["ID_PERMOHONAN_TAMBAH_DAYA"].ToString());
                        daya_permohonan = int.Parse(row["DAYA_PERMOHONAN"].ToString());
                        break;
                    }

                    nomor_pelanggan = permohonanPDLControl.getNomorPelangganByIDTambahDaya(id_permohonan_tambah_daya);
                    DataTable data_member = new DataTable();
                    data_member = memberControl.getDataMemberByNomorPelanggan(nomor_pelanggan);

                    DataTable data_tarif = tarifControl.getDataTarifPSB_ByBeban(daya_permohonan);
                    uC_CetakTagihanPDL1.Enabled = true;

                    foreach (DataRow row in data_tarif.Rows)
                    {
                        id_tarif = int.Parse(row["ID_TARIF"].ToString());
                        biaya_ujl = int.Parse(row["BIAYA_UJL"].ToString());
                        biaya_sambung = int.Parse(row["BIAYA_SAMBUNG"].ToString());
                        break;
                    }

                    total_ujl = hitung_ujl(daya_permohonan, biaya_ujl);
                    total_penyambungan = hitung_biayaPenyambungan(daya_permohonan, biaya_sambung);
                    total_tagihan = total_ujl + total_penyambungan;

                    Dictionary<string, double> data_tarifTagihan = new Dictionary<string, double>();
                    data_tarifTagihan.Add("total_ujl", total_ujl);
                    data_tarifTagihan.Add("total_penyambungan", total_penyambungan);
                    data_tarifTagihan.Add("total_tagihan", total_tagihan);

                    uC_CetakTagihanPDL1.setDataTagihanPDL(data_pegawai, data_permohonan, data_tarif, data_tarifTagihan, data_member);

                    TagihanPSBEntity tEntity = new TagihanPSBEntity(id_permohonan, data_pegawai.ID_PEGAWAI, id_tarif, (decimal)total_tagihan, GlobalEntity.deskripsiTagihan_1, DateTime.Now);
                    tagihanPSBControl.entryDataTagihanPSB(tEntity);

                    uC_CetakTagihanPDL1.Visible = true;
                    uC_CetakTagihanPDL1.BringToFront();
                }
            }
        }

        private double hitung_ujl(int daya_permohonan, int biaya_ujl)
        {
            return (double) daya_permohonan * biaya_ujl;
        }

        private double hitung_biayaPenyambungan(int daya_permohonan, int biaya_penyambungan)
        {
            return (double) daya_permohonan * biaya_penyambungan;
        }

        private void uC_CetakTagihanPDL1_VisibleChanged(object sender, EventArgs e)
        {
            uC_CetakTagihanPDL1.Dock = DockStyle.Fill;
        }
    }
}
