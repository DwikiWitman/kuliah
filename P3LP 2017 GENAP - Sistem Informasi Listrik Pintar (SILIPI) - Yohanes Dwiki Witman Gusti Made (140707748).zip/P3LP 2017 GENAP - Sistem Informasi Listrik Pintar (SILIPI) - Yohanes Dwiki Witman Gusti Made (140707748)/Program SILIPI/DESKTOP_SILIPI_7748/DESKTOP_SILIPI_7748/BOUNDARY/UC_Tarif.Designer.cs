﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class UC_Tarif
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label8 = new System.Windows.Forms.Label();
            this.edID = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tabPageBulanan = new System.Windows.Forms.TabPage();
            this.btnUlangPasca = new System.Windows.Forms.Button();
            this.btnBatalPasca = new System.Windows.Forms.Button();
            this.btnTambahPasca = new System.Windows.Forms.Button();
            this.edKategoriBulanan = new System.Windows.Forms.TextBox();
            this.edBebanBulanan = new System.Windows.Forms.TextBox();
            this.edBiayaPemakaianBulanan = new System.Windows.Forms.TextBox();
            this.edBiayaBebanBulanan = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPagePSB = new System.Windows.Forms.TabPage();
            this.btnUlang = new System.Windows.Forms.Button();
            this.btnBatal = new System.Windows.Forms.Button();
            this.btnTambah = new System.Windows.Forms.Button();
            this.edKategoriPSB = new System.Windows.Forms.TextBox();
            this.edBebanPSB = new System.Windows.Forms.TextBox();
            this.edBiayaSambungPSB = new System.Windows.Forms.TextBox();
            this.edUJLPSB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.tabPageBulanan.SuspendLayout();
            this.tabPagePSB.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(395, 29);
            this.label8.TabIndex = 50;
            this.label8.Text = "SILIPI - PENGELOLAAN TARIF";
            // 
            // edID
            // 
            this.edID.Location = new System.Drawing.Point(375, 0);
            this.edID.Name = "edID";
            this.edID.Size = new System.Drawing.Size(19, 20);
            this.edID.TabIndex = 44;
            this.edID.Visible = false;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // tabPageBulanan
            // 
            this.tabPageBulanan.Controls.Add(this.btnUlangPasca);
            this.tabPageBulanan.Controls.Add(this.btnBatalPasca);
            this.tabPageBulanan.Controls.Add(this.btnTambahPasca);
            this.tabPageBulanan.Controls.Add(this.edKategoriBulanan);
            this.tabPageBulanan.Controls.Add(this.edBebanBulanan);
            this.tabPageBulanan.Controls.Add(this.edBiayaPemakaianBulanan);
            this.tabPageBulanan.Controls.Add(this.edBiayaBebanBulanan);
            this.tabPageBulanan.Controls.Add(this.label3);
            this.tabPageBulanan.Controls.Add(this.label4);
            this.tabPageBulanan.Controls.Add(this.label5);
            this.tabPageBulanan.Controls.Add(this.label9);
            this.tabPageBulanan.Location = new System.Drawing.Point(4, 22);
            this.tabPageBulanan.Name = "tabPageBulanan";
            this.tabPageBulanan.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBulanan.Size = new System.Drawing.Size(331, 271);
            this.tabPageBulanan.TabIndex = 1;
            this.tabPageBulanan.Text = "Tarif Bulanan";
            this.tabPageBulanan.UseVisualStyleBackColor = true;
            // 
            // btnUlangPasca
            // 
            this.btnUlangPasca.Location = new System.Drawing.Point(125, 214);
            this.btnUlangPasca.Name = "btnUlangPasca";
            this.btnUlangPasca.Size = new System.Drawing.Size(89, 39);
            this.btnUlangPasca.TabIndex = 87;
            this.btnUlangPasca.Text = "Ulang";
            this.btnUlangPasca.UseVisualStyleBackColor = true;
            this.btnUlangPasca.Click += new System.EventHandler(this.btnUlang_Click);
            // 
            // btnBatalPasca
            // 
            this.btnBatalPasca.Location = new System.Drawing.Point(6, 214);
            this.btnBatalPasca.Name = "btnBatalPasca";
            this.btnBatalPasca.Size = new System.Drawing.Size(88, 39);
            this.btnBatalPasca.TabIndex = 86;
            this.btnBatalPasca.Text = "Batal";
            this.btnBatalPasca.UseVisualStyleBackColor = true;
            this.btnBatalPasca.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // btnTambahPasca
            // 
            this.btnTambahPasca.Location = new System.Drawing.Point(239, 214);
            this.btnTambahPasca.Name = "btnTambahPasca";
            this.btnTambahPasca.Size = new System.Drawing.Size(89, 39);
            this.btnTambahPasca.TabIndex = 85;
            this.btnTambahPasca.Text = "Tambahkan";
            this.btnTambahPasca.UseVisualStyleBackColor = true;
            this.btnTambahPasca.Click += new System.EventHandler(this.btnTambahEditBulanan_Click);
            // 
            // edKategoriBulanan
            // 
            this.edKategoriBulanan.Location = new System.Drawing.Point(105, 52);
            this.edKategoriBulanan.MaxLength = 25;
            this.edKategoriBulanan.Name = "edKategoriBulanan";
            this.edKategoriBulanan.Size = new System.Drawing.Size(212, 20);
            this.edKategoriBulanan.TabIndex = 84;
            // 
            // edBebanBulanan
            // 
            this.edBebanBulanan.Location = new System.Drawing.Point(104, 89);
            this.edBebanBulanan.MaxLength = 25;
            this.edBebanBulanan.Name = "edBebanBulanan";
            this.edBebanBulanan.Size = new System.Drawing.Size(213, 20);
            this.edBebanBulanan.TabIndex = 82;
            this.edBebanBulanan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // edBiayaPemakaianBulanan
            // 
            this.edBiayaPemakaianBulanan.Location = new System.Drawing.Point(104, 164);
            this.edBiayaPemakaianBulanan.MaxLength = 50;
            this.edBiayaPemakaianBulanan.Name = "edBiayaPemakaianBulanan";
            this.edBiayaPemakaianBulanan.Size = new System.Drawing.Size(213, 20);
            this.edBiayaPemakaianBulanan.TabIndex = 80;
            this.edBiayaPemakaianBulanan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // edBiayaBebanBulanan
            // 
            this.edBiayaBebanBulanan.Location = new System.Drawing.Point(104, 127);
            this.edBiayaBebanBulanan.MaxLength = 25;
            this.edBiayaBebanBulanan.Name = "edBiayaBebanBulanan";
            this.edBiayaBebanBulanan.Size = new System.Drawing.Size(213, 20);
            this.edBiayaBebanBulanan.TabIndex = 79;
            this.edBiayaBebanBulanan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 83;
            this.label3.Text = "Kategori";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 81;
            this.label4.Text = "Beban (VA)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 78;
            this.label5.Text = "Biaya Pemakaian";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 77;
            this.label9.Text = "Biaya Beban";
            // 
            // tabPagePSB
            // 
            this.tabPagePSB.Controls.Add(this.btnUlang);
            this.tabPagePSB.Controls.Add(this.btnBatal);
            this.tabPagePSB.Controls.Add(this.btnTambah);
            this.tabPagePSB.Controls.Add(this.edKategoriPSB);
            this.tabPagePSB.Controls.Add(this.edBebanPSB);
            this.tabPagePSB.Controls.Add(this.edBiayaSambungPSB);
            this.tabPagePSB.Controls.Add(this.edUJLPSB);
            this.tabPagePSB.Controls.Add(this.label7);
            this.tabPagePSB.Controls.Add(this.label6);
            this.tabPagePSB.Controls.Add(this.label2);
            this.tabPagePSB.Controls.Add(this.label1);
            this.tabPagePSB.Location = new System.Drawing.Point(4, 22);
            this.tabPagePSB.Name = "tabPagePSB";
            this.tabPagePSB.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePSB.Size = new System.Drawing.Size(331, 271);
            this.tabPagePSB.TabIndex = 0;
            this.tabPagePSB.Text = "Tarif PSB";
            this.tabPagePSB.UseVisualStyleBackColor = true;
            // 
            // btnUlang
            // 
            this.btnUlang.Location = new System.Drawing.Point(123, 208);
            this.btnUlang.Name = "btnUlang";
            this.btnUlang.Size = new System.Drawing.Size(89, 39);
            this.btnUlang.TabIndex = 79;
            this.btnUlang.Text = "Ulang";
            this.btnUlang.UseVisualStyleBackColor = true;
            this.btnUlang.Click += new System.EventHandler(this.btnUlang_Click);
            // 
            // btnBatal
            // 
            this.btnBatal.Location = new System.Drawing.Point(4, 208);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(88, 39);
            this.btnBatal.TabIndex = 78;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = true;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // btnTambah
            // 
            this.btnTambah.Location = new System.Drawing.Point(237, 208);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(89, 39);
            this.btnTambah.TabIndex = 77;
            this.btnTambah.Text = "Tambahkan";
            this.btnTambah.UseVisualStyleBackColor = true;
            this.btnTambah.Click += new System.EventHandler(this.btnTambahEditPSB_Click);
            // 
            // edKategoriPSB
            // 
            this.edKategoriPSB.Location = new System.Drawing.Point(103, 46);
            this.edKategoriPSB.MaxLength = 25;
            this.edKategoriPSB.Name = "edKategoriPSB";
            this.edKategoriPSB.Size = new System.Drawing.Size(212, 20);
            this.edKategoriPSB.TabIndex = 76;
            // 
            // edBebanPSB
            // 
            this.edBebanPSB.Location = new System.Drawing.Point(102, 83);
            this.edBebanPSB.MaxLength = 25;
            this.edBebanPSB.Name = "edBebanPSB";
            this.edBebanPSB.Size = new System.Drawing.Size(213, 20);
            this.edBebanPSB.TabIndex = 72;
            this.edBebanPSB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // edBiayaSambungPSB
            // 
            this.edBiayaSambungPSB.Location = new System.Drawing.Point(102, 158);
            this.edBiayaSambungPSB.MaxLength = 50;
            this.edBiayaSambungPSB.Name = "edBiayaSambungPSB";
            this.edBiayaSambungPSB.Size = new System.Drawing.Size(213, 20);
            this.edBiayaSambungPSB.TabIndex = 64;
            this.edBiayaSambungPSB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // edUJLPSB
            // 
            this.edUJLPSB.Location = new System.Drawing.Point(102, 121);
            this.edUJLPSB.MaxLength = 25;
            this.edUJLPSB.Name = "edUJLPSB";
            this.edUJLPSB.Size = new System.Drawing.Size(213, 20);
            this.edUJLPSB.TabIndex = 62;
            this.edUJLPSB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edNomor_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 74;
            this.label7.Text = "Kategori";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 70;
            this.label6.Text = "Beban (VA)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 161);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 55;
            this.label2.Text = "Biaya Sambung";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 52;
            this.label1.Text = "Biaya UJL";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPagePSB);
            this.tabControl1.Controls.Add(this.tabPageBulanan);
            this.tabControl1.Location = new System.Drawing.Point(26, 57);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(339, 297);
            this.tabControl1.TabIndex = 52;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // UC_Tarif
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.edID);
            this.Name = "UC_Tarif";
            this.Size = new System.Drawing.Size(398, 373);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.tabPageBulanan.ResumeLayout(false);
            this.tabPageBulanan.PerformLayout();
            this.tabPagePSB.ResumeLayout(false);
            this.tabPagePSB.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox edID;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPagePSB;
        public System.Windows.Forms.Button btnUlang;
        private System.Windows.Forms.Button btnBatal;
        public System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.TextBox edKategoriPSB;
        private System.Windows.Forms.TextBox edBebanPSB;
        private System.Windows.Forms.TextBox edBiayaSambungPSB;
        private System.Windows.Forms.TextBox edUJLPSB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPageBulanan;
        public System.Windows.Forms.Button btnUlangPasca;
        private System.Windows.Forms.Button btnBatalPasca;
        public System.Windows.Forms.Button btnTambahPasca;
        private System.Windows.Forms.TextBox edKategoriBulanan;
        private System.Windows.Forms.TextBox edBebanBulanan;
        private System.Windows.Forms.TextBox edBiayaPemakaianBulanan;
        private System.Windows.Forms.TextBox edBiayaBebanBulanan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
    }
}
