﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_PermohonanPSB : UserControl
    {
        PermohonanPSBControl PControl = new PermohonanPSBControl();
        KodeAreaControl kodeAreaControl = new KodeAreaControl();
        int flagperintah = 0;

        public UC_PermohonanPSB()
        {
            InitializeComponent();
        }

        public void setFlag(int flag)
        {
            flagperintah = flag;
        }

        private bool cektxt()
        {
            bool temp = true;
            if (!dateTimePickerTglPermohonan.Checked)
            {
                errorProvider1.SetError(dateTimePickerTglPermohonan, "Silahkan isi Tanggal Permohonan");
                dateTimePickerTglPermohonan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(dateTimePickerTglPermohonan, "");

            if (edNama.Text == "")
            {
                errorProvider1.SetError(edNama, "Silahkan isi Nama Pemohon");
                edNama.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edNama, "");

            if (edIdentitas.Text == "")
            {
                errorProvider1.SetError(edIdentitas, "Silahkan isi Identitas Pemohon");
                edIdentitas.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edIdentitas, "");

            if (edAlamat.Text == "")
            {
                errorProvider1.SetError(edAlamat, "Silahkan isi Alamat Pemohon");
                edAlamat.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edAlamat, "");

            if (edRT.Text == "")
            {
                errorProvider1.SetError(edRT, "Silahkan isi RT");
                edRT.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edRT, "");

            if (edRW.Text == "")
            {
                errorProvider1.SetError(edRW, "Silahkan isi RW");
                edRW.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edRW, "");

            if (edKelurahan.Text == "")
            {
                errorProvider1.SetError(edKelurahan, "Silahkan isi Kelurahan");
                edKelurahan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edKelurahan, "");

            if (cmbKecamatan.Text == "")
            {
                errorProvider1.SetError(cmbKecamatan, "Silahkan isi Kecamatan");
                cmbKecamatan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbKecamatan, "");

            if (!dateTimePickerTglLahir.Checked)
            {
                errorProvider1.SetError(dateTimePickerTglLahir, "Silahkan isi Tanggal Lahir Pemohon");
                dateTimePickerTglLahir.Focus();
                temp = false;
            }
            else errorProvider1.SetError(dateTimePickerTglLahir, "");

            if (edNomor.Text == "")
            {
                errorProvider1.SetError(edNomor, "Silahkan isi Nomor HP");
                edNomor.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edNomor, "");

            if (edPekerjaan.Text == "")
            {
                errorProvider1.SetError(edPekerjaan, "Silahkan isi Pekerjaan");
                edPekerjaan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edPekerjaan, "");

            if (cmbDaya.Text == "")
            {
                errorProvider1.SetError(cmbDaya, "Silahkan isi Daya Listrik");
                cmbDaya.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbDaya, "");

            if (cmbJenisPembayaran.Text == "")
            {
                errorProvider1.SetError(cmbJenisPembayaran, "Silahkan isi Jenis Pembayaran");
                cmbJenisPembayaran.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbJenisPembayaran, "");


            return temp;
        }

        private void clearForm()
        {
            edNama.Clear();
            edIdentitas.Clear();
            edAlamat.Clear();
            edRT.Clear();
            edKelurahan.Clear();
            cmbKecamatan.SelectedIndex = -1;
            edNomor.Clear();
            edPekerjaan.Clear();
            errorProvider1.Clear();
            cmbDaya.SelectedIndex = -1;
            cmbJenisPembayaran.SelectedIndex = -1;
            //tabPagePSB.Enabled = true;
            //tabControl1.SelectedIndex = 0;
        }

        private void edNomor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        /*
        public void fillFormPSB(int ID_TARIF, string KATEGORI_TARIF, int BEBAN, int BIAYA_UJL, int BIAYA_SAMBUNG)
        {
            tabPageBulanan.Enabled = false;
            edID.Text = ID_TARIF.ToString();
            edKategoriPSB.Text = KATEGORI_TARIF;
            edBebanPSB.Text = BEBAN.ToString(); ;
            edUJLPSB.Text = BIAYA_UJL.ToString(); ;
            edBiayaSambungPSB.Text = BIAYA_SAMBUNG.ToString(); ;
        }
        */

        private void btnUlang_Click(object sender, EventArgs e)
        {
            this.clearForm();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            this.clearForm();

            this.Hide();
            PermohonanPSBUI myParent = (PermohonanPSBUI)this.Parent;

            if (btnTambah.Text == "Tambahkan")
            {
                myParent.EnableAfterInsert();
            }
            else
            {
                //myParent.EnableAfterEdit();
            }
        }

        private void btnTambahEditPSB_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagperintah == 1)
                {
                    if (cektxt() == true)
                    {
                        errorProvider1.Clear();
                        int kode_area = kodeAreaControl.getDataIDKodeAreaByNamaKecamatan(cmbKecamatan.Text) ;

                        Random rnd = new Random();
                        string resi = "TR"+"-"+
                            DateTime.Now.ToString("dd")+
                            DateTime.Now.ToString("MM")+
                            DateTime.Now.ToString("yy")+
                            "-"+rnd.Next(1, 999);

                        PermohonanPSBEntity permohonan = new PermohonanPSBEntity(kode_area, edIdentitas.Text, edNama.Text, 
                            dateTimePickerTglLahir.Value.Date, edAlamat.Text + " , RT " + edRT.Text + ", RW " + edRW.Text + ", Kelurahan " + edKelurahan.Text + ", Kecamatan " + cmbKecamatan.Text , 
                            edNomor.Text, edPekerjaan.Text,
                            int.Parse(cmbDaya.Text), cmbJenisPembayaran.Text, resi, 
                            dateTimePickerTglPermohonan.Value.Date, GlobalEntity.deskripsiPermohonan_1);
                        PControl.entryDataPermohonanPSB(permohonan);
                        clearForm();
                        this.Hide();
                        PermohonanPSBUI myParent = (PermohonanPSBUI)this.Parent;
                        myParent.EnableAfterInsert();
                    }
                }

                else
                {
                    /*
                    if (cektxtPSB() == true)
                    {
                        errorProvider1.Clear();

                        TarifEntity tarif = new TarifEntity(int.Parse(edID.Text), edKategoriPSB.Text, int.Parse(edBebanPSB.Text), int.Parse(edUJLPSB.Text), int.Parse(edBiayaSambungPSB.Text), 1, -1, -1, -1);

                        DialogResult dr = MessageBox.Show("Apakah anda yakin mengupdate tarif ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dr == DialogResult.Yes)
                        {
                            PControl.editDataTarifPSB(tarif);
                        }
                        clearFormPSB();
                        this.Hide();
                        TarifUI myParent = (TarifUI)this.Parent;
                        myParent.EnableAfterEdit(whichTabPage());
                    }
                    */
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbKecamatan_DropDown(object sender, EventArgs e)
        {
            DataTable dt = PControl.getNamaKecamatan();
            cmbKecamatan.DataSource = dt;
            cmbKecamatan.DisplayMember = "NAMA_KECAMATAN";
            cmbKecamatan.ValueMember = "ID_KECAMATAN";
        }
    }
}
