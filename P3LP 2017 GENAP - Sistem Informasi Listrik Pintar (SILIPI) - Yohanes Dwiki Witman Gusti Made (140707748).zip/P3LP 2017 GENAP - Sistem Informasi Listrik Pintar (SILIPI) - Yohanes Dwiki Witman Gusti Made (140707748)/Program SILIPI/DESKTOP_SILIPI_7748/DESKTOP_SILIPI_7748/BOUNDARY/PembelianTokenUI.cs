﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class PembelianTokenUI : Form
    {
        PegawaiEntity data_pegawai = new PegawaiEntity();
        MemberControl memberControl = new MemberControl();
        Random random = new Random();

        /* 
         *  SINGLETON FORM 
         */
        private static PembelianTokenUI instance;
        public static PembelianTokenUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new PembelianTokenUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public PembelianTokenUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public PembelianTokenUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.data_pegawai = data_pegawai;
        }

        private void PembelianTokenUI_Load(object sender, EventArgs e)
        {
            TampilDataMember(this.dataGridView1);
            uC_CetakStrukToken1.Visible = false;
            uC_CetakStrukToken1.Enabled = false;
        }

        public void TampilDataMember(DataGridView data)
        {
            data.DataSource = memberControl.getDataMemberPrabayar();
            DataTable DT = memberControl.getDataMemberPrabayar();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_MEMBER, NOMOR_KTP, NOMOR_MEMBER, NOMOR_KWH, NAMA_MEMBER, TANGGAL_LAHIR_MEMBER, ALAMAT_INSTALASI, NOMOR_HP_MEMBER, PEKERJAAN, DAYA_LISTRIK, TIPE_MEMBER, STATUS";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_MEMBER";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }

        public void EnableAfterPay()
        {
            dataGridView1.Enabled = true;
            this.btnTambah.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataMember(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = "";
            }
        }

        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);

            DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
            foreach (DataRow row in data_member.Rows)
            {
                lblNomorPelanggan.Text = row["NOMOR_MEMBER"].ToString();
                break;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);

            DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
            foreach (DataRow row in data_member.Rows)
            {
                lblNomorPelanggan.Text = row["NOMOR_MEMBER"].ToString();
                break;
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnTambah.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        public void EnableAfterPrint()
        {
            dataGridView1.Enabled = true;
            this.btnTambah.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataMember(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = "";
            }
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataMember(dataGridView1);
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = memberControl.searchDataMemberPrabayar(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataMember(this.dataGridView1);
            }
        }


        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabControl1.TabPages["tabPageCetakStruk"])
            {
                if (txtID.Text == "")
                {
                    MessageBox.Show("Silahkan pilih Member terlebih dahulu!", "Information");
                    dataGridView1.Focus();
                }
                else
                {

                }
            }


            else if (tabControl1.SelectedTab == tabControl1.TabPages["tabPagePembelianToken"])
            {
                if (txtID.Text == "")
                {
                    MessageBox.Show("Silahkan pilih Member terlebih dahulu!", "Information");
                    dataGridView1.Focus();
                }
                else if (cmbNominalToken.Text == "")
                {
                    MessageBox.Show("Silahkan pilih nominal token!", "Information");
                    cmbNominalToken.Focus();
                }
                else if (edUang.Text == "")
                {
                    MessageBox.Show("Silahkan masukkan uang pelanggan!", "Information");
                    edUang.Focus();
                }
                else if (edUang.Text == "")
                {
                    MessageBox.Show("Silahkan masukkan uang pelanggan!", "Information");
                    edUang.Focus();
                }
                else if ((decimal.Parse(edUang.Text) < decimal.Parse(lblHargaToken.Text)))
                {
                    MessageBox.Show("Uang pemohon kurang dari Total Tagihan!", "Information");
                    edUang.Focus();
                }
                else
                {
                    DialogResult dr = MessageBox.Show("Are you sure you want to buy the token? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (dr == DialogResult.Yes)
                    {
                        TransaksiControl transaksiControl = new TransaksiControl();
                        DetilTransaksiControl detiltransaksiControl = new DetilTransaksiControl();
                        TokenControl tokenControl = new TokenControl();

                        DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
                        string jenis_member = "";
                        foreach (DataRow row in data_member.Rows)
                        {
                            jenis_member = row["TIPE_MEMBER"].ToString();
                            break;
                        }

                        DetilTransaksiEntity detiltransaksiEntity = new DetilTransaksiEntity(jenis_member, GlobalEntity.channelPembayaran_1, int.Parse(cmbJumlahToken.Text));
                        detiltransaksiControl.entryDataDetilTransaksiToken(detiltransaksiEntity);
                        int id_detail_transaksi = detiltransaksiControl.getLastIDDetilTransaksi();

                        Dictionary<int, string> nomor_token_dict = new Dictionary<int, string>();
                        string nomor_concat = ""; int dayaToken; string nomor_random = "";
                        var random = new Random();

                        for (int i = 1; i <= int.Parse(cmbJumlahToken.Text); i++)
                        {
                            nomor_random = RandomDigits(11);
                            nomor_token_dict.Add(i, nomor_random);
                            if (i < int.Parse(cmbJumlahToken.Text))
                                nomor_concat += nomor_random + ",";
                            else
                                nomor_concat += nomor_random;
                        }

                        if (int.Parse(cmbNominalToken.SelectedValue.ToString()) == 20000)
                            dayaToken = 25;
                        else if (int.Parse(cmbNominalToken.SelectedValue.ToString()) == 50000)
                            dayaToken = 50;
                        else if (int.Parse(cmbNominalToken.SelectedValue.ToString()) == 100000)
                            dayaToken = 75;
                        else if (int.Parse(cmbNominalToken.SelectedValue.ToString()) == 500000)
                            dayaToken = 375;
                        else if (int.Parse(cmbNominalToken.SelectedValue.ToString()) == 1000000)
                            dayaToken = 750;
                        else
                            dayaToken = 0;

                        TokenEntity tokenEntity = new TokenEntity(nomor_concat, int.Parse(cmbNominalToken.SelectedValue.ToString()), int.Parse(cmbNominalToken.SelectedValue.ToString()));
                        tokenControl.entryDataToken(tokenEntity);
                        int id_token = tokenControl.getLastIDToken();

                        TransaksiEntity transaksiEntity = new TransaksiEntity(id_token, int.Parse(txtID.Text), data_pegawai.ID_PEGAWAI, DateTime.Now.Date, decimal.Parse(lblHargaToken.Text));
                        transaksiEntity.ID_DETIL_TRANSAKSI = id_detail_transaksi;
                        transaksiControl.entryDataTransaksiToken(transaksiEntity);
                        
                        MessageBox.Show("Your payment was succesful!  Kembalian Rp." + (Decimal.Parse(edUang.Text) - Decimal.Parse(lblHargaToken.Text)).ToString(), "Information");

                        uC_CetakStrukToken1.Enabled = true;
                        uC_CetakStrukToken1.setDataStruk(data_pegawai, data_member, nomor_token_dict, decimal.Parse(lblHargaToken.Text), dayaToken);
                        uC_CetakStrukToken1.Visible = true;
                        uC_CetakStrukToken1.BringToFront();
                    }
                }
            } 
        }

        private void cmbNominalToken_DropDown(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("NOMINAL");
            dt.Columns.Add("HARGA");

            var row = dt.NewRow();          
            row["NOMINAL"] = "";
            row["HARGA"] = 0;

            row = dt.NewRow();
            row["NOMINAL"] = "Rp. 20.000,-";
            row["HARGA"] = 20000;
            dt.Rows.Add(row);

            row = dt.NewRow();
            row["NOMINAL"] = "Rp. 50.000,-";
            row["HARGA"] = 50000;
            dt.Rows.Add(row);

            row = dt.NewRow();
            row["NOMINAL"] = "Rp. 100.000,-";
            row["HARGA"] = 100000;
            dt.Rows.Add(row);

            row = dt.NewRow();
            row["NOMINAL"] = "Rp. 500.000,-";
            row["HARGA"] = 500000;
            dt.Rows.Add(row);

            row = dt.NewRow();
            row["NOMINAL"] = "Rp. 1.000.000,-";
            row["HARGA"] = 1000000;
            dt.Rows.Add(row);

            cmbNominalToken.DataSource = dt;
            cmbNominalToken.DisplayMember = "NOMINAL";
            cmbNominalToken.ValueMember = "HARGA";
        }


        public string RandomDigits(int length)
        {
            string s = string.Empty;
            for (int i = 0; i < length; i++)
                s = String.Concat(s, random.Next(10).ToString());
            return s;
        }


        private void cmbJumlahToken_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNominalToken.SelectedItem == null)
            {
                lblHargaToken.Text = "0";
            }
            else
            {
                int nominal_token = int.Parse(cmbNominalToken.SelectedValue.ToString());
                int jumlah_token = int.Parse(cmbJumlahToken.Text);
                lblHargaToken.Text = (nominal_token * jumlah_token).ToString();
            }
        }

        private void edUang_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabControl1.TabPages["tabPageCetakStruk"])
            {
                btnTambah.Text = "Cetak Struk Token";
                btnTambah.Image = (System.Drawing.Image)(Properties.Resources.Image_printer);
            }
            else if (tabControl1.SelectedTab == tabControl1.TabPages["tabPagePembelianToken"])
            {
                btnTambah.Text = "Lakukan Pembayaran";
                btnTambah.Image = (System.Drawing.Image)(Properties.Resources.Image_hand_streched_money_dollar_outline);
            }
        }

        private void cmbNominalToken_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbJumlahToken.SelectedItem == null)
            {
                lblHargaToken.Text = "0";
            }
            else
            {
                int nominal_token = int.Parse(cmbNominalToken.SelectedValue.ToString());
                int jumlah_token = int.Parse(cmbJumlahToken.Text);
                lblHargaToken.Text = (nominal_token * jumlah_token).ToString();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView2, 0);
            txtRow.Text = getRow(dataGridView2);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView2, 0);
            txtRow.Text = getRow(dataGridView2);
        }

        private void edCari_CetakStruk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView2.DataSource = memberControl.searchDataMember(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataMember(this.dataGridView2);
            }
        }
    }
}
