﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_CetakTagihanPSB : UserControl
    {
        CetakTagihanPSB cetakTagihanPSB;

        public UC_CetakTagihanPSB()
        {
            InitializeComponent();
        }

        public void setDataTagihanPSB(PegawaiEntity data_pegawai, DataTable data_permohonan, DataTable data_tarif, Dictionary<string, double> data_tarifTagihan)
        {
            cetakTagihanPSB = new CetakTagihanPSB();
            cetakTagihanPSB.SetDataSource(data_permohonan);

            foreach (DataRow row in data_tarif.Rows)
            {
                cetakTagihanPSB.SetParameterValue("kategoriPermohonanTarif", row["KATEGORI_TARIF"].ToString());
                cetakTagihanPSB.SetParameterValue("bebanTarif", row["BEBAN"].ToString());
                cetakTagihanPSB.SetParameterValue("biayaUJL", row["BIAYA_UJL"].ToString());
                cetakTagihanPSB.SetParameterValue("biayaSambung", row["BIAYA_SAMBUNG"].ToString());
                break;
            }

            cetakTagihanPSB.SetParameterValue("idPegawai", data_pegawai.ID_PEGAWAI);
            cetakTagihanPSB.SetParameterValue("namaPegawai", data_pegawai.NAMA_PEGAWAI);
            cetakTagihanPSB.SetParameterValue("totalBiayaUJL", data_tarifTagihan["total_ujl"]);
            cetakTagihanPSB.SetParameterValue("totalBiayaSambung", data_tarifTagihan["total_penyambungan"]);
            cetakTagihanPSB.SetParameterValue("totalTagihan", data_tarifTagihan["total_tagihan"]);

            crystalReportViewer1.ReportSource = cetakTagihanPSB;
            crystalReportViewer1.Show();
            crystalReportViewer1.Refresh();
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            cetakTagihanPSB.Dispose();

            CetakTagihanPSBUI myParent = (CetakTagihanPSBUI)this.Parent;
            myParent.EnableAfterPrint();
            this.Enabled = false;
            this.Visible = false;
            this.Hide();
        }



    }
}
