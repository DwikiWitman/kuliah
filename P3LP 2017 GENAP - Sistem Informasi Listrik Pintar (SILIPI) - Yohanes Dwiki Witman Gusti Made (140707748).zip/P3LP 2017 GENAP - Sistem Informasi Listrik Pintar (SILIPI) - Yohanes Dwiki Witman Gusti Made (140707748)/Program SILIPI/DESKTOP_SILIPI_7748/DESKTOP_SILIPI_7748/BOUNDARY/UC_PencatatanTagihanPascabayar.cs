﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.CONTROL;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_PencatatanTagihanPascabayar : UserControl
    {
        PegawaiEntity data_pegawai = new PegawaiEntity();
        TagihanPascbayarControl tagihanPascabayarControl = new TagihanPascbayarControl();
        DataTable data_member;
        int id_member=0;

        public UC_PencatatanTagihanPascabayar()
        {
            InitializeComponent();
        }

        public void setDataTagihanPascabayar(PegawaiEntity data_pegawai, DataTable data_member)
        {
            this.data_pegawai = data_pegawai;
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }
            
            lblKwhBulanLalu.Text = tagihanPascabayarControl.getDataMeteranBulanLalu_ByIDMember(id_member).ToString();
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            PencatatanTagihanPascabayarUI myParent = (PencatatanTagihanPascabayarUI)this.Parent;
            myParent.EnableAfterEntryData();
            this.Enabled = false;
            this.Visible = false;
            this.Hide();
        }

        private void edAngkaMeteran_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (edAngkaMeteran.Text == "")
            {
                MessageBox.Show("Silahkan masukkan angka di meteran pelanggan terlebih dahulu!", "Information");
                edAngkaMeteran.Focus();
            }
            else if (cmbBulan.Text == "")
            {
                MessageBox.Show("Silahkan isi bulan tagihan!", "Information");
                cmbBulan.Focus();
            }
            else if (cmbTahun.Text == "")
            {
                MessageBox.Show("Silahkan isi tahun tagihan!", "Information");
                cmbTahun.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to add this monthly-bill? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);



                if (dr == DialogResult.Yes && (int.Parse(lblKwhBulanLalu.Text) < int.Parse(edAngkaMeteran.Text)))
                {
                    TarifControl tarifControl = new TarifControl();

                    DataTable data_tarif = tarifControl.getDataTarifPascabayar_ByBeban(int.Parse(lblDayaListrik.Text));
                    int id_tarif = 0, biaya_beban = 0, biaya_kwh = 0;

                    foreach (DataRow row in data_tarif.Rows)
                    {
                        id_tarif = int.Parse(row["ID_TARIF"].ToString());
                        biaya_beban = int.Parse(row["BIAYA_BEBAN"].ToString());
                        biaya_kwh = int.Parse(row["BIAYA_PEMAKAIAN"].ToString());
                        break;
                    }

                    int kwh_bulan_lalu = int.Parse(lblKwhBulanLalu.Text);

                    int total_biaya_beban = (int.Parse(lblDayaListrik.Text) / 1000) * biaya_beban;
                    int total_biaya_pemakaian = (int.Parse(edAngkaMeteran.Text) - kwh_bulan_lalu) * biaya_kwh;
                    int total_biaya_tagihan = total_biaya_beban + total_biaya_pemakaian;

                    TagihanPascabayarEntity tagihanPascabayarEntity = new TagihanPascabayarEntity(id_member, id_tarif, kwh_bulan_lalu, int.Parse(edAngkaMeteran.Text), cmbBulan.Text, int.Parse(cmbTahun.Text), total_biaya_tagihan, GlobalEntity.deskripsiTagihan_1);
                    tagihanPascabayarControl.entryDataTagihanPascabayar(tagihanPascabayarEntity);

                    
                }
                else
                {
                    MessageBox.Show("Gagal! Kwh Sekarang lebih besar dari Kwh Sebelumnya!", "Warning");
                    edAngkaMeteran.Focus();
                }
            }
        }

        private void cmbTahun_DropDown(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ANGKA_TAHUN");

            for (int i = 0; i < 3; i++)
            {
                var row = dt.NewRow();
                row["ANGKA_TAHUN"] = int.Parse(DateTime.Now.ToString("yyyy"))+i;
                dt.Rows.Add(row);
            }

            cmbTahun.DataSource = dt;
            cmbTahun.DisplayMember = "ANGKA_TAHUN";
            cmbTahun.ValueMember = "ANGKA_TAHUN";
        }

    }
}
