﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class DashboardManagerUI : Form
    {
        PegawaiEntity Pegawai = new PegawaiEntity();
        PegawaiControl PC = new PegawaiControl();

        LaporanPSBPDLUI laporanPSBPDL;

        public DashboardManagerUI(PegawaiEntity Pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.Pegawai = Pegawai;
        }

        private void DashboardManagerUI_Load(object sender, EventArgs e)
        {
            labelNama.Text = Pegawai.NAMA_PEGAWAI;
            labelJabatan.Text = PC.getNamaJabatan(Pegawai.ID_JABATAN);
            labelUsername.Text = Pegawai.USERNAME_PEGAWAI;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labelWaktu.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log-off?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Hide();
                LoginUI login = new LoginUI();
                login.ShowDialog();
                this.Close();
            }
        }

        private void buttonPegawaiUI_Click(object sender, EventArgs e)
        {
            PegawaiUI pegawaiForm = new PegawaiUI();
            pegawaiForm.MdiParent = this;
            pegawaiForm.Show();
            tableLayoutPanelIcon_Utama.SendToBack();
            pegawaiForm.BringToFront();
        }

        private void pictureBoxControl_Click(object sender, EventArgs e)
        {
            if (tableLayoutPanelWord_Utama.Visible == true)
            {
                tableLayoutPanelWord_Utama.Hide();
                pictureBoxControl.Image = DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_left_circle;
            }
            else if (tableLayoutPanelWord_Utama.Visible == false)
            {
                tableLayoutPanelWord_Utama.Show();
                pictureBoxControl.Image = DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_right_circle;
            }
        }

        private void pictureBoxExit_MouseHover(object sender, EventArgs e)
        {
            pictureBoxExit.BackColor = Color.FromArgb(0, 192, 0);
            Size size = new Size(45, 65);
            pictureBoxExit.Size = size;
        }

        private void pictureBoxExit_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxExit.BackColor = Color.LimeGreen;
            Size size = new Size(32, 57);
            pictureBoxExit.Size = size;
        }

        private void pictureBoxControl_MouseHover(object sender, EventArgs e)
        {
            pictureBoxControl.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxControl_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxControl.BackColor = Color.LimeGreen;
        }

        private void pictureBoxIndetitasPegawai_MouseHover(object sender, EventArgs e)
        {
            pictureBoxIndetitasPegawai.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxIndetitasPegawai_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxIndetitasPegawai.BackColor = Color.LimeGreen;
        }

        private void pictureBoxPengelolaanPegawai_Click(object sender, EventArgs e)
        {
            buttonPegawaiUI_Click(sender, e);
        }

        private void pictureBoxPengelolaanPegawai_MouseHover(object sender, EventArgs e)
        {
            pictureBoxPengelolaanPegawai.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxPengelolaanPegawai_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxPengelolaanPegawai.BackColor = Color.LimeGreen;
        }

        
        private void buttonLaporan_Click(object sender, EventArgs e)
        {
            laporanPSBPDL = LaporanPSBPDLUI.GetForm;
            if (laporanPSBPDL != null)
            {
                laporanPSBPDL.setPegawai(Pegawai);
                laporanPSBPDL.MdiParent = this;
                laporanPSBPDL.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                laporanPSBPDL.BringToFront();
            }
        }
    }
}
