﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_CetakStrukToken : UserControl
    {
        CetakStrukToken cetakStrukToken;

        public UC_CetakStrukToken()
        {
            InitializeComponent();
        }

        public void setDataStruk(PegawaiEntity data_pegawai, DataTable data_member, Dictionary<int, string> nomor_token_dict, decimal total_harga, int dayaToken)
        {
            cetakStrukToken = new CetakStrukToken();
            
            cetakStrukToken.SetParameterValue("namaPegawai", data_pegawai.NAMA_PEGAWAI);

            foreach (DataRow row in data_member.Rows)
            {
                cetakStrukToken.SetParameterValue("nomorPelanggan", row["NOMOR_MEMBER"].ToString());
                cetakStrukToken.SetParameterValue("nomorKWH", row["NOMOR_KWH"].ToString());
                cetakStrukToken.SetParameterValue("namaPelanggan", row["NAMA_MEMBER"].ToString());
                break;
            }

            for (int i = 1; i <= 5; i++)
            {
                if (i <= nomor_token_dict.Count)
                    cetakStrukToken.SetParameterValue("nomorToken"+i , nomor_token_dict[i]);
                else
                    cetakStrukToken.SetParameterValue("nomorToken"+i, "-");
            }
            
            cetakStrukToken.SetParameterValue("totalHarga", total_harga);
            cetakStrukToken.SetParameterValue("dayaToken", dayaToken);

            crystalReportViewer1.ReportSource = cetakStrukToken;
            crystalReportViewer1.Show();
            crystalReportViewer1.Refresh();
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            cetakStrukToken.Dispose();

            PembelianTokenUI myParent = (PembelianTokenUI)this.Parent;
            myParent.EnableAfterPrint();
            this.Enabled = false;
            this.Visible = false;
            this.Hide();
        }
    }
}
