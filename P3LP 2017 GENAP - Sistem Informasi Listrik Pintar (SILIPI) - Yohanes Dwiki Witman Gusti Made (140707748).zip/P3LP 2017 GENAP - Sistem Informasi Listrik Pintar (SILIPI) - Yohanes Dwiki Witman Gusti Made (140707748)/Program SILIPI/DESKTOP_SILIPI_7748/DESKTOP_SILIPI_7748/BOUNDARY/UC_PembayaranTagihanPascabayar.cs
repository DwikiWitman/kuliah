﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.CONTROL;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_PembayaranTagihanPascabayar : UserControl
    {
        PegawaiEntity data_pegawai = new PegawaiEntity();
        DataTable data_member;
        int id_member=0,id_tagihanpascabayar = 0;

        public UC_PembayaranTagihanPascabayar()
        {
            InitializeComponent();
        }

        public void setDataTagihanPascabayar(PegawaiEntity data_pegawai, DataTable data_member, DataTable data_tagihanpascabayar)
        {
            this.data_pegawai = data_pegawai;
            this.data_member = data_member;

            foreach (DataRow row in data_member.Rows)
            {
                id_member = int.Parse(row["ID_MEMBER"].ToString());
                lblNomorMember.Text = row["NOMOR_MEMBER"].ToString();
                lblNomorKWH.Text = row["NOMOR_KWH"].ToString();
                lblIdentitas.Text = row["NOMOR_KTP"].ToString();
                lblNama.Text = row["NAMA_MEMBER"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_MEMBER"].ToString();
                lblAlamat.Text = row["ALAMAT_INSTALASI"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_MEMBER"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN"].ToString();
                lblDayaListrik.Text = row["DAYA_LISTRIK"].ToString();
                lblJenisMember.Text = row["TIPE_MEMBER"].ToString();
                break;
            }

            TarifControl tarifControl = new TarifControl();
            TagihanPascbayarControl tagihanPascabayarControl = new TagihanPascbayarControl();

            DataTable data_tarif = tarifControl.getDataTarifPascabayar_ByBeban(int.Parse(lblDayaListrik.Text));
            int biaya_beban = 0, biaya_kwh = 0;

            foreach (DataRow row in data_tagihanpascabayar.Rows)
            {
                id_tagihanpascabayar = int.Parse(row["ID_TAGIHAN_PASCABAYAR"].ToString());
                lblBulan.Text = row["BULAN_TAGIHAN"].ToString();
                lblTahun.Text = row["TAHUN_TAGIHAN"].ToString();
                lblKWHSebelum.Text = row["KWH_SEBELUM"].ToString();
                lblKWHSesudah.Text = row["KWH_SESUDAH"].ToString();
                lblTotalTagihan.Text = row["TOTAL_TAGIHAN_PASCABAYAR"].ToString();
            }

            foreach (DataRow row in data_tarif.Rows)
            {  
                biaya_beban = int.Parse(row["BIAYA_BEBAN"].ToString());
                biaya_kwh = int.Parse(row["BIAYA_PEMAKAIAN"].ToString());
                break;
            }

            lblTotalBiayaBeban.Text = ((int.Parse(lblDayaListrik.Text) / 1000) * biaya_beban).ToString();
            lblTotalBiayaPemakaian.Text = ((int.Parse(lblKWHSesudah.Text) - int.Parse(lblKWHSebelum.Text)) * biaya_beban).ToString();
            
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            PembayaranTagihanPascabayarUI myParent = (PembayaranTagihanPascabayarUI)this.Parent;
            myParent.EnableAfterPay();
            this.Visible = false;
        }

        private void edAngkaMeteran_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            if (edUang.Text == "")
            {
                MessageBox.Show("Silahkan masukkan uang pelanggan terlebih dahulu!", "Information");
                edUang.Focus();
            }
            else if ((decimal.Parse(edUang.Text) < decimal.Parse(lblTotalTagihan.Text)))
            {
                MessageBox.Show("Uang pelanggan kurang dari Total Tagihan!", "Information");
                edUang.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to pay the bill? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    TransaksiControl transaksiControl = new TransaksiControl();
                    DetilTransaksiControl detiltransaksiControl = new DetilTransaksiControl();
                    TagihanPascbayarControl tagihanPascabayarControl = new TagihanPascbayarControl();

                    TransaksiEntity transaksiEntity = new TransaksiEntity(id_tagihanpascabayar, this.id_member, data_pegawai.ID_PEGAWAI, DateTime.Now.Date, decimal.Parse(lblTotalTagihan.Text));
                    DetilTransaksiEntity detiltransaksiEntity = new DetilTransaksiEntity(lblJenisMember.Text, GlobalEntity.channelPembayaran_1);
                    
                    detiltransaksiControl.entryDataDetilTransaksi(detiltransaksiEntity);
                    int id_detail_transaksi = detiltransaksiControl.getLastIDDetilTransaksi();
                    transaksiEntity.ID_DETIL_TRANSAKSI = id_detail_transaksi;
                    transaksiControl.entryDataTransaksiPascabayar(transaksiEntity);

                    tagihanPascabayarControl.updateDataTagihanPascabayar(GlobalEntity.deskripsiTagihan_2, id_tagihanpascabayar);
                    MessageBox.Show("Your payment was succesful!  Kembalian Rp." + (Decimal.Parse(edUang.Text) - Decimal.Parse(lblTotalTagihan.Text)).ToString(), "Information");

                    PembayaranTagihanPascabayarUI myParent = (PembayaranTagihanPascabayarUI)this.Parent;
                    myParent.EnableAfterPay();
                    this.Enabled = false;
                    this.Visible = false;
                    this.Hide();
                }
            }
        }
    }
}
