﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class CetakTagihanPSBUI : Form
    {
        PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();
        TagihanPSBControl tagihanPSBControl = new TagihanPSBControl();
        TarifControl tarifControl = new TarifControl();
        PegawaiEntity data_pegawai = new PegawaiEntity();

        /* 
         *  SINGLETON FORM 
         */
        private static CetakTagihanPSBUI instance;
        public static CetakTagihanPSBUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new CetakTagihanPSBUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public CetakTagihanPSBUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public CetakTagihanPSBUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.data_pegawai = data_pegawai;
        }

        private void CetakTagihanPSBUI_Load(object sender, EventArgs e)
        {
            TampilDataPemohonTerverifikasi(this.dataGridView1);
            uC_CetakTagihanPSB1.Visible = false;
            uC_CetakTagihanPSB1.Enabled = false;
        }

        public void TampilDataPemohonTerverifikasi(DataGridView data)
        {
            data.DataSource = permohonanPSBControl.getDataPenerimaanPSB();
            DataTable DT = permohonanPSBControl.getDataPenerimaanPSB();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            //data.Columns.RemoveAt(0);  // remove col 0 di datagridview
            //data.Columns.RemoveAt(1);  // remove col 1 di fatagridview
            //data.Columns[0].Visible = false; // hide col 0 di datagridview

            data.Columns[0].HeaderText = "ID_PERMOHONAN";
            data.Columns[1].HeaderText = "ID_PERMOHONAN_TAMBAH_DAYA";
            data.Columns[2].HeaderText = "ID_KODE_AREA";
            data.Columns[3].HeaderText = "IDENTITAS_PEMOHON";
            data.Columns[4].HeaderText = "NAMA_PEMOHON";
            data.Columns[5].HeaderText = "TANGGAL_LAHIR";
            data.Columns[6].HeaderText = "ALAMAT_PEMOHON";
            data.Columns[7].HeaderText = "NOMOR_HP_PEMOHON";
            data.Columns[8].HeaderText = "PEKERJAAN_PEMOHON";
            data.Columns[9].HeaderText = "DAYA_PERMOHONAN";
            data.Columns[10].HeaderText = "JENIS_SAMBUNGAN";
            data.Columns[11].HeaderText = "NOMOR_RESI";
            data.Columns[12].HeaderText = "TANGGAL_PERMOHONAN";
            data.Columns[13].HeaderText = "TANGGAL_PERSETUJUAN";
            data.Columns[14].HeaderText = "TANGGAL_PENOLAKAN";
            data.Columns[15].HeaderText = "DESKRIPSI";


            data.Columns[0].Width = 86;
            data.Columns[1].Width = 150;
            data.Columns[2].Width = 150;
            data.Columns[3].Width = 150;
            data.Columns[4].Width = 150;
            data.Columns[5].Width = 150;
            data.Columns[6].Width = 150;
            data.Columns[7].Width = 150;
            data.Columns[8].Width = 150;
            data.Columns[9].Width = 150;
            data.Columns[10].Width = 150;
            data.Columns[11].Width = 150;
            data.Columns[12].Width = 150;
            data.Columns[13].Width = 150;
            data.Columns[14].Width = 150;
            data.Columns[15].Width = 150;


            data.Columns[0].Visible = false;
            data.Columns[1].Visible = false;
            data.Columns[2].Visible = false;
            data.Columns[14].Visible = false;
        }

        public void EnableAfterPrint()
        {
            dataGridView1.Enabled = true;
            this.btnPrint.Enabled = true;
            this.btnKeluar.Enabled = true;
            edCari.Enabled = true;

            TampilDataPemohonTerverifikasi(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
        }

        public void DisableMainForm()
        {
            dataGridView1.Enabled = false;
            edCari.Enabled = false;
            this.btnPrint.Enabled = false;
            this.btnKeluar.Enabled = false;
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                uC_CetakTagihanPSB1.Enabled = true;
                uC_CetakTagihanPSB1.Dispose();     
                this.Dispose();
            }
        }

        private void bindingSource1_PositionChanged(object sender, EventArgs e)
        {
            this.TampilDataPemohonTerverifikasi(dataGridView1);
        }

        private void edCari_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Convert.ToChar(13)))
            {
                this.dataGridView1.DataSource = permohonanPSBControl.searchDataPermohonanPSB(edCari.Text);
            }

            if (edCari.Text.Length == 1)
            {
                TampilDataPemohonTerverifikasi(this.dataGridView1);
            }
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log out?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                LoginUI utama = new LoginUI();
                utama.ShowDialog();
                this.Dispose();
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Silahkan pilih pemohon terlebih dahulu!", "Information");
                dataGridView1.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to make a receipt to the selected person?            The receipt will be stored to the database after the receipt is generated.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    int daya_permohonan = 0;
                    int id_permohonan = 0;
                    int id_tarif = 0;
                    int biaya_ujl = 0;
                    int biaya_sambung = 0;
                    double total_ujl = 0.0;
                    double total_penyambungan = 0.0;
                    double total_tagihan = 0.0;


                    DataTable data_permohonan = new DataTable();
                    data_permohonan = permohonanPSBControl.getDataPermohonanPSB_ByID(int.Parse(txtID.Text));

                    foreach (DataRow row in data_permohonan.Rows)
                    {
                        id_permohonan = int.Parse(row["ID_PERMOHONAN"].ToString());
                        daya_permohonan = int.Parse(row["DAYA_PERMOHONAN"].ToString());
                        break;
                    }

                    DataTable data_tarif = tarifControl.getDataTarifPSB_ByBeban(daya_permohonan);
                    uC_CetakTagihanPSB1.Enabled = true;

                    foreach (DataRow row in data_tarif.Rows)
                    {
                        id_tarif = int.Parse(row["ID_TARIF"].ToString());
                        biaya_ujl = int.Parse(row["BIAYA_UJL"].ToString());
                        biaya_sambung = int.Parse(row["BIAYA_SAMBUNG"].ToString());
                        break;
                    }

                    total_ujl = hitung_ujl(daya_permohonan, biaya_ujl);
                    total_penyambungan = hitung_biayaPenyambungan(daya_permohonan, biaya_sambung);
                    total_tagihan = total_ujl + total_penyambungan;

                    Dictionary<string, double> data_tarifTagihan = new Dictionary<string, double>();
                    data_tarifTagihan.Add("total_ujl", total_ujl);
                    data_tarifTagihan.Add("total_penyambungan", total_penyambungan);
                    data_tarifTagihan.Add("total_tagihan", total_tagihan);

                    uC_CetakTagihanPSB1.setDataTagihanPSB(data_pegawai, data_permohonan, data_tarif, data_tarifTagihan);

                    TagihanPSBEntity tEntity = new TagihanPSBEntity(id_permohonan, data_pegawai.ID_PEGAWAI, id_tarif, (decimal)total_tagihan, GlobalEntity.deskripsiTagihan_1, DateTime.Now);
                    tagihanPSBControl.entryDataTagihanPSB(tEntity);

                    uC_CetakTagihanPSB1.Visible = true;
                    uC_CetakTagihanPSB1.BringToFront();
                }
            }
        }

        private double hitung_ujl(int daya_permohonan, int biaya_ujl)
        {
            return (double) daya_permohonan * biaya_ujl;
        }

        private double hitung_biayaPenyambungan(int daya_permohonan, int biaya_penyambungan)
        {
            return (double) daya_permohonan * biaya_penyambungan;
        }

        private void uC_CetakTagihanPSB1_VisibleChanged(object sender, EventArgs e)
        {
            uC_CetakTagihanPSB1.Dock = DockStyle.Fill;
        }
    }
}
