﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_CetakTagihanPDL : UserControl
    {
        CetakTagihanPDL cetakTagihanPDL;

        public UC_CetakTagihanPDL()
        {
            InitializeComponent();
        }

        public void setDataTagihanPDL(PegawaiEntity data_pegawai, DataTable data_permohonan, DataTable data_tarif, Dictionary<string, double> data_tarifTagihan, DataTable data_member)
        {
            cetakTagihanPDL = new CetakTagihanPDL();
            cetakTagihanPDL.SetDataSource(data_permohonan);

            foreach (DataRow row in data_tarif.Rows)
            {
                cetakTagihanPDL.SetParameterValue("kategoriPermohonanTarif", row["KATEGORI_TARIF"].ToString());
                cetakTagihanPDL.SetParameterValue("bebanTarif", row["BEBAN"].ToString());
                cetakTagihanPDL.SetParameterValue("biayaUJL", row["BIAYA_UJL"].ToString());
                cetakTagihanPDL.SetParameterValue("biayaSambung", row["BIAYA_SAMBUNG"].ToString());
                break;
            }

            foreach (DataRow row in data_member.Rows)
            {
                cetakTagihanPDL.SetParameterValue("nomorPelanggan", row["NOMOR_MEMBER"].ToString());
                cetakTagihanPDL.SetParameterValue("kwhSebelum", row["DAYA_LISTRIK"].ToString());
                break;
            }

            cetakTagihanPDL.SetParameterValue("idPegawai", data_pegawai.ID_PEGAWAI);
            cetakTagihanPDL.SetParameterValue("namaPegawai", data_pegawai.NAMA_PEGAWAI);
            cetakTagihanPDL.SetParameterValue("totalBiayaUJL", data_tarifTagihan["total_ujl"]);
            cetakTagihanPDL.SetParameterValue("totalBiayaSambung", data_tarifTagihan["total_penyambungan"]);
            cetakTagihanPDL.SetParameterValue("totalTagihan", data_tarifTagihan["total_tagihan"]);

            crystalReportViewer1.ReportSource = cetakTagihanPDL;
            crystalReportViewer1.Show();
            crystalReportViewer1.Refresh();
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            cetakTagihanPDL.Dispose();

            CetakTagihanPDLUI myParent = (CetakTagihanPDLUI)this.Parent;
            myParent.EnableAfterPrint();
            this.Enabled = false;
            this.Visible = false;
            this.Hide();
        }
    }
}
