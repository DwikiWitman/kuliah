﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.CONTROL;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_PembayaranTagihanPSB : UserControl
    {
        PegawaiEntity data_pegawai = new PegawaiEntity();
        DataTable data_permohonan, data_tagihan;
        Random random = new Random();
        int id_tagihan;

        public UC_PembayaranTagihanPSB()
        {
            InitializeComponent();
        }

        public void setDataTagihanPSB(PegawaiEntity data_pegawai, DataTable data_permohonan, DataTable data_tagihan)
        {
            this.data_pegawai = data_pegawai;
            this.data_permohonan = data_permohonan;
            this.data_tagihan = data_tagihan;

            foreach (DataRow row in data_permohonan.Rows)
            {
                lblIDPermohonan.Text = row["ID_PERMOHONAN"].ToString();
                lblKodeArea.Text = row["ID_KODE_AREA"].ToString();
                lblIdentitas.Text = row["IDENTITAS_PEMOHON"].ToString();
                lblNama.Text = row["NAMA_PEMOHON"].ToString();
                lblTglLahir.Text = row["TANGGAL_LAHIR_PEMOHON"].ToString();
                lblAlamat.Text = row["ALAMAT_PEMOHON"].ToString();
                lblNomorHP.Text = row["NOMOR_HP_PEMOHON"].ToString();
                lblPekerjaan.Text = row["PEKERJAAN_PEMOHON"].ToString();
                lblDaya.Text = row["DAYA_PERMOHONAN"].ToString();
                lblJenisSambungan.Text = row["JENIS_SAMBUNGAN"].ToString();
                lblNomorResi.Text = row["NOMOR_RESI"].ToString();
                lblTglPermohonan.Text = row["TANGGAL_PERMOHONAN"].ToString();
                lblTglPersetujuan.Text = row["TANGGAL_PERSETUJUAN"].ToString();
                lblDeskripsi.Text = row["DESKRIPSI"].ToString();
                break;
            }


            foreach (DataRow row in data_tagihan.Rows)
            {
                lblTotalTagihan.Text = row["TOTAL_TAGIHAN_PERMOHONAN"].ToString();
                id_tagihan = int.Parse(row["ID_TAGIHAN_PERMOHONAN"].ToString());
                break;
            }

        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            PembayaranTagihanPSBUI myParent = (PembayaranTagihanPSBUI)this.Parent;
            myParent.EnableAfterPay();
            this.Visible = false;
        }

        private void edUang_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnBayar_Click(object sender, EventArgs e)
        {
            if (edUang.Text == "")
            {
                MessageBox.Show("Silahkan masukkan uang pemohon terlebih dahulu!", "Information");
                edUang.Focus();
            }
            else if ((decimal.Parse(edUang.Text) < decimal.Parse(lblTotalTagihan.Text)))
            {
                MessageBox.Show("Uang pemohon kurang dari Total Tagihan!", "Information");
                edUang.Focus();
            }
            else
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to pay this bill? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    TransaksiControl transaksiControl = new TransaksiControl();
                    DetilTransaksiControl detiltransaksiControl = new DetilTransaksiControl();
                    MemberControl memberControl = new MemberControl();
                    TagihanPSBControl tagihanPSBControl = new TagihanPSBControl();
                    PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();
                    TrafoControl trafoControl = new TrafoControl();
                    KodeAreaControl kodeAreaControl = new KodeAreaControl();
                    

                    TransaksiEntity transaksiEntity = new TransaksiEntity(id_tagihan, data_pegawai.ID_PEGAWAI, DateTime.Now.Date, Decimal.Parse(lblTotalTagihan.Text));
                    DetilTransaksiEntity detiltransaksiEntity = new DetilTransaksiEntity(lblJenisSambungan.Text,GlobalEntity.channelPembayaran_1);
                    
                    string nomor_member = "";  //nomor_member digenerate database
                    string nomor_kwh = RandomDigits(11);
                    MemberEntity memberEntity = new MemberEntity(lblIdentitas.Text, nomor_member, nomor_kwh, lblNama.Text, DateTime.Parse(lblTglLahir.Text).Date, lblAlamat.Text, lblNomorHP.Text, lblPekerjaan.Text, int.Parse(lblDaya.Text), lblJenisSambungan.Text, GlobalEntity.deskripsiStatusPemasangan_2);


                    detiltransaksiControl.entryDataDetilTransaksi(detiltransaksiEntity);
                    int id_detail_transaksi = detiltransaksiControl.getLastIDDetilTransaksi();
                    transaksiEntity.ID_DETIL_TRANSAKSI = id_detail_transaksi;
                    transaksiControl.entryDataTransaksiPSB(transaksiEntity);

                    memberControl.entryDataMember(memberEntity);
                    tagihanPSBControl.updateDataTagihanPSB(GlobalEntity.deskripsiTagihan_2, id_tagihan);
                    permohonanPSBControl.updateDataDeskripsiPSB(GlobalEntity.deskripsiPermohonan_4,int.Parse(lblIDPermohonan.Text));
                    
                    int id_trafo = kodeAreaControl.getDataIDTrafoByIDKodeArea(int.Parse(lblKodeArea.Text));
                    trafoControl.tambahDayaTerpakai(int.Parse(lblDaya.Text), id_trafo);

                    MessageBox.Show("Your payment was succesful!  Kembalian Rp." + (Decimal.Parse(edUang.Text) - Decimal.Parse(lblTotalTagihan.Text)).ToString(), "Information");

                    PembayaranTagihanPSBUI myParent = (PembayaranTagihanPSBUI)this.Parent;
                    myParent.EnableAfterPay();
                    this.Enabled = false;
                    this.Visible = false;
                    this.Hide();
                }
            }
        }

        private void edUang_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        public string RandomDigits(int length)
        {
            string s = string.Empty;
            for (int i = 0; i < length; i++)
                s = String.Concat(s, random.Next(10).ToString());
            return s;
        }

    }
}
