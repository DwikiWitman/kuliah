﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class DashboardAdministratorUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanelIcon_Utama = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelIcon_Middle = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxPengelolaanPegawai2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxIndetitasPegawai = new System.Windows.Forms.PictureBox();
            this.pictureBoxPengelolaanPegawai = new System.Windows.Forms.PictureBox();
            this.pictureBoxPengelolaanPegawai3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxControl = new System.Windows.Forms.PictureBox();
            this.pictureBoxWindows = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanelBottomBar = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanelWord_Middle = new System.Windows.Forms.TableLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanelWord_IdentitasPegawai = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.labelNama = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelJabatan = new System.Windows.Forms.Label();
            this.labelWaktu = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonPegawaiUI = new System.Windows.Forms.Button();
            this.btnTarif = new System.Windows.Forms.Button();
            this.tableLayoutPanelWord_Utama = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanelWord_Top = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanelIcon_Utama.SuspendLayout();
            this.tableLayoutPanelIcon_Middle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIndetitasPegawai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindows)).BeginInit();
            this.tableLayoutPanelBottomBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.tableLayoutPanelWord_Middle.SuspendLayout();
            this.tableLayoutPanelWord_IdentitasPegawai.SuspendLayout();
            this.tableLayoutPanelWord_Utama.SuspendLayout();
            this.tableLayoutPanelWord_Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanelIcon_Utama
            // 
            this.tableLayoutPanelIcon_Utama.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelIcon_Utama.ColumnCount = 1;
            this.tableLayoutPanelIcon_Utama.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.tableLayoutPanelIcon_Middle, 0, 1);
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.pictureBoxControl, 0, 0);
            this.tableLayoutPanelIcon_Utama.Controls.Add(this.pictureBoxWindows, 0, 2);
            this.tableLayoutPanelIcon_Utama.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanelIcon_Utama.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelIcon_Utama.Name = "tableLayoutPanelIcon_Utama";
            this.tableLayoutPanelIcon_Utama.RowCount = 3;
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelIcon_Utama.Size = new System.Drawing.Size(70, 733);
            this.tableLayoutPanelIcon_Utama.TabIndex = 0;
            // 
            // tableLayoutPanelIcon_Middle
            // 
            this.tableLayoutPanelIcon_Middle.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelIcon_Middle.ColumnCount = 1;
            this.tableLayoutPanelIcon_Middle.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai2, 0, 2);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxIndetitasPegawai, 0, 0);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai, 0, 1);
            this.tableLayoutPanelIcon_Middle.Controls.Add(this.pictureBoxPengelolaanPegawai3, 0, 3);
            this.tableLayoutPanelIcon_Middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelIcon_Middle.Location = new System.Drawing.Point(3, 103);
            this.tableLayoutPanelIcon_Middle.Name = "tableLayoutPanelIcon_Middle";
            this.tableLayoutPanelIcon_Middle.RowCount = 4;
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelIcon_Middle.Size = new System.Drawing.Size(64, 557);
            this.tableLayoutPanelIcon_Middle.TabIndex = 3;
            // 
            // pictureBoxPengelolaanPegawai2
            // 
            this.pictureBoxPengelolaanPegawai2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai2.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai2.Location = new System.Drawing.Point(3, 281);
            this.pictureBoxPengelolaanPegawai2.Name = "pictureBoxPengelolaanPegawai2";
            this.pictureBoxPengelolaanPegawai2.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxPengelolaanPegawai2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai2.TabIndex = 5;
            this.pictureBoxPengelolaanPegawai2.TabStop = false;
            // 
            // pictureBoxIndetitasPegawai
            // 
            this.pictureBoxIndetitasPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxIndetitasPegawai.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_users_man_woman;
            this.pictureBoxIndetitasPegawai.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxIndetitasPegawai.Name = "pictureBoxIndetitasPegawai";
            this.pictureBoxIndetitasPegawai.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxIndetitasPegawai.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxIndetitasPegawai.TabIndex = 3;
            this.pictureBoxIndetitasPegawai.TabStop = false;
            this.pictureBoxIndetitasPegawai.Click += new System.EventHandler(this.pictureBoxControl_Click);
            this.pictureBoxIndetitasPegawai.MouseLeave += new System.EventHandler(this.pictureBoxIndetitasPegawai_MouseLeave);
            this.pictureBoxIndetitasPegawai.MouseHover += new System.EventHandler(this.pictureBoxIndetitasPegawai_MouseHover);
            // 
            // pictureBoxPengelolaanPegawai
            // 
            this.pictureBoxPengelolaanPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai.Location = new System.Drawing.Point(3, 142);
            this.pictureBoxPengelolaanPegawai.Name = "pictureBoxPengelolaanPegawai";
            this.pictureBoxPengelolaanPegawai.Size = new System.Drawing.Size(58, 133);
            this.pictureBoxPengelolaanPegawai.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai.TabIndex = 4;
            this.pictureBoxPengelolaanPegawai.TabStop = false;
            this.pictureBoxPengelolaanPegawai.Click += new System.EventHandler(this.pictureBoxPengelolaanPegawai_Click);
            this.pictureBoxPengelolaanPegawai.MouseLeave += new System.EventHandler(this.pictureBoxPengelolaanPegawai_MouseLeave);
            this.pictureBoxPengelolaanPegawai.MouseHover += new System.EventHandler(this.pictureBoxPengelolaanPegawai_MouseHover);
            // 
            // pictureBoxPengelolaanPegawai3
            // 
            this.pictureBoxPengelolaanPegawai3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxPengelolaanPegawai3.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_divide_outsource_management;
            this.pictureBoxPengelolaanPegawai3.Location = new System.Drawing.Point(3, 420);
            this.pictureBoxPengelolaanPegawai3.Name = "pictureBoxPengelolaanPegawai3";
            this.pictureBoxPengelolaanPegawai3.Size = new System.Drawing.Size(58, 134);
            this.pictureBoxPengelolaanPegawai3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxPengelolaanPegawai3.TabIndex = 6;
            this.pictureBoxPengelolaanPegawai3.TabStop = false;
            // 
            // pictureBoxControl
            // 
            this.pictureBoxControl.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBoxControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxControl.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_right_circle;
            this.pictureBoxControl.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxControl.Name = "pictureBoxControl";
            this.pictureBoxControl.Size = new System.Drawing.Size(64, 94);
            this.pictureBoxControl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxControl.TabIndex = 5;
            this.pictureBoxControl.TabStop = false;
            this.pictureBoxControl.Click += new System.EventHandler(this.pictureBoxControl_Click);
            this.pictureBoxControl.MouseLeave += new System.EventHandler(this.pictureBoxControl_MouseLeave);
            this.pictureBoxControl.MouseHover += new System.EventHandler(this.pictureBoxControl_MouseHover);
            // 
            // pictureBoxWindows
            // 
            this.pictureBoxWindows.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxWindows.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_logo_apple;
            this.pictureBoxWindows.Location = new System.Drawing.Point(3, 666);
            this.pictureBoxWindows.Name = "pictureBoxWindows";
            this.pictureBoxWindows.Size = new System.Drawing.Size(64, 64);
            this.pictureBoxWindows.TabIndex = 6;
            this.pictureBoxWindows.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Trajan Pro", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(835, 73);
            this.label1.TabIndex = 6;
            this.label1.Text = "Sistem Informasi Listrik Pintar";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanelBottomBar
            // 
            this.tableLayoutPanelBottomBar.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelBottomBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tableLayoutPanelBottomBar.ColumnCount = 2;
            this.tableLayoutPanelBottomBar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 94.07245F));
            this.tableLayoutPanelBottomBar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.927552F));
            this.tableLayoutPanelBottomBar.Controls.Add(this.pictureBoxExit, 1, 0);
            this.tableLayoutPanelBottomBar.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanelBottomBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanelBottomBar.Location = new System.Drawing.Point(459, 660);
            this.tableLayoutPanelBottomBar.Name = "tableLayoutPanelBottomBar";
            this.tableLayoutPanelBottomBar.RowCount = 1;
            this.tableLayoutPanelBottomBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBottomBar.Size = new System.Drawing.Size(895, 73);
            this.tableLayoutPanelBottomBar.TabIndex = 9;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.BackColor = System.Drawing.Color.LimeGreen;
            this.pictureBoxExit.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBoxExit.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_door_enter;
            this.pictureBoxExit.Location = new System.Drawing.Point(844, 3);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(48, 67);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxExit.TabIndex = 7;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            this.pictureBoxExit.MouseLeave += new System.EventHandler(this.pictureBoxExit_MouseLeave);
            this.pictureBoxExit.MouseHover += new System.EventHandler(this.pictureBoxExit_MouseHover);
            // 
            // tableLayoutPanelWord_Middle
            // 
            this.tableLayoutPanelWord_Middle.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelWord_Middle.ColumnCount = 1;
            this.tableLayoutPanelWord_Middle.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Middle.Controls.Add(this.button2, 0, 3);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.tableLayoutPanelWord_IdentitasPegawai, 0, 0);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.buttonPegawaiUI, 0, 1);
            this.tableLayoutPanelWord_Middle.Controls.Add(this.btnTarif, 0, 2);
            this.tableLayoutPanelWord_Middle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_Middle.Location = new System.Drawing.Point(6, 109);
            this.tableLayoutPanelWord_Middle.Name = "tableLayoutPanelWord_Middle";
            this.tableLayoutPanelWord_Middle.RowCount = 4;
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_Middle.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_Middle.Size = new System.Drawing.Size(377, 545);
            this.tableLayoutPanelWord_Middle.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(3, 411);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(371, 131);
            this.button2.TabIndex = 2;
            this.button2.Text = "Reserved.";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelWord_IdentitasPegawai
            // 
            this.tableLayoutPanelWord_IdentitasPegawai.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnCount = 2;
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanelWord_IdentitasPegawai.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 265F));
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelNama, 1, 0);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelUsername, 1, 1);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelJabatan, 1, 2);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.labelWaktu, 1, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanelWord_IdentitasPegawai.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanelWord_IdentitasPegawai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_IdentitasPegawai.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelWord_IdentitasPegawai.Name = "tableLayoutPanelWord_IdentitasPegawai";
            this.tableLayoutPanelWord_IdentitasPegawai.RowCount = 4;
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelWord_IdentitasPegawai.Size = new System.Drawing.Size(371, 130);
            this.tableLayoutPanelWord_IdentitasPegawai.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LimeGreen;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(5, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 30);
            this.label5.TabIndex = 7;
            this.label5.Text = "Time";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelNama
            // 
            this.labelNama.AutoSize = true;
            this.labelNama.BackColor = System.Drawing.Color.LimeGreen;
            this.labelNama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelNama.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNama.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelNama.Location = new System.Drawing.Point(115, 2);
            this.labelNama.Name = "labelNama";
            this.labelNama.Size = new System.Drawing.Size(259, 30);
            this.labelNama.TabIndex = 0;
            this.labelNama.Text = "labelNama";
            this.labelNama.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelUsername.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsername.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelUsername.Location = new System.Drawing.Point(115, 34);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(259, 30);
            this.labelUsername.TabIndex = 1;
            this.labelUsername.Text = "labelUsername";
            this.labelUsername.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelJabatan
            // 
            this.labelJabatan.AutoSize = true;
            this.labelJabatan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelJabatan.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJabatan.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelJabatan.Location = new System.Drawing.Point(115, 66);
            this.labelJabatan.Name = "labelJabatan";
            this.labelJabatan.Size = new System.Drawing.Size(259, 30);
            this.labelJabatan.TabIndex = 2;
            this.labelJabatan.Text = "labelJabatan";
            this.labelJabatan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelWaktu
            // 
            this.labelWaktu.AutoSize = true;
            this.labelWaktu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelWaktu.Font = new System.Drawing.Font("Trajan Pro", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWaktu.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.labelWaktu.Location = new System.Drawing.Point(115, 98);
            this.labelWaktu.Name = "labelWaktu";
            this.labelWaktu.Size = new System.Drawing.Size(259, 30);
            this.labelWaktu.TabIndex = 3;
            this.labelWaktu.Text = "labelWaktu";
            this.labelWaktu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LimeGreen;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(5, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 30);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nama";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LimeGreen;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(5, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Username";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LimeGreen;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(5, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 30);
            this.label4.TabIndex = 6;
            this.label4.Text = "Jabatan";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonPegawaiUI
            // 
            this.buttonPegawaiUI.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonPegawaiUI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.buttonPegawaiUI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPegawaiUI.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.buttonPegawaiUI.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.buttonPegawaiUI.Location = new System.Drawing.Point(3, 139);
            this.buttonPegawaiUI.Name = "buttonPegawaiUI";
            this.buttonPegawaiUI.Size = new System.Drawing.Size(371, 130);
            this.buttonPegawaiUI.TabIndex = 0;
            this.buttonPegawaiUI.Text = "Pengelolaan Karyawan / Pegawai.";
            this.buttonPegawaiUI.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPegawaiUI.UseVisualStyleBackColor = true;
            this.buttonPegawaiUI.Click += new System.EventHandler(this.buttonPegawaiUI_Click);
            // 
            // btnTarif
            // 
            this.btnTarif.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTarif.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTarif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTarif.Font = new System.Drawing.Font("Trajan Pro", 12F, System.Drawing.FontStyle.Bold);
            this.btnTarif.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnTarif.Location = new System.Drawing.Point(3, 275);
            this.btnTarif.Name = "btnTarif";
            this.btnTarif.Size = new System.Drawing.Size(371, 130);
            this.btnTarif.TabIndex = 1;
            this.btnTarif.Text = "Pengelolaan Tarif Listrik.";
            this.btnTarif.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTarif.UseVisualStyleBackColor = true;
            this.btnTarif.Click += new System.EventHandler(this.btnTarif_Click);
            // 
            // tableLayoutPanelWord_Utama
            // 
            this.tableLayoutPanelWord_Utama.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanelWord_Utama.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanelWord_Utama.ColumnCount = 1;
            this.tableLayoutPanelWord_Utama.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Utama.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanelWord_Utama.Controls.Add(this.tableLayoutPanelWord_Middle, 0, 1);
            this.tableLayoutPanelWord_Utama.Controls.Add(this.tableLayoutPanelWord_Top, 0, 0);
            this.tableLayoutPanelWord_Utama.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanelWord_Utama.Location = new System.Drawing.Point(70, 0);
            this.tableLayoutPanelWord_Utama.Name = "tableLayoutPanelWord_Utama";
            this.tableLayoutPanelWord_Utama.RowCount = 3;
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelWord_Utama.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelWord_Utama.Size = new System.Drawing.Size(389, 733);
            this.tableLayoutPanelWord_Utama.TabIndex = 8;
            this.tableLayoutPanelWord_Utama.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Trajan Pro", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label7.Location = new System.Drawing.Point(6, 660);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(377, 70);
            this.label7.TabIndex = 8;
            this.label7.Text = "SILIPI - DESKTOP © 2017";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanelWord_Top
            // 
            this.tableLayoutPanelWord_Top.ColumnCount = 2;
            this.tableLayoutPanelWord_Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.98695F));
            this.tableLayoutPanelWord_Top.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.01305F));
            this.tableLayoutPanelWord_Top.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanelWord_Top.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanelWord_Top.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelWord_Top.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanelWord_Top.Name = "tableLayoutPanelWord_Top";
            this.tableLayoutPanelWord_Top.RowCount = 1;
            this.tableLayoutPanelWord_Top.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelWord_Top.Size = new System.Drawing.Size(377, 94);
            this.tableLayoutPanelWord_Top.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Trajan Pro", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(134, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(240, 94);
            this.label6.TabIndex = 8;
            this.label6.Text = "Identitas Pegawai";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_user_id;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // DashboardAdministratorUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 733);
            this.Controls.Add(this.tableLayoutPanelBottomBar);
            this.Controls.Add(this.tableLayoutPanelWord_Utama);
            this.Controls.Add(this.tableLayoutPanelIcon_Utama);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.IsMdiContainer = true;
            this.Name = "DashboardAdministratorUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardAdministratorUI";
            this.Load += new System.EventHandler(this.DashboardAdministratorUI_Load);
            this.tableLayoutPanelIcon_Utama.ResumeLayout(false);
            this.tableLayoutPanelIcon_Middle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIndetitasPegawai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPengelolaanPegawai3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindows)).EndInit();
            this.tableLayoutPanelBottomBar.ResumeLayout(false);
            this.tableLayoutPanelBottomBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.tableLayoutPanelWord_Middle.ResumeLayout(false);
            this.tableLayoutPanelWord_IdentitasPegawai.ResumeLayout(false);
            this.tableLayoutPanelWord_IdentitasPegawai.PerformLayout();
            this.tableLayoutPanelWord_Utama.ResumeLayout(false);
            this.tableLayoutPanelWord_Utama.PerformLayout();
            this.tableLayoutPanelWord_Top.ResumeLayout(false);
            this.tableLayoutPanelWord_Top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelIcon_Utama;
        private System.Windows.Forms.PictureBox pictureBoxIndetitasPegawai;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxControl;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelIcon_Middle;
        private System.Windows.Forms.PictureBox pictureBoxWindows;
        private System.Windows.Forms.PictureBox pictureBoxPengelolaanPegawai3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBottomBar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Middle;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_IdentitasPegawai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelNama;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label labelJabatan;
        private System.Windows.Forms.Label labelWaktu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonPegawaiUI;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Utama;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWord_Top;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnTarif;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}