﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class DashboardPetugasLoketUI : Form
    {
        PegawaiEntity Pegawai = new PegawaiEntity();
        PegawaiControl PC = new PegawaiControl();

        PermohonanPSBUI permohonanPSB;
        PermohonanPDLUI permohonanPDL; 
        CetakKartuMemberUI cetakKartuMember; 
        PembayaranTagihanPSBUI pembayaranTagihan; 
        CetakTagihanPSBUI cetakTagihan;
        CetakTagihanPDLUI cetakTagihanPDL;
        PencatatanTagihanPascabayarUI pencatatanTagihanPascabayar;
        PembayaranTagihanPascabayarUI pembayaranTagihanPascabayar;
        PembelianTokenUI pembelianToken;
        StatusPSBUI pengubahanStatusPemasangan;

        public DashboardPetugasLoketUI(PegawaiEntity Pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.Pegawai = Pegawai;
        }

        private void DashboardPetugasLoketUI_Load(object sender, EventArgs e)
        {
            labelNama.Text = Pegawai.NAMA_PEGAWAI;
            labelJabatan.Text = PC.getNamaJabatan(Pegawai.ID_JABATAN);
            labelUsername.Text = Pegawai.USERNAME_PEGAWAI;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labelWaktu.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt");
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to log-off?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Hide();
                LoginUI login = new LoginUI();
                login.ShowDialog();
                this.Close();
            }
        }

        private void buttonPegawaiUI_Click(object sender, EventArgs e)
        {
            PegawaiUI pegawaiForm = new PegawaiUI();
            pegawaiForm.MdiParent = this;
            pegawaiForm.Show();
            tableLayoutPanelIcon_Utama.SendToBack();
            pegawaiForm.BringToFront();
        }

        private void pictureBoxControl_Click(object sender, EventArgs e)
        {
            if (tableLayoutPanelWord_Utama.Visible == true)
            {
                tableLayoutPanelWord_Utama.Hide();
                pictureBoxControl.Image = DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_left_circle;
            }
            else if (tableLayoutPanelWord_Utama.Visible == false)
            {
                tableLayoutPanelWord_Utama.Show();
                pictureBoxControl.Image = DESKTOP_SILIPI_7748.Properties.Resources.Image_arrow_right_circle;
            }
        }

        private void pictureBoxExit_MouseHover(object sender, EventArgs e)
        {
            pictureBoxExit.BackColor = Color.FromArgb(0, 192, 0);
            Size size = new Size(45, 65);
            pictureBoxExit.Size = size;
        }

        private void pictureBoxExit_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxExit.BackColor = Color.LimeGreen;
            Size size = new Size(32, 57);
            pictureBoxExit.Size = size;
        }

        private void pictureBoxControl_MouseHover(object sender, EventArgs e)
        {
            pictureBoxControl.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxControl_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxControl.BackColor = Color.LimeGreen;
        }

        private void pictureBoxIndetitasPegawai_MouseHover(object sender, EventArgs e)
        {
            pictureBoxIndetitasPegawai.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxIndetitasPegawai_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxIndetitasPegawai.BackColor = Color.LimeGreen;
        }

        private void pictureBoxPengelolaanPegawai_Click(object sender, EventArgs e)
        {
            buttonPegawaiUI_Click(sender, e);
        }

        private void pictureBoxPengelolaanPegawai_MouseHover(object sender, EventArgs e)
        {
            pictureBoxPengelolaanPegawai.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void pictureBoxPengelolaanPegawai_MouseLeave(object sender, EventArgs e)
        {
            pictureBoxPengelolaanPegawai.BackColor = Color.LimeGreen;
        }

        private void buttonCetakTagihan_Click(object sender, EventArgs e)
        {
            cetakTagihan = CetakTagihanPSBUI.GetForm;
            if (cetakTagihan != null)
            {
                cetakTagihan.setPegawai(Pegawai);
                cetakTagihan.MdiParent = this;
                cetakTagihan.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                cetakTagihan.BringToFront();
            }
        }

        private void buttonBayarTagihan_Click(object sender, EventArgs e)
        {
            pembayaranTagihan = PembayaranTagihanPSBUI.GetForm;
            if (pembayaranTagihan != null)
            {
                pembayaranTagihan.setPegawai(Pegawai);
                pembayaranTagihan.MdiParent = this;
                pembayaranTagihan.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                pembayaranTagihan.BringToFront();
            }
        }

        private void buttonCetakKartuMember_Click(object sender, EventArgs e)
        {
            cetakKartuMember = CetakKartuMemberUI.GetForm;
            if (cetakKartuMember != null)
            {
                cetakKartuMember.setPegawai(Pegawai);
                cetakKartuMember.MdiParent = this;
                cetakKartuMember.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                cetakKartuMember.BringToFront();
            }
        }

        private void buttonKelolaPSB_Click(object sender, EventArgs e)
        {
            permohonanPSB = PermohonanPSBUI.GetForm;
            if (permohonanPSB != null)
            {
                permohonanPSB.setPegawai(Pegawai);
                permohonanPSB.MdiParent = this;
                permohonanPSB.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                permohonanPSB.BringToFront();
            }
        }

        private void buttonPencatatanTagihanPascabayar_Click(object sender, EventArgs e)
        {
            pencatatanTagihanPascabayar = PencatatanTagihanPascabayarUI.GetForm;
            if (pencatatanTagihanPascabayar != null)
            {
                pencatatanTagihanPascabayar.setPegawai(Pegawai);
                pencatatanTagihanPascabayar.MdiParent = this;
                pencatatanTagihanPascabayar.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                pencatatanTagihanPascabayar.BringToFront();
            }
        }

        private void buttonPembayaranTagihanPascabayar_Click(object sender, EventArgs e)
        {
            pembayaranTagihanPascabayar = PembayaranTagihanPascabayarUI.GetForm;
            if (pembayaranTagihanPascabayar != null)
            {
                pembayaranTagihanPascabayar.setPegawai(Pegawai);
                pembayaranTagihanPascabayar.MdiParent = this;
                pembayaranTagihanPascabayar.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                pembayaranTagihanPascabayar.BringToFront();
            }
        }

        private void buttonPembelianToken_Click(object sender, EventArgs e)
        {
            pembelianToken = PembelianTokenUI.GetForm;
            if (pembelianToken != null)
            {
                pembelianToken.setPegawai(Pegawai);
                pembelianToken.MdiParent = this;
                pembelianToken.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                pembelianToken.BringToFront();
            }
        }

        private void buttonPengubahanStatusPemasangan_Click(object sender, EventArgs e)
        {
            pengubahanStatusPemasangan = StatusPSBUI.GetForm;
            if (pengubahanStatusPemasangan != null)
            {
                pengubahanStatusPemasangan.setPegawai(Pegawai);
                pengubahanStatusPemasangan.MdiParent = this;
                pengubahanStatusPemasangan.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                pengubahanStatusPemasangan.BringToFront();
            }
        }

        private void btnPermohonanPDL_Click(object sender, EventArgs e)
        {
            permohonanPDL = PermohonanPDLUI.GetForm;
            if (permohonanPDL != null)
            {
                permohonanPDL.setPegawai(Pegawai);
                permohonanPDL.MdiParent = this;
                permohonanPDL.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                permohonanPDL.BringToFront();
            }
        }

        private void buttonBayarTagihanPDL_Click(object sender, EventArgs e)
        {
            cetakTagihanPDL = CetakTagihanPDLUI.GetForm;
            if (cetakTagihanPDL != null)
            {
                cetakTagihanPDL.setPegawai(Pegawai);
                cetakTagihanPDL.MdiParent = this;
                cetakTagihanPDL.Show();
                tableLayoutPanelIcon_Utama.SendToBack();
                cetakTagihanPDL.BringToFront();
            }
        }
    }
}
