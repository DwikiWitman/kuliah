﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_Pegawai : UserControl
    {
        PegawaiControl PControl = new PegawaiControl();
        int flagperintah = 0;

        public void setFlag(int flag)
        {
            flagperintah = flag;
        }

        public UC_Pegawai()
        {
            InitializeComponent();
        }

        private bool cektxt()
        {
            bool temp = true;
            if (edUsername.Text == "")
            {
                errorProvider1.SetError(edUsername, "Silahkan isi Username Pegawai");
                edUsername.Focus();
                temp = false;
            } else errorProvider1.SetError(edUsername, "");

            if (edPassword.Text == "")
            {
                errorProvider1.SetError(edPassword, "Silahkan isi Password Pegawai");
                edPassword.Focus();
                temp = false;
            } else errorProvider1.SetError(edPassword, "");

            if (cmbJabatan.SelectedIndex == -1)
            {
                errorProvider1.SetError(cmbJabatan, "Silahkan Pilih Jabatan Pegawai");
                cmbJabatan.Focus();
                temp = false;
            } else errorProvider1.SetError(cmbJabatan, "");

            if (edNama.Text == "")
            {
                errorProvider1.SetError(edNama, "Silahkan isi Nama Lengkap Pegawai");
                edNama.Focus();
                temp = false;
            } else errorProvider1.SetError(edNama, "");

            if (edAlamat.Text == "")
            {
                errorProvider1.SetError(edAlamat, "Silahkan isi Alamat Rumah Pegawai");
                edAlamat.Focus();
                temp = false;
            } else errorProvider1.SetError(edAlamat, "");

            if (!dateTimePicker1.Checked)
            {
                errorProvider1.SetError(dateTimePicker1, "Silahkan isi Tanggal Lahir Pegawai");
                dateTimePicker1.Focus();
                temp = false;
            } else errorProvider1.SetError(dateTimePicker1, "");

            if (edNomor.Text == "")
            {
                errorProvider1.SetError(edNomor, "Silahkan isi Nomor Handphone Pegawai");
                edNomor.Focus();
                temp = false;
            } else errorProvider1.SetError(edNomor, "");

            return temp;
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagperintah == 1)
                {
                    if (cektxt() == true)
                    {
                        errorProvider1.Clear();
                        int IDJabatan = PControl.getIDJabatan(cmbJabatan.Text);
                        PegawaiEntity pegawai = new PegawaiEntity(IDJabatan, edNama.Text, dateTimePicker1.Value.Date, edAlamat.Text, edNomor.Text, edUsername.Text, edPassword.Text);
                        PControl.entryDataPegawai(pegawai);
                        clearForm();
                        this.Hide();
                        PegawaiUI myParent = (PegawaiUI)this.Parent;
                        myParent.EnableAfterInsert();
                    }
                }

                else
                {

                    if (cektxt() == true)
                    {
                        errorProvider1.Clear();
                        int IDJabatan = PControl.getIDJabatan(cmbJabatan.Text);
                        PegawaiEntity pegawai = new PegawaiEntity(int.Parse(edID.Text),IDJabatan, edNama.Text, dateTimePicker1.Value.Date, edAlamat.Text, edNomor.Text, edUsername.Text, edPassword.Text);
                        
                        DialogResult dr = MessageBox.Show("Apakah anda yakin mengupdate pegawai ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (dr == DialogResult.Yes)
                        {
                            PControl.editDataPegawai(pegawai);
                        }
                        clearForm();
                        this.Hide();
                        PegawaiUI myParent = (PegawaiUI)this.Parent;
                        myParent.EnableAfterEdit();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearForm()
        {
            edUsername.Clear();
            edPassword.Clear();
            cmbJabatan.SelectedIndex = -1;
            edNama.Clear();
            edAlamat.Clear();
            edNomor.Clear();
            errorProvider1.Clear();
        }

        private void edNomor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        public void fillForm(int id_pegawai, int jabatan, string nama, DateTime tanggal_lahir, string alamat, string hp, string username, string password)
        {
            edID.Text = id_pegawai.ToString();
            cmbJabatan.SelectedIndex = jabatan-1;
            edNama.Text = nama;
            dateTimePicker1.Value =  tanggal_lahir.Date;
            edAlamat.Text = alamat;
            edNomor.Text = hp;
            edUsername.Text = username;
            edPassword.Text = password;        
        }

        private void btnUlang_Click(object sender, EventArgs e)
        {
            this.clearForm();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            clearForm();
            this.Hide();
            PegawaiUI myParent = (PegawaiUI)this.Parent;
            if (btnTambah.Text == "Tambahkan")
            {
                myParent.EnableAfterInsert();
            }
            else
                myParent.EnableAfterEdit();
            
        }
    }
}
