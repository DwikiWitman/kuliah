﻿using DESKTOP_SILIPI_7748.BOUNDARY;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748
{
    public partial class LoginUI : Form
    {
        string user, pass, nama_jabatan;
        int id_pegawai, id_jabatan;

        LoginControl lc = new LoginControl();

        public LoginUI()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            user = edUser.Text;
            pass = edPass.Text;

            if (lc.cekLogin(user, pass) == true)
            {
                id_pegawai = lc.getIDPegawai(user, pass);
                id_jabatan = lc.getIDJabatanPegawai(user, pass);
                nama_jabatan = lc.getNamaJabatanPegawai(id_jabatan);
                
                if (nama_jabatan == "CEO")
                {
                    this.Hide();
                    PegawaiEntity P = lc.getDataPegawai(id_pegawai);
                    DashboardManagerUI dashboard = new DashboardManagerUI(P);
                    dashboard.ShowDialog();
                    this.Close();
                }

                else if (nama_jabatan == "Manager Operasional")
                {
                    this.Hide();
                    PegawaiEntity P = lc.getDataPegawai(id_pegawai);
                    DashboardManagerUI dashboard = new DashboardManagerUI(P);
                    dashboard.ShowDialog();
                    this.Close();
                }

                else if (nama_jabatan == "Administrator")
                {
                    this.Hide();
                    PegawaiEntity P = lc.getDataPegawai(id_pegawai);
                    DashboardAdministratorUI dashboard = new DashboardAdministratorUI(P);
                    dashboard.ShowDialog();
                    this.Close();
                }

                else if (nama_jabatan == "Petugas Loket")
                {
                    this.Hide();
                    PegawaiEntity P = lc.getDataPegawai(id_pegawai);
                    DashboardPetugasLoketUI dashboard = new DashboardPetugasLoketUI(P);
                    dashboard.ShowDialog();
                    this.Close();
                }

                else
                {
                    MessageBox.Show("User does not have access rights.", "Information");
                }

            }

            else if (edUser.Text == "" || edPass.Text == "")
            {
                if (edUser.Text == "" && edPass.Text == "")
                {
                    MessageBox.Show("Please fill your username and password.", "Information");
                    edUser.Text = "USERNAME";
                    edPass.Text = "PASSWORD";
                    edUser.Focus();
                }
                else if (edUser.Text == "")
                {
                    MessageBox.Show("Please fill your username.", "Information");
                    edUser.Text = "USERNAME";
                    edUser.Focus();
                }
                else if (edPass.Text == "")
                {
                    MessageBox.Show("Please fill your password.", "Information");
                    edPass.Text = "PASSWORD";
                    edPass.Focus();
                }
            }

            else
            {
                MessageBox.Show("Your username or password is incorrect.", "Information");
                edUser.Text = "USERNAME";
                edUser.Focus();
            }
        }

        private void btnKeluar_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }

        private void edPass_Click(object sender, EventArgs e)
        {
            edPass.Text = "";
        }

        private void edUser_Click(object sender, EventArgs e)
        {
            edUser.Text = "";
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to exit?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                this.Dispose();
            }
        }
    }
}
