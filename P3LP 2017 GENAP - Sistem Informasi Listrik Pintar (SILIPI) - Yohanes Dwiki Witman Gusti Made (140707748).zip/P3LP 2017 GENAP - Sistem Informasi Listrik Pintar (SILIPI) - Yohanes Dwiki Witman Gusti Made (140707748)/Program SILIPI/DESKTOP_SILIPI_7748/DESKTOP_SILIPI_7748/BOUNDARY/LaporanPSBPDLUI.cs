﻿using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class LaporanPSBPDLUI : Form
    {
        PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();
        PermohonanPDLControl permohonanPDLControl = new PermohonanPDLControl();
        MemberControl memberControl = new MemberControl();
        PegawaiEntity data_pegawai = new PegawaiEntity();
        TransaksiControl transaksiControl = new TransaksiControl();
        LaporanPSBPDL laporanPSBPDL;
        LaporanStatusPemasangan laporanStatusPemasangan;

        /* 
         *  SINGLETON FORM 
         */
        private static LaporanPSBPDLUI instance;
        public static LaporanPSBPDLUI GetForm
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                    instance = new LaporanPSBPDLUI();
                return instance;
            }
        }
        
        public void setPegawai(PegawaiEntity data_pegawai) { this.data_pegawai = data_pegawai; }

        public LaporanPSBPDLUI()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }
        /* 
         *  SINGLETON FORM 
         */

        public LaporanPSBPDLUI(PegawaiEntity data_pegawai)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            this.data_pegawai = data_pegawai;
        }

        private void LaporanPSBPDLUI_Load(object sender, EventArgs e)
        {
            DataTable data_permohonanPSB = permohonanPSBControl.getDataPermohonanPSB();
            DataTable data_permohonanPDL = permohonanPDLControl.getDataPermohonanPDL();
            DataTable data_member = memberControl.getDataMember();

            laporanPSBPDL = new LaporanPSBPDL();
            //laporanPSBPDL.Database.Tables[0].SetDataSource(data_permohonanPSB);
            //laporanPSBPDL.Database.Tables[1].SetDataSource(data_permohonanPDL);
            laporanPSBPDL.SetDataSource(data_permohonanPSB);
            //laporanPSBPDL.SetDataSource(data_permohonanPDL);
            //laporanPSBPDL.SetParameterValue("namaPegawai", data_pegawai.NAMA_PEGAWAI);

            laporanStatusPemasangan = new LaporanStatusPemasangan();
            laporanStatusPemasangan.SetDataSource(data_member);

            crystalReportViewer1.ReportSource = laporanPSBPDL;
            crystalReportViewer1.Show();
            crystalReportViewer1.Refresh();

            crystalReportViewer2.ReportSource = laporanStatusPemasangan;
            crystalReportViewer2.Show();
            crystalReportViewer2.Refresh();

            TampilDataMember(dataGridView1);
        }

        private void keluarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            laporanPSBPDL.Dispose();
            this.Dispose();
        }

        public void TampilDataMember(DataGridView data)
        {
            data.DataSource = memberControl.getDataMember();
            DataTable DT = memberControl.getDataMember();
            BindingList<DataTable> listTbl = new BindingList<DataTable>();

            if (DT.Rows.Count > 0)
            {
                int counter = 0, subTblIndex = -1;
                foreach (DataRow dr in DT.Rows)
                {
                    if (counter == 0)
                    {
                        listTbl.Add(DT.Clone());
                        subTblIndex++;
                    }
                    listTbl[subTblIndex].Rows.Add(dr.ItemArray);
                    counter++;
                    if (counter == 20) counter = 0;
                }
            }

            bindingSource1.DataSource = listTbl;
            bindingNavigator1.BindingSource = bindingSource1;
            data.DataSource = (DT.Rows.Count > 0 ? listTbl[bindingSource1.Position] : DT);

            var columnList = "ID_MEMBER, NOMOR_KTP, NOMOR_MEMBER, NOMOR_KWH, NAMA_MEMBER, TANGGAL_LAHIR_MEMBER, ALAMAT_INSTALASI, NOMOR_HP_MEMBER, PEKERJAAN, DAYA_LISTRIK, TIPE_MEMBER, STATUS";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            columnList = "ID_MEMBER";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
        }


        public void TampilDataTransaksi(DataGridView data)
        {
            data.DataSource = null;
            DataTable DT = transaksiControl.getDataTransaksiByIDMember(int.Parse(txtID.Text));
            data.DataSource = DT;
            
            var columnList = "ID_TRANSAKSI, ID_DETIL_TRANSAKSI, ID_TAGIHAN_PERMOHONAN, ID_TAGIHAN_PASCABAYAR, ID_TOKEN, ID_MEMBER, ID_PEGAWAI, TANGGAL_TRANSAKSI, TOTAL_PEMBAYARAN";
            var columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                var gridViewColumn = data.Columns[columnListArray[i].Trim()];
                if (gridViewColumn != null)
                {
                    gridViewColumn.DisplayIndex = i;
                    data.Columns[i].HeaderText = columnListArray[i];
                    data.Columns[i].Width = 200;
                }
            }

            /*
            columnList = "ID_TRANSAKSI, ID_DETIL_TRANSAKSI, ID_TAGIHAN_PERMOHONAN, ID_TAGIHAN_PASCABAYAR, ID_TOKEN, ID_MEMBER, ID_PEGAWAI";
            columnListArray = columnList.Split(',');
            for (var i = 0; i < columnListArray.Length; i++)
            {
                data.Columns[columnListArray[i].Trim()].Visible = false;
            }
             * */
        }

        public void EnableAfterLook()
        {
            dataGridView1.Enabled = true;
            dataGridView2.Enabled = true;
            edCari.Enabled = true;
            this.Visible = true;
            this.BringToFront();

            TampilDataMember(this.dataGridView1);
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows[0].Selected = true;
                txtID.Text = getKolom(dataGridView1, 0);
            }
        }

        private string getKolom(DataGridView dg, int i)
        {
            return dg[dg.Columns[i].Index, dg.CurrentRow.Index].Value.ToString();
        }

        private string getKolomEdit(DataGridView dg, int i)
        {
            return dg[dg.Columns[0].Index, dg.Rows[i].Index].Value.ToString();
        }

        private string getRow(DataGridView dg)
        {
            return dg.CurrentRow.Index.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView1.DataSource = null;
            else
                TampilDataTransaksi(dataGridView2);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = getKolom(dataGridView1, 0);
            txtRow.Text = getRow(dataGridView1);
            int id = int.Parse(txtID.Text);
            if (id < 0)
                dataGridView1.DataSource = null;
            else
                TampilDataTransaksi(dataGridView2);
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            txtID.Text = getKolom(dataGridView2, 0);
            txtRow.Text = getRow(dataGridView2);
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int id_transaksi = 0;
            id_transaksi = int.Parse(getKolom(dataGridView2, 0));

            DialogResult dr = MessageBox.Show("Apakah anda ingin melihat detil transaksi ini ?", "Pertanyaan",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes && id_transaksi != 0)
            {
                TagihanPascbayarControl tagihanPascabayarControl = new TagihanPascbayarControl();
                TagihanPSBControl tagihanPSBControl = new TagihanPSBControl();
                TokenControl tokenControl = new TokenControl();

                DataTable data_member = memberControl.getDataMemberByID(int.Parse(txtID.Text));
                DataTable data_transaksi = transaksiControl.getDataTransaksiByID(id_transaksi);

                int id_tagihan_pascabayar = 0;
                int id_tagihan_psb = 0;
                int id_token = 0;

                foreach (DataRow row in data_transaksi.Rows)
                {
                    try
                    {
                        id_tagihan_pascabayar = int.Parse(row["ID_TAGIHAN_PASCABAYAR"].ToString());
                    }
                    catch (Exception ex) { ex.ToString(); };
                    try
                    {
                        id_tagihan_psb = int.Parse(row["ID_TAGIHAN_PERMOHONAN"].ToString());
                    }
                    catch (Exception ex) { ex.ToString(); };
                    try
                    {
                        id_token = int.Parse(row["ID_TOKEN"].ToString());
                    }
                    catch (Exception ex) { ex.ToString(); };
                    break;
                }

                if (id_tagihan_pascabayar != 0)
                {
                    DataTable data_tagihanpascabayar = tagihanPascabayarControl.getDataTagihanPascabayar_ByID(id_tagihan_pascabayar);
                    uC_DetilTransaksi1.Visible = true;
                    uC_DetilTransaksi1.setDataDetilTransaksiPascabayar(data_pegawai, data_member, data_tagihanpascabayar, data_transaksi);
                }
                else if (id_tagihan_psb != 0)
                {
                    DataTable data_tagihanpsb = tagihanPSBControl.getDataTagihanPSB_ByIDTagihan(id_tagihan_psb);
                    uC_DetilTransaksi1.Visible = true;
                    uC_DetilTransaksi1.setDataDetilTransaksiPSB(data_pegawai, data_member, data_tagihanpsb, data_transaksi);
                }
                else if (id_token != 0)
                {
                    DataTable data_token = tokenControl.getDataTokenByID(id_token);
                    uC_DetilTransaksi1.Visible = true;
                    uC_DetilTransaksi1.setDataDetilTransaksiToken(data_pegawai, data_member, data_token, data_transaksi);
                }

            }
            else
                MessageBox.Show("Silahkan pilih transaksi member.", "Information");
            
            
        }

        private void uC_DetilTransaksi1_VisibleChanged(object sender, EventArgs e)
        {
            uC_DetilTransaksi1.Dock = DockStyle.Fill;
        }
    }
}
