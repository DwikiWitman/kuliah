﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.CONTROL;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_PermohonanPDL : UserControl
    {
        PermohonanPSBControl permohonanPSBControl = new PermohonanPSBControl();
        PermohonanPDLControl permohonanPDLControl = new PermohonanPDLControl();
        KodeAreaControl kodeAreaControl = new KodeAreaControl();
        Random rnd = new Random();

        public UC_PermohonanPDL()
        {
            InitializeComponent();
        }

        public void setNomorPelanggan(string nomor_pelanggan)
        {
            this.lblNomorPelanggan.Text = nomor_pelanggan;
        }

        private bool cektxt()
        {
            bool temp = true;
            if (!dateTimePickerTglPermohonan.Checked)
            {
                errorProvider1.SetError(dateTimePickerTglPermohonan, "Silahkan isi Tanggal Permohonan");
                dateTimePickerTglPermohonan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(dateTimePickerTglPermohonan, "");

            if (edNama.Text == "")
            {
                errorProvider1.SetError(edNama, "Silahkan isi Nama Pemohon");
                edNama.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edNama, "");

            if (lblNomorPelanggan.Text == "")
            {
                errorProvider1.SetError(lblNomorPelanggan, "Silahkan isi Nama Pemohon");
                lblNomorPelanggan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edNama, "");

            if (edIdentitas.Text == "")
            {
                errorProvider1.SetError(edIdentitas, "Silahkan isi Identitas Pemohon");
                edIdentitas.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edIdentitas, "");

            if (edAlamat.Text == "")
            {
                errorProvider1.SetError(edAlamat, "Silahkan isi Alamat Pemohon");
                edAlamat.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edAlamat, "");

            if (edRT.Text == "")
            {
                errorProvider1.SetError(edRT, "Silahkan isi RT");
                edRT.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edRT, "");

            if (edRW.Text == "")
            {
                errorProvider1.SetError(edRW, "Silahkan isi RW");
                edRW.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edRW, "");

            if (edKelurahan.Text == "")
            {
                errorProvider1.SetError(edKelurahan, "Silahkan isi Kelurahan");
                edKelurahan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edKelurahan, "");

            if (cmbKecamatan.Text == "")
            {
                errorProvider1.SetError(cmbKecamatan, "Silahkan isi Kecamatan");
                cmbKecamatan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbKecamatan, "");

            if (!dateTimePickerTglLahir.Checked)
            {
                errorProvider1.SetError(dateTimePickerTglLahir, "Silahkan isi Tanggal Lahir Pemohon");
                dateTimePickerTglLahir.Focus();
                temp = false;
            }
            else errorProvider1.SetError(dateTimePickerTglLahir, "");

            if (edNomor.Text == "")
            {
                errorProvider1.SetError(edNomor, "Silahkan isi Nomor HP");
                edNomor.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edNomor, "");

            if (edPekerjaan.Text == "")
            {
                errorProvider1.SetError(edPekerjaan, "Silahkan isi Pekerjaan");
                edPekerjaan.Focus();
                temp = false;
            }
            else errorProvider1.SetError(edPekerjaan, "");

            if (cmbDaya.Text == "")
            {
                errorProvider1.SetError(cmbDaya, "Silahkan isi Daya Listrik");
                cmbDaya.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbDaya, "");

            if (cmbJenisPembayaran.Text == "")
            {
                errorProvider1.SetError(cmbJenisPembayaran, "Silahkan isi Jenis Pembayaran");
                cmbJenisPembayaran.Focus();
                temp = false;
            }
            else errorProvider1.SetError(cmbJenisPembayaran, "");


            return temp;
        }

        private void clearForm()
        {
            edNama.Clear();
            edIdentitas.Clear();
            edAlamat.Clear();
            edRT.Clear();
            edKelurahan.Clear();
            cmbKecamatan.SelectedIndex = -1;
            edNomor.Clear();
            edPekerjaan.Clear();
            errorProvider1.Clear();
            cmbDaya.SelectedIndex = -1;
            cmbJenisPembayaran.SelectedIndex = -1;
            //tabPagePSB.Enabled = true;
            //tabControl1.SelectedIndex = 0;
        }

        private void edNomor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        
        private void btnUlang_Click(object sender, EventArgs e)
        {
            this.clearForm();
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            this.clearForm();

            this.Hide();
            PermohonanPDLUI myParent = (PermohonanPDLUI)this.Parent;

            if (btnTambah.Text == "Tambahkan")
            {
                myParent.EnableAfterInsert();
            }
            else
            {
                //myParent.EnableAfterEdit();
            }
        }

        private void btnTambahEditPDL_Click(object sender, EventArgs e)
        {
            try
            {
                if (cektxt() == true)
                    {
                        errorProvider1.Clear();
                        int kode_area = kodeAreaControl.getDataIDKodeAreaByNamaKecamatan(cmbKecamatan.Text) ;

                        string resi = ResiTerima();

                        TambahDayaEntity tambah_daya = new TambahDayaEntity(lblNomorPelanggan.Text, int.Parse(cmbDaya.Text));
                        permohonanPDLControl.entryDataTambahDaya(tambah_daya);

                        int id_permohonan_tambahdaya = permohonanPDLControl.getLastIDTambahDaya();

                        PermohonanPSBEntity permohonan = new PermohonanPSBEntity(id_permohonan_tambahdaya, kode_area, edIdentitas.Text, edNama.Text, 
                            dateTimePickerTglLahir.Value.Date, edAlamat.Text + " , RT " + edRT.Text + ", RW " + edRW.Text + ", Kelurahan " + edKelurahan.Text + ", Kecamatan " + cmbKecamatan.Text , 
                            edNomor.Text, edPekerjaan.Text,
                            int.Parse(cmbDaya.Text), cmbJenisPembayaran.Text, resi, 
                            dateTimePickerTglPermohonan.Value.Date, GlobalEntity.deskripsiPermohonan_1);

                        permohonanPSBControl.entryDataPermohonanPDL(permohonan);
                        clearForm();
                        this.Hide();
                        PermohonanPDLUI myParent = (PermohonanPDLUI)this.Parent;
                        myParent.EnableAfterInsert();
                    }
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public string ResiTerima()
        {
            string s = string.Empty;
            s        = "TR"+"-"+
                            DateTime.Now.ToString("dd")+
                            DateTime.Now.ToString("MM")+
                            DateTime.Now.ToString("yy")+
                            "-"+rnd.Next(000, 999);
            return s;
        }

        private void cmbKecamatan_DropDown(object sender, EventArgs e)
        {
            DataTable dt = permohonanPSBControl.getNamaKecamatan();
            cmbKecamatan.DataSource = dt;
            cmbKecamatan.DisplayMember = "NAMA_KECAMATAN";
            cmbKecamatan.ValueMember = "ID_KECAMATAN";
        }
    }
}
