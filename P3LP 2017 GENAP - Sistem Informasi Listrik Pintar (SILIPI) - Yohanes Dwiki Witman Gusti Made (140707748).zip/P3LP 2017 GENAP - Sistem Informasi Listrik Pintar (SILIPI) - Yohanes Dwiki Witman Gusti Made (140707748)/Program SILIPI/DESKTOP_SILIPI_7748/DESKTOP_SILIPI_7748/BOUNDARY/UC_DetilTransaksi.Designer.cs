﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class UC_DetilTransaksi
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl66 = new System.Windows.Forms.Label();
            this.lbl55 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lblJenisMember = new System.Windows.Forms.Label();
            this.lblDayaListrik = new System.Windows.Forms.Label();
            this.lblPekerjaan = new System.Windows.Forms.Label();
            this.lblNomorHP = new System.Windows.Forms.Label();
            this.lblAlamat = new System.Windows.Forms.Label();
            this.lblTglLahir = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.lblIdentitas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textboxx = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNomorMember = new System.Windows.Forms.Label();
            this.lblNomorKWH = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl77 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl88 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl66
            // 
            this.lbl66.AutoSize = true;
            this.lbl66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl66.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl66.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl66.Location = new System.Drawing.Point(177, 147);
            this.lbl66.Name = "lbl66";
            this.lbl66.Size = new System.Drawing.Size(165, 27);
            this.lbl66.TabIndex = 40;
            this.lbl66.Text = "lbl66";
            this.lbl66.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl55
            // 
            this.lbl55.AutoSize = true;
            this.lbl55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl55.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl55.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl55.Location = new System.Drawing.Point(177, 118);
            this.lbl55.Name = "lbl55";
            this.lbl55.Size = new System.Drawing.Size(165, 27);
            this.lbl55.TabIndex = 39;
            this.lbl55.Text = "lbl55";
            this.lbl55.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl44
            // 
            this.lbl44.AutoSize = true;
            this.lbl44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl44.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl44.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl44.Location = new System.Drawing.Point(177, 89);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(165, 27);
            this.lbl44.TabIndex = 38;
            this.lbl44.Text = "lbl44";
            this.lbl44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl33.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl33.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl33.Location = new System.Drawing.Point(177, 60);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(165, 27);
            this.lbl33.TabIndex = 37;
            this.lbl33.Text = "lbl33";
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl22.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl22.Location = new System.Drawing.Point(177, 31);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(165, 27);
            this.lbl22.TabIndex = 36;
            this.lbl22.Text = "lbl22";
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl11.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl11.Location = new System.Drawing.Point(177, 2);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(165, 27);
            this.lbl11.TabIndex = 35;
            this.lbl11.Text = "lbl11";
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblJenisMember
            // 
            this.lblJenisMember.AutoSize = true;
            this.lblJenisMember.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblJenisMember.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJenisMember.Location = new System.Drawing.Point(194, 263);
            this.lblJenisMember.Name = "lblJenisMember";
            this.lblJenisMember.Size = new System.Drawing.Size(148, 28);
            this.lblJenisMember.TabIndex = 22;
            this.lblJenisMember.Text = "label26";
            this.lblJenisMember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDayaListrik
            // 
            this.lblDayaListrik.AutoSize = true;
            this.lblDayaListrik.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDayaListrik.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDayaListrik.Location = new System.Drawing.Point(194, 234);
            this.lblDayaListrik.Name = "lblDayaListrik";
            this.lblDayaListrik.Size = new System.Drawing.Size(148, 27);
            this.lblDayaListrik.TabIndex = 21;
            this.lblDayaListrik.Text = "label25";
            this.lblDayaListrik.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPekerjaan
            // 
            this.lblPekerjaan.AutoSize = true;
            this.lblPekerjaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPekerjaan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPekerjaan.Location = new System.Drawing.Point(194, 205);
            this.lblPekerjaan.Name = "lblPekerjaan";
            this.lblPekerjaan.Size = new System.Drawing.Size(148, 27);
            this.lblPekerjaan.TabIndex = 20;
            this.lblPekerjaan.Text = "label24";
            this.lblPekerjaan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomorHP
            // 
            this.lblNomorHP.AutoSize = true;
            this.lblNomorHP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomorHP.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomorHP.Location = new System.Drawing.Point(194, 176);
            this.lblNomorHP.Name = "lblNomorHP";
            this.lblNomorHP.Size = new System.Drawing.Size(148, 27);
            this.lblNomorHP.TabIndex = 19;
            this.lblNomorHP.Text = "label23";
            this.lblNomorHP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAlamat
            // 
            this.lblAlamat.AutoSize = true;
            this.lblAlamat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlamat.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlamat.Location = new System.Drawing.Point(194, 147);
            this.lblAlamat.Name = "lblAlamat";
            this.lblAlamat.Size = new System.Drawing.Size(148, 27);
            this.lblAlamat.TabIndex = 18;
            this.lblAlamat.Text = "label22";
            this.lblAlamat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTglLahir
            // 
            this.lblTglLahir.AutoSize = true;
            this.lblTglLahir.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTglLahir.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTglLahir.Location = new System.Drawing.Point(194, 118);
            this.lblTglLahir.Name = "lblTglLahir";
            this.lblTglLahir.Size = new System.Drawing.Size(148, 27);
            this.lblTglLahir.TabIndex = 17;
            this.lblTglLahir.Text = "label21";
            this.lblTglLahir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNama.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNama.Location = new System.Drawing.Point(194, 89);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(148, 27);
            this.lblNama.TabIndex = 16;
            this.lblNama.Text = "label20";
            this.lblNama.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdentitas
            // 
            this.lblIdentitas.AutoSize = true;
            this.lblIdentitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdentitas.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentitas.Location = new System.Drawing.Point(194, 60);
            this.lblIdentitas.Name = "lblIdentitas";
            this.lblIdentitas.Size = new System.Drawing.Size(148, 27);
            this.lblIdentitas.TabIndex = 15;
            this.lblIdentitas.Text = "label19";
            this.lblIdentitas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 27);
            this.label4.TabIndex = 0;
            this.label4.Text = "NOMOR MEMBER";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label5.Location = new System.Drawing.Point(5, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 27);
            this.label5.TabIndex = 1;
            this.label5.Text = "NOMOR kWH";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label6.Location = new System.Drawing.Point(5, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 27);
            this.label6.TabIndex = 2;
            this.label6.Text = "KTP / SIM";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label7.Location = new System.Drawing.Point(5, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 27);
            this.label7.TabIndex = 3;
            this.label7.Text = "NAMA PEMOHON";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label8.Location = new System.Drawing.Point(5, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(181, 27);
            this.label8.TabIndex = 4;
            this.label8.Text = "TANGGAL LAHIR";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label9.Location = new System.Drawing.Point(5, 147);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 27);
            this.label9.TabIndex = 5;
            this.label9.Text = "ALAMAT";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label10.Location = new System.Drawing.Point(5, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(181, 27);
            this.label10.TabIndex = 6;
            this.label10.Text = "NOMOR HP";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label11.Location = new System.Drawing.Point(5, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(181, 27);
            this.label11.TabIndex = 7;
            this.label11.Text = "PEKERJAAN";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label12.Location = new System.Drawing.Point(5, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(181, 27);
            this.label12.TabIndex = 8;
            this.label12.Text = "DAYA LISTRIK";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl2.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl2.Location = new System.Drawing.Point(5, 31);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(164, 27);
            this.lbl2.TabIndex = 15;
            this.lbl2.Text = "lbl2";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl1.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl1.Location = new System.Drawing.Point(5, 2);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(164, 27);
            this.lbl1.TabIndex = 22;
            this.lbl1.Text = "lbl1";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl3.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl3.Location = new System.Drawing.Point(5, 60);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(164, 27);
            this.lbl3.TabIndex = 30;
            this.lbl3.Text = "lbl3";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl4.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl4.Location = new System.Drawing.Point(5, 89);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(164, 27);
            this.lbl4.TabIndex = 31;
            this.lbl4.Text = "lbl4";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(5, 118);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(164, 27);
            this.lbl5.TabIndex = 32;
            this.lbl5.Text = "lbl5";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label13.Location = new System.Drawing.Point(5, 263);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(181, 28);
            this.label13.TabIndex = 9;
            this.label13.Text = "JENIS MEMBER";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textboxx
            // 
            this.textboxx.AutoSize = true;
            this.textboxx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textboxx.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxx.Location = new System.Drawing.Point(3, 0);
            this.textboxx.Name = "textboxx";
            this.textboxx.Size = new System.Drawing.Size(654, 39);
            this.textboxx.TabIndex = 1;
            this.textboxx.Text = "LISTRIK PINTAR - Detil Transaksi Member";
            this.textboxx.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(725, 394);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel2.Controls.Add(this.pictureBoxExit, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textboxx, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(715, 34);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_close_outline;
            this.pictureBoxExit.Location = new System.Drawing.Point(663, 3);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(44, 28);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxExit.TabIndex = 0;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(5, 47);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.42345F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.57655F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(715, 342);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(362, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(347, 34);
            this.label3.TabIndex = 1;
            this.label3.Text = "DETAIL TRANSAKSI";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(347, 34);
            this.label2.TabIndex = 0;
            this.label2.Text = "DETAIL MEMBER";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.09434F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.90566F));
            this.tableLayoutPanel4.Controls.Add(this.lblJenisMember, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.lblDayaListrik, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.lblPekerjaan, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.lblNomorHP, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.lblAlamat, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.lblTglLahir, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblNama, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblIdentitas, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label12, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.label13, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.lblNomorMember, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblNomorKWH, 1, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 43);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 10;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(347, 293);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // lblNomorMember
            // 
            this.lblNomorMember.AutoSize = true;
            this.lblNomorMember.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomorMember.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomorMember.Location = new System.Drawing.Point(194, 2);
            this.lblNomorMember.Name = "lblNomorMember";
            this.lblNomorMember.Size = new System.Drawing.Size(148, 27);
            this.lblNomorMember.TabIndex = 13;
            this.lblNomorMember.Text = "label17";
            this.lblNomorMember.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomorKWH
            // 
            this.lblNomorKWH.AutoSize = true;
            this.lblNomorKWH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomorKWH.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomorKWH.Location = new System.Drawing.Point(194, 31);
            this.lblNomorKWH.Name = "lblNomorKWH";
            this.lblNomorKWH.Size = new System.Drawing.Size(148, 27);
            this.lblNomorKWH.TabIndex = 14;
            this.lblNomorKWH.Text = "label18";
            this.lblNomorKWH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.lbl66, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.lbl55, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.lbl44, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.lbl33, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.lbl22, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.lbl11, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.lbl2, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.lbl1, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.lbl3, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.lbl4, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.lbl5, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.lbl6, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.lbl7, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.lbl77, 1, 6);
            this.tableLayoutPanel5.Controls.Add(this.lbl8, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.lbl88, 1, 7);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(362, 43);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 9;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(347, 293);
            this.tableLayoutPanel5.TabIndex = 3;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(5, 147);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(164, 27);
            this.lbl6.TabIndex = 33;
            this.lbl6.Text = "lbl6";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl7.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl7.Location = new System.Drawing.Point(5, 176);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(164, 27);
            this.lbl7.TabIndex = 34;
            this.lbl7.Text = "lbl7";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl77
            // 
            this.lbl77.AutoSize = true;
            this.lbl77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl77.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lbl77.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl77.Location = new System.Drawing.Point(177, 176);
            this.lbl77.Name = "lbl77";
            this.lbl77.Size = new System.Drawing.Size(165, 27);
            this.lbl77.TabIndex = 41;
            this.lbl77.Text = "lbl77";
            this.lbl77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl8.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl8.Location = new System.Drawing.Point(5, 205);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(164, 27);
            this.lbl8.TabIndex = 43;
            this.lbl8.Text = "lbl8";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl88
            // 
            this.lbl88.AutoSize = true;
            this.lbl88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl88.Font = new System.Drawing.Font("Calibri", 12F);
            this.lbl88.Location = new System.Drawing.Point(177, 205);
            this.lbl88.Name = "lbl88";
            this.lbl88.Size = new System.Drawing.Size(165, 27);
            this.lbl88.TabIndex = 42;
            this.lbl88.Text = "lbl88";
            this.lbl88.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UC_DetilTransaksi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_DetilTransaksi";
            this.Size = new System.Drawing.Size(725, 394);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl66;
        private System.Windows.Forms.Label lbl55;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lblJenisMember;
        private System.Windows.Forms.Label lblDayaListrik;
        private System.Windows.Forms.Label lblPekerjaan;
        private System.Windows.Forms.Label lblNomorHP;
        private System.Windows.Forms.Label lblAlamat;
        private System.Windows.Forms.Label lblTglLahir;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Label lblIdentitas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label textboxx;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label lblNomorMember;
        private System.Windows.Forms.Label lblNomorKWH;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl77;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl88;
    }
}
