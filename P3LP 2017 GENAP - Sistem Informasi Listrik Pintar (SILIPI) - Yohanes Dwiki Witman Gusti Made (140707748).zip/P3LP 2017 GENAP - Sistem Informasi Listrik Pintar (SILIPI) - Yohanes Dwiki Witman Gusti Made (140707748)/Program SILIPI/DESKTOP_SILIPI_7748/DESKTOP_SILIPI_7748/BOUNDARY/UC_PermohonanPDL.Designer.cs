﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class UC_PermohonanPDL
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbKecamatan = new System.Windows.Forms.ComboBox();
            this.edRT = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.edRW = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.edKelurahan = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbJenisPembayaran = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimePickerTglPermohonan = new System.Windows.Forms.DateTimePicker();
            this.edPekerjaan = new System.Windows.Forms.TextBox();
            this.cmbDaya = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.edNama = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePickerTglLahir = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.edNomor = new System.Windows.Forms.TextBox();
            this.edIdentitas = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.edAlamat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.edID = new System.Windows.Forms.TextBox();
            this.edIDKecamatan = new System.Windows.Forms.TextBox();
            this.btnBatal = new System.Windows.Forms.Button();
            this.btnUbah = new System.Windows.Forms.Button();
            this.btnTambah = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.lblNomorPelanggan = new System.Windows.Forms.Label();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 42.01474F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.98526F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.cmbJenisPembayaran, 1, 10);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.dateTimePickerTglPermohonan, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.edPekerjaan, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.cmbDaya, 1, 9);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.edNama, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.dateTimePickerTglLahir, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.edNomor, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.edIdentitas, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.edAlamat, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.label15, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblNomorPelanggan, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 43);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 11;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.114992F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.82638F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.117626F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(468, 421);
            this.tableLayoutPanel3.TabIndex = 68;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.86463F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.13537F));
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.cmbKecamatan, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.edRT, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.edRW, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.edKelurahan, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label12, 0, 3);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(200, 154);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(264, 111);
            this.tableLayoutPanel4.TabIndex = 68;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 30);
            this.label1.TabIndex = 33;
            this.label1.Text = "RT";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbKecamatan
            // 
            this.cmbKecamatan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbKecamatan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKecamatan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbKecamatan.FormattingEnabled = true;
            this.cmbKecamatan.Items.AddRange(new object[] {
            "Danurejan",
            "Gedong Tengen",
            "Gondokusuman",
            "Gondomanan"});
            this.cmbKecamatan.Location = new System.Drawing.Point(105, 93);
            this.cmbKecamatan.Name = "cmbKecamatan";
            this.cmbKecamatan.Size = new System.Drawing.Size(156, 26);
            this.cmbKecamatan.TabIndex = 65;
            // 
            // edRT
            // 
            this.edRT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edRT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edRT.Location = new System.Drawing.Point(105, 3);
            this.edRT.MaxLength = 25;
            this.edRT.Name = "edRT";
            this.edRT.Size = new System.Drawing.Size(156, 24);
            this.edRT.TabIndex = 54;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F);
            this.label10.Location = new System.Drawing.Point(3, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 30);
            this.label10.TabIndex = 55;
            this.label10.Text = "RW";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edRW
            // 
            this.edRW.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edRW.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edRW.Location = new System.Drawing.Point(105, 33);
            this.edRW.MaxLength = 25;
            this.edRW.Name = "edRW";
            this.edRW.Size = new System.Drawing.Size(156, 24);
            this.edRW.TabIndex = 56;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F);
            this.label11.Location = new System.Drawing.Point(3, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 30);
            this.label11.TabIndex = 57;
            this.label11.Text = "Kelurahan";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edKelurahan
            // 
            this.edKelurahan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edKelurahan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edKelurahan.Location = new System.Drawing.Point(105, 63);
            this.edKelurahan.MaxLength = 30;
            this.edKelurahan.Name = "edKelurahan";
            this.edKelurahan.Size = new System.Drawing.Size(156, 24);
            this.edKelurahan.TabIndex = 58;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F);
            this.label12.Location = new System.Drawing.Point(3, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 30);
            this.label12.TabIndex = 59;
            this.label12.Text = "Kecamatan";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbJenisPembayaran
            // 
            this.cmbJenisPembayaran.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbJenisPembayaran.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJenisPembayaran.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbJenisPembayaran.FormattingEnabled = true;
            this.cmbJenisPembayaran.Items.AddRange(new object[] {
            "Prabayar",
            "Pascabayar"});
            this.cmbJenisPembayaran.Location = new System.Drawing.Point(200, 392);
            this.cmbJenisPembayaran.Name = "cmbJenisPembayaran";
            this.cmbJenisPembayaran.Size = new System.Drawing.Size(264, 26);
            this.cmbJenisPembayaran.TabIndex = 64;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F);
            this.label9.Location = new System.Drawing.Point(4, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(189, 29);
            this.label9.TabIndex = 52;
            this.label9.Text = "Tgl Permohonan";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F);
            this.label14.Location = new System.Drawing.Point(4, 389);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(189, 31);
            this.label14.TabIndex = 63;
            this.label14.Text = "Jenis Pembayaran";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dateTimePickerTglPermohonan
            // 
            this.dateTimePickerTglPermohonan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePickerTglPermohonan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTglPermohonan.Location = new System.Drawing.Point(200, 4);
            this.dateTimePickerTglPermohonan.Name = "dateTimePickerTglPermohonan";
            this.dateTimePickerTglPermohonan.ShowCheckBox = true;
            this.dateTimePickerTglPermohonan.Size = new System.Drawing.Size(264, 24);
            this.dateTimePickerTglPermohonan.TabIndex = 53;
            // 
            // edPekerjaan
            // 
            this.edPekerjaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edPekerjaan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edPekerjaan.Location = new System.Drawing.Point(200, 332);
            this.edPekerjaan.MaxLength = 15;
            this.edPekerjaan.Name = "edPekerjaan";
            this.edPekerjaan.Size = new System.Drawing.Size(264, 24);
            this.edPekerjaan.TabIndex = 62;
            // 
            // cmbDaya
            // 
            this.cmbDaya.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbDaya.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDaya.FormattingEnabled = true;
            this.cmbDaya.Items.AddRange(new object[] {
            "1300",
            "2200",
            "3500",
            "4400",
            "6600",
            "10000"});
            this.cmbDaya.Location = new System.Drawing.Point(200, 362);
            this.cmbDaya.Name = "cmbDaya";
            this.cmbDaya.Size = new System.Drawing.Size(264, 26);
            this.cmbDaya.TabIndex = 43;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F);
            this.label7.Location = new System.Drawing.Point(4, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(189, 29);
            this.label7.TabIndex = 47;
            this.label7.Text = "Nama Calon Pelanggan";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F);
            this.label13.Location = new System.Drawing.Point(4, 329);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(189, 29);
            this.label13.TabIndex = 61;
            this.label13.Text = "Pekerjaan";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edNama
            // 
            this.edNama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edNama.Location = new System.Drawing.Point(200, 64);
            this.edNama.MaxLength = 50;
            this.edNama.Name = "edNama";
            this.edNama.Size = new System.Drawing.Size(264, 24);
            this.edNama.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F);
            this.label2.Location = new System.Drawing.Point(4, 359);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 29);
            this.label2.TabIndex = 34;
            this.label2.Text = "Daya";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dateTimePickerTglLahir
            // 
            this.dateTimePickerTglLahir.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePickerTglLahir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTglLahir.Location = new System.Drawing.Point(200, 272);
            this.dateTimePickerTglLahir.Name = "dateTimePickerTglLahir";
            this.dateTimePickerTglLahir.ShowCheckBox = true;
            this.dateTimePickerTglLahir.Size = new System.Drawing.Size(264, 24);
            this.dateTimePickerTglLahir.TabIndex = 51;
            this.dateTimePickerTglLahir.Value = new System.DateTime(1990, 4, 26, 16, 49, 0, 0);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F);
            this.label6.Location = new System.Drawing.Point(4, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(189, 29);
            this.label6.TabIndex = 45;
            this.label6.Text = "No. Identitas (KTP/SIM)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edNomor
            // 
            this.edNomor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edNomor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edNomor.Location = new System.Drawing.Point(200, 302);
            this.edNomor.MaxLength = 15;
            this.edNomor.Name = "edNomor";
            this.edNomor.Size = new System.Drawing.Size(264, 24);
            this.edNomor.TabIndex = 42;
            // 
            // edIdentitas
            // 
            this.edIdentitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edIdentitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edIdentitas.Location = new System.Drawing.Point(200, 94);
            this.edIdentitas.MaxLength = 25;
            this.edIdentitas.Name = "edIdentitas";
            this.edIdentitas.Size = new System.Drawing.Size(264, 24);
            this.edIdentitas.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F);
            this.label5.Location = new System.Drawing.Point(4, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(189, 29);
            this.label5.TabIndex = 37;
            this.label5.Text = "Alamat Lengkap";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // edAlamat
            // 
            this.edAlamat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edAlamat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edAlamat.Location = new System.Drawing.Point(200, 124);
            this.edAlamat.MaxLength = 100;
            this.edAlamat.Name = "edAlamat";
            this.edAlamat.Size = new System.Drawing.Size(264, 24);
            this.edAlamat.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F);
            this.label4.Location = new System.Drawing.Point(4, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 29);
            this.label4.TabIndex = 36;
            this.label4.Text = "Nomor HP";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F);
            this.label3.Location = new System.Drawing.Point(4, 269);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 29);
            this.label3.TabIndex = 35;
            this.label3.Text = "Tgl Lahir";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F);
            this.label15.Location = new System.Drawing.Point(4, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(189, 29);
            this.label15.TabIndex = 69;
            this.label15.Text = "Kode Pelanggan";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.edID, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.edIDKecamatan, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 4);
            this.tableLayoutPanel2.TabIndex = 68;
            // 
            // edID
            // 
            this.edID.Location = new System.Drawing.Point(103, 3);
            this.edID.Name = "edID";
            this.edID.Size = new System.Drawing.Size(35, 20);
            this.edID.TabIndex = 44;
            this.edID.Visible = false;
            // 
            // edIDKecamatan
            // 
            this.edIDKecamatan.Location = new System.Drawing.Point(3, 3);
            this.edIDKecamatan.Name = "edIDKecamatan";
            this.edIDKecamatan.Size = new System.Drawing.Size(35, 20);
            this.edIDKecamatan.TabIndex = 66;
            this.edIDKecamatan.Visible = false;
            // 
            // btnBatal
            // 
            this.btnBatal.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnBatal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBatal.FlatAppearance.BorderSize = 0;
            this.btnBatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBatal.Font = new System.Drawing.Font("Segoe UI", 14.25F);
            this.btnBatal.Location = new System.Drawing.Point(3, 3);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(150, 48);
            this.btnBatal.TabIndex = 32;
            this.btnBatal.Text = "Cancel";
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // btnUbah
            // 
            this.btnUbah.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnUbah.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUbah.FlatAppearance.BorderSize = 0;
            this.btnUbah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUbah.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUbah.Location = new System.Drawing.Point(159, 3);
            this.btnUbah.Name = "btnUbah";
            this.btnUbah.Size = new System.Drawing.Size(150, 48);
            this.btnUbah.TabIndex = 33;
            this.btnUbah.Text = "Ulang";
            this.btnUbah.UseVisualStyleBackColor = false;
            this.btnUbah.Click += new System.EventHandler(this.btnUlang_Click);
            // 
            // btnTambah
            // 
            this.btnTambah.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnTambah.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnTambah.FlatAppearance.BorderSize = 0;
            this.btnTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTambah.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTambah.Location = new System.Drawing.Point(315, 3);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(150, 48);
            this.btnTambah.TabIndex = 31;
            this.btnTambah.Text = "Tambah";
            this.btnTambah.UseVisualStyleBackColor = false;
            this.btnTambah.Click += new System.EventHandler(this.btnTambahEditPDL_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel5.Controls.Add(this.btnBatal, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.btnUbah, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.btnTambah, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 470);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(468, 54);
            this.tableLayoutPanel5.TabIndex = 68;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(474, 527);
            this.tableLayoutPanel1.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(468, 30);
            this.label8.TabIndex = 50;
            this.label8.Text = "LISTRIK PINTAR - FORM PSB";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // lblNomorPelanggan
            // 
            this.lblNomorPelanggan.AutoSize = true;
            this.lblNomorPelanggan.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblNomorPelanggan.Font = new System.Drawing.Font("Calibri", 12F);
            this.lblNomorPelanggan.Location = new System.Drawing.Point(200, 31);
            this.lblNomorPelanggan.Name = "lblNomorPelanggan";
            this.lblNomorPelanggan.Size = new System.Drawing.Size(160, 29);
            this.lblNomorPelanggan.TabIndex = 70;
            this.lblNomorPelanggan.Text = "label Nomor Pelanggan";
            this.lblNomorPelanggan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UC_PermohonanPDL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_PermohonanPDL";
            this.Size = new System.Drawing.Size(474, 527);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbKecamatan;
        private System.Windows.Forms.TextBox edRT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox edRW;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox edKelurahan;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbJenisPembayaran;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimePickerTglPermohonan;
        private System.Windows.Forms.TextBox edPekerjaan;
        private System.Windows.Forms.ComboBox cmbDaya;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox edNama;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePickerTglLahir;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox edNomor;
        private System.Windows.Forms.TextBox edIdentitas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox edAlamat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox edID;
        private System.Windows.Forms.TextBox edIDKecamatan;
        private System.Windows.Forms.Button btnBatal;
        public System.Windows.Forms.Button btnUbah;
        public System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblNomorPelanggan;
    }
}
