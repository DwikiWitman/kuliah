﻿namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    partial class UC_PembayaranTagihanPSB
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.textboxx = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblDeskripsi = new System.Windows.Forms.Label();
            this.lblTglPersetujuan = new System.Windows.Forms.Label();
            this.lblTglPermohonan = new System.Windows.Forms.Label();
            this.lblJenisSambungan = new System.Windows.Forms.Label();
            this.lblDaya = new System.Windows.Forms.Label();
            this.lblPekerjaan = new System.Windows.Forms.Label();
            this.lblNomorHP = new System.Windows.Forms.Label();
            this.lblAlamat = new System.Windows.Forms.Label();
            this.lblTglLahir = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.lblIdentitas = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblIDPermohonan = new System.Windows.Forms.Label();
            this.lblKodeArea = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.btnKeluar = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotalTagihan = new System.Windows.Forms.Label();
            this.btnBayar = new System.Windows.Forms.Button();
            this.lblNomorResi = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.edUang = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel2.Controls.Add(this.pictureBoxExit, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textboxx, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(555, 34);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_close_outline;
            this.pictureBoxExit.Location = new System.Drawing.Point(503, 3);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(44, 28);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxExit.TabIndex = 0;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            // 
            // textboxx
            // 
            this.textboxx.AutoSize = true;
            this.textboxx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textboxx.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxx.Location = new System.Drawing.Point(3, 0);
            this.textboxx.Name = "textboxx";
            this.textboxx.Size = new System.Drawing.Size(494, 39);
            this.textboxx.TabIndex = 1;
            this.textboxx.Text = "LISTRIK PINTAR - Pembayaran Tagihan PSB";
            this.textboxx.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(565, 369);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(5, 47);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.42345F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.57655F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(555, 317);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(282, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(267, 32);
            this.label3.TabIndex = 1;
            this.label3.Text = "DETAIL PEMBAYARAN";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(267, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "DETAIL PEMOHON";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.09434F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.90566F));
            this.tableLayoutPanel4.Controls.Add(this.lblDeskripsi, 1, 12);
            this.tableLayoutPanel4.Controls.Add(this.lblTglPersetujuan, 1, 11);
            this.tableLayoutPanel4.Controls.Add(this.lblTglPermohonan, 1, 10);
            this.tableLayoutPanel4.Controls.Add(this.lblJenisSambungan, 1, 9);
            this.tableLayoutPanel4.Controls.Add(this.lblDaya, 1, 8);
            this.tableLayoutPanel4.Controls.Add(this.lblPekerjaan, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.lblNomorHP, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.lblAlamat, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.lblTglLahir, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblNama, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblIdentitas, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 7);
            this.tableLayoutPanel4.Controls.Add(this.label12, 0, 8);
            this.tableLayoutPanel4.Controls.Add(this.label13, 0, 9);
            this.tableLayoutPanel4.Controls.Add(this.label14, 0, 10);
            this.tableLayoutPanel4.Controls.Add(this.label15, 0, 11);
            this.tableLayoutPanel4.Controls.Add(this.label16, 0, 12);
            this.tableLayoutPanel4.Controls.Add(this.lblIDPermohonan, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblKodeArea, 1, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(6, 41);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 13;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.145408F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.25509F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(267, 270);
            this.tableLayoutPanel4.TabIndex = 2;
            // 
            // lblDeskripsi
            // 
            this.lblDeskripsi.AutoSize = true;
            this.lblDeskripsi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDeskripsi.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeskripsi.Location = new System.Drawing.Point(150, 230);
            this.lblDeskripsi.Name = "lblDeskripsi";
            this.lblDeskripsi.Size = new System.Drawing.Size(112, 38);
            this.lblDeskripsi.TabIndex = 25;
            this.lblDeskripsi.Text = "label29";
            this.lblDeskripsi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTglPersetujuan
            // 
            this.lblTglPersetujuan.AutoSize = true;
            this.lblTglPersetujuan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTglPersetujuan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTglPersetujuan.Location = new System.Drawing.Point(150, 211);
            this.lblTglPersetujuan.Name = "lblTglPersetujuan";
            this.lblTglPersetujuan.Size = new System.Drawing.Size(112, 17);
            this.lblTglPersetujuan.TabIndex = 24;
            this.lblTglPersetujuan.Text = "label28";
            this.lblTglPersetujuan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTglPermohonan
            // 
            this.lblTglPermohonan.AutoSize = true;
            this.lblTglPermohonan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTglPermohonan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTglPermohonan.Location = new System.Drawing.Point(150, 192);
            this.lblTglPermohonan.Name = "lblTglPermohonan";
            this.lblTglPermohonan.Size = new System.Drawing.Size(112, 17);
            this.lblTglPermohonan.TabIndex = 23;
            this.lblTglPermohonan.Text = "label27";
            this.lblTglPermohonan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblJenisSambungan
            // 
            this.lblJenisSambungan.AutoSize = true;
            this.lblJenisSambungan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblJenisSambungan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJenisSambungan.Location = new System.Drawing.Point(150, 173);
            this.lblJenisSambungan.Name = "lblJenisSambungan";
            this.lblJenisSambungan.Size = new System.Drawing.Size(112, 17);
            this.lblJenisSambungan.TabIndex = 22;
            this.lblJenisSambungan.Text = "label26";
            this.lblJenisSambungan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDaya
            // 
            this.lblDaya.AutoSize = true;
            this.lblDaya.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDaya.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDaya.Location = new System.Drawing.Point(150, 154);
            this.lblDaya.Name = "lblDaya";
            this.lblDaya.Size = new System.Drawing.Size(112, 17);
            this.lblDaya.TabIndex = 21;
            this.lblDaya.Text = "label25";
            this.lblDaya.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPekerjaan
            // 
            this.lblPekerjaan.AutoSize = true;
            this.lblPekerjaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPekerjaan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPekerjaan.Location = new System.Drawing.Point(150, 135);
            this.lblPekerjaan.Name = "lblPekerjaan";
            this.lblPekerjaan.Size = new System.Drawing.Size(112, 17);
            this.lblPekerjaan.TabIndex = 20;
            this.lblPekerjaan.Text = "label24";
            this.lblPekerjaan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNomorHP
            // 
            this.lblNomorHP.AutoSize = true;
            this.lblNomorHP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomorHP.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomorHP.Location = new System.Drawing.Point(150, 116);
            this.lblNomorHP.Name = "lblNomorHP";
            this.lblNomorHP.Size = new System.Drawing.Size(112, 17);
            this.lblNomorHP.TabIndex = 19;
            this.lblNomorHP.Text = "label23";
            this.lblNomorHP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAlamat
            // 
            this.lblAlamat.AutoSize = true;
            this.lblAlamat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlamat.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlamat.Location = new System.Drawing.Point(150, 97);
            this.lblAlamat.Name = "lblAlamat";
            this.lblAlamat.Size = new System.Drawing.Size(112, 17);
            this.lblAlamat.TabIndex = 18;
            this.lblAlamat.Text = "label22";
            this.lblAlamat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTglLahir
            // 
            this.lblTglLahir.AutoSize = true;
            this.lblTglLahir.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTglLahir.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTglLahir.Location = new System.Drawing.Point(150, 78);
            this.lblTglLahir.Name = "lblTglLahir";
            this.lblTglLahir.Size = new System.Drawing.Size(112, 17);
            this.lblTglLahir.TabIndex = 17;
            this.lblTglLahir.Text = "label21";
            this.lblTglLahir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNama.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNama.Location = new System.Drawing.Point(150, 59);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(112, 17);
            this.lblNama.TabIndex = 16;
            this.lblNama.Text = "label20";
            this.lblNama.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdentitas
            // 
            this.lblIdentitas.AutoSize = true;
            this.lblIdentitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdentitas.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdentitas.Location = new System.Drawing.Point(150, 40);
            this.lblIdentitas.Name = "lblIdentitas";
            this.lblIdentitas.Size = new System.Drawing.Size(112, 17);
            this.lblIdentitas.TabIndex = 15;
            this.lblIdentitas.Text = "label19";
            this.lblIdentitas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "ID PERMOHONAN";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label5.Location = new System.Drawing.Point(5, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "ID KODE AREA";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label6.Location = new System.Drawing.Point(5, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "KTP / SIM";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label7.Location = new System.Drawing.Point(5, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "NAMA PEMOHON";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label8.Location = new System.Drawing.Point(5, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 17);
            this.label8.TabIndex = 4;
            this.label8.Text = "TANGGAL LAHIR";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label9.Location = new System.Drawing.Point(5, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "ALAMAT";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label10.Location = new System.Drawing.Point(5, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(137, 17);
            this.label10.TabIndex = 6;
            this.label10.Text = "NOMOR HP";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label11.Location = new System.Drawing.Point(5, 135);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "PEKERJAAN";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label12.Location = new System.Drawing.Point(5, 154);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 17);
            this.label12.TabIndex = 8;
            this.label12.Text = "DAYA";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label13.Location = new System.Drawing.Point(5, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 17);
            this.label13.TabIndex = 9;
            this.label13.Text = "JENIS SAMBUNGAN";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label14.Location = new System.Drawing.Point(5, 192);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(137, 17);
            this.label14.TabIndex = 10;
            this.label14.Text = "TGL PERMOHONAN";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label15.Location = new System.Drawing.Point(5, 211);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(137, 17);
            this.label15.TabIndex = 11;
            this.label15.Text = "TGL PERSETUJUAN";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.label16.Location = new System.Drawing.Point(5, 230);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(137, 38);
            this.label16.TabIndex = 12;
            this.label16.Text = "DESKRIPSI";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIDPermohonan
            // 
            this.lblIDPermohonan.AutoSize = true;
            this.lblIDPermohonan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIDPermohonan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDPermohonan.Location = new System.Drawing.Point(150, 2);
            this.lblIDPermohonan.Name = "lblIDPermohonan";
            this.lblIDPermohonan.Size = new System.Drawing.Size(112, 17);
            this.lblIDPermohonan.TabIndex = 13;
            this.lblIDPermohonan.Text = "label17";
            this.lblIDPermohonan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblKodeArea
            // 
            this.lblKodeArea.AutoSize = true;
            this.lblKodeArea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblKodeArea.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKodeArea.Location = new System.Drawing.Point(150, 21);
            this.lblKodeArea.Name = "lblKodeArea";
            this.lblKodeArea.Size = new System.Drawing.Size(112, 17);
            this.lblKodeArea.TabIndex = 14;
            this.lblKodeArea.Text = "label18";
            this.lblKodeArea.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.btnKeluar, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.btnBayar, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.lblNomorResi, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label31, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label30, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 1, 2);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(282, 41);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(267, 270);
            this.tableLayoutPanel5.TabIndex = 3;
            // 
            // btnKeluar
            // 
            this.btnKeluar.BackColor = System.Drawing.Color.Silver;
            this.btnKeluar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnKeluar.FlatAppearance.BorderSize = 0;
            this.btnKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeluar.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btnKeluar.ForeColor = System.Drawing.Color.Black;
            this.btnKeluar.Location = new System.Drawing.Point(5, 206);
            this.btnKeluar.Name = "btnKeluar";
            this.btnKeluar.Size = new System.Drawing.Size(124, 59);
            this.btnKeluar.TabIndex = 24;
            this.btnKeluar.Text = "Cancel";
            this.btnKeluar.UseVisualStyleBackColor = false;
            this.btnKeluar.Click += new System.EventHandler(this.pictureBoxExit_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.lblTotalTagihan, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(137, 72);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(125, 59);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 59);
            this.label1.TabIndex = 21;
            this.label1.Text = "Rp. ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalTagihan
            // 
            this.lblTotalTagihan.AutoSize = true;
            this.lblTotalTagihan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTotalTagihan.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lblTotalTagihan.Location = new System.Drawing.Point(43, 0);
            this.lblTotalTagihan.Name = "lblTotalTagihan";
            this.lblTotalTagihan.Size = new System.Drawing.Size(79, 59);
            this.lblTotalTagihan.TabIndex = 20;
            this.lblTotalTagihan.Text = "label35";
            this.lblTotalTagihan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnBayar
            // 
            this.btnBayar.BackColor = System.Drawing.Color.LimeGreen;
            this.btnBayar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnBayar.FlatAppearance.BorderSize = 0;
            this.btnBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBayar.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            this.btnBayar.ForeColor = System.Drawing.Color.White;
            this.btnBayar.Image = global::DESKTOP_SILIPI_7748.Properties.Resources.Image_hand_streched_money_dollar_outline;
            this.btnBayar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBayar.Location = new System.Drawing.Point(137, 206);
            this.btnBayar.Name = "btnBayar";
            this.btnBayar.Size = new System.Drawing.Size(125, 59);
            this.btnBayar.TabIndex = 25;
            this.btnBayar.Text = "Bayar!";
            this.btnBayar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBayar.UseVisualStyleBackColor = false;
            this.btnBayar.Click += new System.EventHandler(this.btnBayar_Click);
            // 
            // lblNomorResi
            // 
            this.lblNomorResi.AutoSize = true;
            this.lblNomorResi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNomorResi.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.lblNomorResi.Location = new System.Drawing.Point(137, 2);
            this.lblNomorResi.Name = "lblNomorResi";
            this.lblNomorResi.Size = new System.Drawing.Size(125, 65);
            this.lblNomorResi.TabIndex = 19;
            this.lblNomorResi.Text = "label34";
            this.lblNomorResi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(5, 136);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(124, 65);
            this.label31.TabIndex = 16;
            this.label31.Text = "Uang Anda";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(5, 69);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(124, 65);
            this.label30.TabIndex = 15;
            this.label30.Text = "Total Tagihan";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(5, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 65);
            this.label17.TabIndex = 22;
            this.label17.Text = "Nomor Resi";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel7, 1, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(137, 139);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(125, 59);
            this.tableLayoutPanel6.TabIndex = 26;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 59);
            this.label18.TabIndex = 0;
            this.label18.Text = "Rp. ";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.edUang, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(43, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 3;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.78698F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.60651F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.60651F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(79, 53);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // edUang
            // 
            this.edUang.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.edUang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edUang.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edUang.Location = new System.Drawing.Point(3, 21);
            this.edUang.Name = "edUang";
            this.edUang.Size = new System.Drawing.Size(73, 20);
            this.edUang.TabIndex = 0;
            this.edUang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.edUang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.edUang_KeyPress_1);
            // 
            // UC_PembayaranTagihanPSB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_PembayaranTagihanPSB";
            this.Size = new System.Drawing.Size(565, 369);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lblDeskripsi;
        private System.Windows.Forms.Label lblTglPersetujuan;
        private System.Windows.Forms.Label lblTglPermohonan;
        private System.Windows.Forms.Label lblJenisSambungan;
        private System.Windows.Forms.Label lblDaya;
        private System.Windows.Forms.Label lblPekerjaan;
        private System.Windows.Forms.Label lblNomorHP;
        private System.Windows.Forms.Label lblAlamat;
        private System.Windows.Forms.Label lblTglLahir;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Label lblIdentitas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblIDPermohonan;
        private System.Windows.Forms.Label lblKodeArea;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lblNomorResi;
        private System.Windows.Forms.Label lblTotalTagihan;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnKeluar;
        private System.Windows.Forms.Button btnBayar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TextBox edUang;
        private System.Windows.Forms.Label textboxx;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label1;
    }
}
