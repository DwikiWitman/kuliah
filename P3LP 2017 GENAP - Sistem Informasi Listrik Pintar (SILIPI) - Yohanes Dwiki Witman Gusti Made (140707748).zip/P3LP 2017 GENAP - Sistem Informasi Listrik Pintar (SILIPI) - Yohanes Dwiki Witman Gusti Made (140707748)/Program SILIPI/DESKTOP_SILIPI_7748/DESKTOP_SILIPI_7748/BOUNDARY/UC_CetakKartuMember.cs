﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748.BOUNDARY
{
    public partial class UC_CetakKartuMember : UserControl
    {
        CetakKartuMember cetakKartuMember;

        public UC_CetakKartuMember()
        {
            InitializeComponent();
        }

        public void setDataTagihanPSB(PegawaiEntity data_pegawai, DataTable data_member)
        {
            cetakKartuMember = new CetakKartuMember();
            cetakKartuMember.SetDataSource(data_member);
            cetakKartuMember.SetParameterValue("namaPegawai", data_pegawai.NAMA_PEGAWAI);

            crystalReportViewer1.ReportSource = cetakKartuMember;
            crystalReportViewer1.Show();
            crystalReportViewer1.Refresh();
        }

        private void pictureBoxExit_Click(object sender, EventArgs e)
        {
            cetakKartuMember.Dispose();

            CetakKartuMemberUI myParent = (CetakKartuMemberUI)this.Parent;
            myParent.EnableAfterPrint();
            this.Enabled = false;
            this.Visible = false;
            this.Hide();
        }
    }
}
