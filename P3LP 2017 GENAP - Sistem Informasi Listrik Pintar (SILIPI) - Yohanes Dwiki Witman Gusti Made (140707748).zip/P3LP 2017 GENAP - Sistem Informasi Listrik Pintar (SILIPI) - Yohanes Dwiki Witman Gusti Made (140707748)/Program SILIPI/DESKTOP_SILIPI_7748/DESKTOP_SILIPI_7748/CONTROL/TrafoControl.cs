﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class TrafoControl
    {
        TBL_TRAFOTableAdapter tbl_trafo = new TBL_TRAFOTableAdapter();

        public DataTable getDataTrafo()
        {
            return tbl_trafo.GetData();
        }

        public void tambahDayaTerpakai(int daya_terpakai, int id_trafo)
        {
            tbl_trafo.TambahDataDayaTerpakai(daya_terpakai, id_trafo);
        }
    }
}
