﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class TagihanPascbayarControl
    {
        TBL_MEMBERTableAdapter tbl_permohonan = new TBL_MEMBERTableAdapter();
        TBL_TAGIHANPASCABAYARTableAdapter tbl_tagihan_pascabayar = new TBL_TAGIHANPASCABAYARTableAdapter();

        public DataTable getDataTagihanPascabayar()
        {
            return tbl_tagihan_pascabayar.GetData();
        }

        public DataTable getDataTagihanPascabayar_ByID(int id_tagihanpascabayar)
        {
            return tbl_tagihan_pascabayar.GetDataByID(id_tagihanpascabayar);
        }

        public int getDataMeteranBulanLalu_ByIDMember(int id_member)
        {
            int? kwh = (int?) tbl_tagihan_pascabayar.GetDataMeteranBulanLaluByIDMember(id_member);
            if ((kwh ?? 0) == 0)
                return 0;
            else
                return kwh.Value;
        }

        public DataTable getDataTagihanPascabayar_ByIDMember(int id_member)
        {
            return tbl_tagihan_pascabayar.GetDataTagihanPascabayarByIDMember(id_member);
        }

        public void entryDataTagihanPascabayar(TagihanPascabayarEntity T)
        {
            try
            {
                tbl_tagihan_pascabayar.EntryDataTagihanPascabayar(T.ID_MEMBER, T.ID_TARIF, T.KWH_SEBELUM, T.KWH_SESUDAH, T.BULAN_TAGIHAN, T.TAHUN_TAGIHAN, T.TOTAL_TAGIHAN_PASCABAYAR, T.STATUS_TAGIHAN_PASCABAYAR);
                MessageBox.Show("Pencatatan Berhasil!", "Information");
            }
            catch (SqlException e)
            {
                switch (e.Number)
                {
                    case 2601:
                        MessageBox.Show("" + e.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    default:
                        MessageBox.Show("" + e.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
        }

        public void updateDataTagihanPascabayar(string status_tagihan, int id_tagihanpascabayar)
        {
            tbl_tagihan_pascabayar.UpdateDataTagihanPascabayar(status_tagihan, id_tagihanpascabayar);
        }

        public DataTable searchDataTagihanPascabayar_ByNomorPelanggan_ByNomorKwh(string keyword)
        {
            return tbl_tagihan_pascabayar.SearchDataTagihanPascabayarByNomorPelanggan(keyword);
        }
    }
}
