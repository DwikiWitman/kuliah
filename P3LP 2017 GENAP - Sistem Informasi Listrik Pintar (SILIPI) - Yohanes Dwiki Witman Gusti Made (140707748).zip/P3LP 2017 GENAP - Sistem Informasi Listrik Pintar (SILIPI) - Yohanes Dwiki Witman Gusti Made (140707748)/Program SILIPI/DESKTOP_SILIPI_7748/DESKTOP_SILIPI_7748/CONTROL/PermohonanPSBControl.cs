﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class PermohonanPSBControl
    {
        TBL_PERMOHONANTableAdapter tbl_permohonan = new TBL_PERMOHONANTableAdapter();
        TBL_KECAMATANTableAdapter tbl_kecamatan = new TBL_KECAMATANTableAdapter();
        TBL_KODEAREATableAdapter tbl_kodearea = new TBL_KODEAREATableAdapter();

        public DataTable getDataPermohonanPSB()
        {
            return tbl_permohonan.GetData();
        }

        public DataTable getDataPermohonanPSB_BelumTerverifikasi()
        {
            return tbl_permohonan.GetDataPermohonanPSB_BelumTerverifikasi();
        }

        public DataTable getDataPermohonanPSB_ByID(int id_permohonan)
        {
            return tbl_permohonan.GetDataByID(id_permohonan);
        }

        public DataTable getNamaKecamatan()
        {
            return tbl_kecamatan.GetDataNamaKecamatan();
        }

        public DataTable getDataPenerimaanPSB()
        {
            return tbl_permohonan.GetDataPenerimaanPSB();
        }

        public void entryDataPermohonanPSB(PermohonanPSBEntity PP)
        {
            tbl_permohonan.EntryDataPermohonanPSB(PP.ID_KODE_AREA, PP.IDENTITAS_PEMOHON, PP.NAMA_PEMOHON, PP.TANGGAL_LAHIR_PEMOHON, PP.ALAMAT_PEMOHON, PP.NOMOR_HP_PEMOHON, PP.PEKERJAAN_PEMOHON, PP.DAYA_PERMOHONAN, PP.JENIS_SAMBUNGAN, PP.NOMOR_RESI, PP.TANGGAL_PERMOHONAN, PP.DESKRIPSI);
        }

        public void updateDataPenolakanPSB(PermohonanPSBEntity PP)
        {
            tbl_permohonan.UpdateDataPenolakanPSB(PP.NOMOR_RESI, PP.TANGGAL_PENOLAKAN, PP.DESKRIPSI, PP.ID_PERMOHONAN);
        }

        public void updateDataPenerimaanPSB(PermohonanPSBEntity PP)
        {
            tbl_permohonan.UpdateDataPenerimaanPSB(PP.NOMOR_RESI, PP.TANGGAL_PERSETUJUAN, PP.DESKRIPSI, PP.ID_PERMOHONAN);
        }

        public DataTable searchDataPermohonanPSB(string keyword)
        {
            return tbl_permohonan.SearchDataPermohonanPSB(keyword);
        }

        public void updateDataDeskripsiPSB(string deskripsi, int id_permohonanpsb)
        {
            tbl_permohonan.UpdateDataDeskripsiPSB(deskripsi, id_permohonanpsb);
        }


        //PDL in data permohonan
        public void entryDataPermohonanPDL(PermohonanPSBEntity PP)
        {
            tbl_permohonan.EntryDataPermohonanPDL(PP.ID_PERMOHONAN_TAMBAH_DAYA, PP.ID_KODE_AREA, PP.IDENTITAS_PEMOHON, PP.NAMA_PEMOHON, PP.TANGGAL_LAHIR_PEMOHON, PP.ALAMAT_PEMOHON, PP.NOMOR_HP_PEMOHON, PP.PEKERJAAN_PEMOHON, PP.DAYA_PERMOHONAN, PP.JENIS_SAMBUNGAN, PP.NOMOR_RESI, PP.TANGGAL_PERMOHONAN, PP.DESKRIPSI);
        }

        public DataTable getDataPenerimaanPDL()
        {
            return tbl_permohonan.GetDataPenerimaanPDL();
        }

        public DataTable searchDataPermohonanPDL(string keyword)
        {
            return tbl_permohonan.SearchDataPermohonanPDL(keyword);
        }
    }
}
