﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class TokenControl
    {
        TBL_TOKENTableAdapter tbl_token = new TBL_TOKENTableAdapter();

        public DataTable getDataToken()
        {
            return tbl_token.GetData();
        }

        public DataTable getDataTokenByID(int id_token)
        {
            return tbl_token.GetDataByID(id_token);
        }

        public int getLastIDToken()
        {
            return tbl_token.GetLastIDToken().Value;
        }

        public void entryDataToken(TokenEntity T)
        {
            tbl_token.EntryDataToken(T.NOMOR_TOKEN, T.NOMINAL_TOKEN, T.HARGA_TOKEN);
        }
    }
}
