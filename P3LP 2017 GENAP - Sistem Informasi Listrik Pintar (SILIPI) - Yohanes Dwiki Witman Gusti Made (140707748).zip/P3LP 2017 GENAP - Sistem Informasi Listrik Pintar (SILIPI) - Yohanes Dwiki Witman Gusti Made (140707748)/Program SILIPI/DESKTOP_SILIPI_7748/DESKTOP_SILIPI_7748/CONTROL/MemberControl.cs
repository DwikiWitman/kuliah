﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class MemberControl
    {
        TBL_MEMBERTableAdapter tbl_member = new TBL_MEMBERTableAdapter();

        public DataTable getDataMember()
        {
            return tbl_member.GetData();
        }

        public DataTable getDataMemberByID(int id_member)
        {
            return tbl_member.GetDataByID(id_member);
        }

        public DataTable getDataMemberByNomorPelanggan(string nomor_pelanggan)
        {
            return tbl_member.GetDataMemberByNomorMember(nomor_pelanggan);
        }

        public DataTable getDataMemberPrabayar()
        {
            return tbl_member.GetDataMemberPrabayar();
        }

        public DataTable getDataMemberPascabayar()
        {
            return tbl_member.GetDataMemberPascabayar();
        }

        public DataTable searchDataMemberPrabayar(string nomor)
        {
            return tbl_member.SearchDataMemberPrabayar(nomor);
        }

        public DataTable searchDataMemberPascabayar(string nomor)
        {
            return tbl_member.SearchDataMemberPascabayar(nomor);
        }

        public DataTable searchDataMember(string nomor)
        {
            return tbl_member.SearchDataMember(nomor);
        }

        public void entryDataMember(MemberEntity M)
        {
            tbl_member.EntryDataMember(M.NOMOR_KTP, M.NOMOR_MEMBER, M.NOMOR_KWH, M.NAMA_MEMBER, M.TANGGAL_LAHIR_MEMBER.Date, M.ALAMAT_INSTALASI, M.NOMOR_HP_MEMBER, M.PEKERJAAN, M.DAYA_LISTRIK, M.TIPE_MEMBER, M.STATUS);
        }

        public void updateDataStatusPemasangan(string status, int id_member)
        {
            tbl_member.UpdateDataStatusPemasangan(status, id_member);
        }
    }
}
