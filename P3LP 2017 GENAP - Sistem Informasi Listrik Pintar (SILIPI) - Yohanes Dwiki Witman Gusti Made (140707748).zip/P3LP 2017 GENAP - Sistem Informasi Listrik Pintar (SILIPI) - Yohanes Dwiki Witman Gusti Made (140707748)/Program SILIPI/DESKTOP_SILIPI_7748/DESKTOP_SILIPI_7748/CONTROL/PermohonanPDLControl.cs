﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class PermohonanPDLControl
    {
        TBL_PERMOHONANTableAdapter tbl_permohonanPSB = new TBL_PERMOHONANTableAdapter();
        TBL_TAMBAHDAYATableAdapter tbl_permohonanPDL = new TBL_TAMBAHDAYATableAdapter();

        public DataTable getDataPermohonanPDL()
        {
            return tbl_permohonanPDL.GetData();
        }

        public void entryDataTambahDaya(TambahDayaEntity TD)
        {
            tbl_permohonanPDL.EntryDataTambahDaya(TD.NOMOR_MEMBER, TD.DAYA_LISTRIK_BARU);
        }

        public int getLastIDTambahDaya()
        {
            return tbl_permohonanPDL.GetLastIDTambahDaya().Value;
        }

        public string getNomorPelangganByIDTambahDaya(int id_permohonan_pdl)
        {
            return tbl_permohonanPDL.GetDataNomorPelanggan(id_permohonan_pdl);
        }
    }
}
