﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    public class TagihanPSBControl
    {
        TBL_PERMOHONANTableAdapter tbl_permohonan = new TBL_PERMOHONANTableAdapter();
        TBL_TAGIHANPERMOHONANTableAdapter tbl_tagihanpsb = new TBL_TAGIHANPERMOHONANTableAdapter();

        public DataTable getDataTagihanPSB()
        {
            return tbl_tagihanpsb.GetData();
        }

        public DataTable getDataTagihanPSB_ByIDTagihan(int id_tagihan)
        {
            return tbl_tagihanpsb.GetDataByIDTagihan(id_tagihan);
        }

        public DataTable getDataTagihanPSB_ByNomorResi(string nomor_resi)
        {
            return tbl_tagihanpsb.GetDataTagihanPSBByNomorResi(nomor_resi);
        }

        public int getDataIDPermohonanByIDTagihanPSB(int id_tagihan_psb)
        {
            return tbl_tagihanpsb.GetDataIDPermohonanByIDTagihanPSB(id_tagihan_psb).Value;
        }

        public void entryDataTagihanPSB(TagihanPSBEntity T)
        {
            try
            {
                tbl_tagihanpsb.EntryDataTagihanPSB(T.ID_PERMOHONAN, T.ID_PEGAWAI, T.ID_TARIF, T.TOTAL_TAGIHAN_PERMOHONAN, T.STATUS_TAGIHAN_PERMOHOHAN, T.TANGGAL_TAGIHAN_PERMOHONAN);
            }
            catch (SqlException e)
            {
                switch (e.Number)
                {
                    case 2601:
                        MessageBox.Show(""+e.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    default:
                        MessageBox.Show(""+e.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
        }

        
        public void updateDataTagihanPSB(string status_tagihan, int id_tagihanpsb)
        {
            tbl_tagihanpsb.UpdateDataTagihanPSB(status_tagihan, id_tagihanpsb);
        }
    }
}
