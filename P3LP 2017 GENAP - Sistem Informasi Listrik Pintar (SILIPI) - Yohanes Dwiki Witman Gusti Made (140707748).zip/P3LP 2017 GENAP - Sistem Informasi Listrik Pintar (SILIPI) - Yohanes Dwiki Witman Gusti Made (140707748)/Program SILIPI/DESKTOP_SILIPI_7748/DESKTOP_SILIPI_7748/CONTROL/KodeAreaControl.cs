﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class KodeAreaControl
    {
        TBL_KODEAREATableAdapter tbl_kodearea = new TBL_KODEAREATableAdapter();

        public DataTable getDataKodeArea()
        {
            return tbl_kodearea.GetData();
        }

        public int getDataIDTrafoByIDKodeArea(int id_kode_area)
        {
            return tbl_kodearea.GetDataIDTrafoByIDKodeArea(id_kode_area).Value;
        }

        public int getDataIDKodeAreaByNamaKecamatan(string nama_kecamatan)
        {
            return tbl_kodearea.GetDataIDKodeAreaByNamaKecamatan(nama_kecamatan).Value;
        }
    }
}
