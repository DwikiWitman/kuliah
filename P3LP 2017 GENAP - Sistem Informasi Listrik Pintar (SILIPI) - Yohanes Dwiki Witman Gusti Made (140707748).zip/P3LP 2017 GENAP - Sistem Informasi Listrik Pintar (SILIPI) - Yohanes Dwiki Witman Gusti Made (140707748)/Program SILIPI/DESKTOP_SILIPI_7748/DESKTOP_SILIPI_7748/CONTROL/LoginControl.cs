﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class LoginControl
    {
        TBL_PEGAWAITableAdapter tbl_pegawai = new TBL_PEGAWAITableAdapter();
        TBL_JABATANTableAdapter tbl_jabatan = new TBL_JABATANTableAdapter();

        public PegawaiEntity getDataPegawai(int id_pegawai)
        {
            DataTable DT = tbl_pegawai.GetDataPegawaiByID(id_pegawai);
            PegawaiEntity P = new PegawaiEntity();
            foreach (DataRow DR in DT.Rows)
            {
                    P = new PegawaiEntity
                    (
                        int.Parse(DR["id_pegawai"].ToString()),
                        int.Parse(DR["id_jabatan"].ToString()),
                        DR["nama_pegawai"].ToString(),
                        DR["username_pegawai"].ToString()
                    );
            }
   
            return P;
        }

        public bool cekLogin(string user, string password)
        {
            bool cek = false;
            try
            {
                if (tbl_pegawai.GetUsername(user, password).ToString() != "")
                {
                    cek = true;
                }
                else
                {
                    cek = false;
                }
            }
            catch (Exception ex) { ex.ToString(); }
            return cek;
        }

        public int getIDJabatanPegawai(string user, string password)
        {
            int role = 0;
            try
            {
                role = int.Parse(tbl_pegawai.GetIDJabatan(user, password).ToString());
            }
            catch (Exception ex)
            {
                role = 0;
                ex.ToString();
            }
            return role;
        }

        public string getNamaJabatanPegawai(int id_jabatan)
        {
            string role = "";
            try
            {
                role = tbl_jabatan.GetNamaJabatan(id_jabatan).ToString();
            }
            catch (Exception ex)
            {
                role = "";
                ex.ToString();
            }
            return role;
        }

        public int getIDPegawai(string user, string password)
        {
            int id_pegawai = 0;
            try
            {
                id_pegawai = int.Parse(tbl_pegawai.GetIDPegawai(user, password).ToString());
            }
            catch (Exception ex)
            {
                id_pegawai = 0;
                ex.ToString();
            }
            
            return id_pegawai;
        }
    }
}
