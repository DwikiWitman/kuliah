﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class TarifControl
    {
        TBL_TARIFTableAdapter tbl_tarif = new TBL_TARIFTableAdapter();

        public DataTable getDataTarifPSB()
        {
            return tbl_tarif.GetDataTarifPSB();
        }

        public DataTable getDataTarifBulanan()
        {
            return tbl_tarif.GetDataTarifBulanan();
        }

        public DataTable getDataTarifPSB_ByBeban(int beban)
        {
            return tbl_tarif.GetDataTarifPSBByBeban(beban);
        }

        public void entryDataTarifPSB(TarifEntity T)
        {
            tbl_tarif.EntryDataTarifPSB(T.KATEGORI_TARIF, T.BEBAN, T.BIAYA_UJL, T.BIAYA_SAMBUNG, T.IS_TARIF_PSB);
        }

        public void entryDataTarifBulanan(TarifEntity T)
        {
            tbl_tarif.EntryDataTarifBulanan(T.KATEGORI_TARIF, T.BEBAN, T.BIAYA_BEBAN, T.BIAYA_PEMAKAIAN, T.IS_TARIF_PASCABAYAR);
        }

        public void editDataTarifPSB(TarifEntity T)
        {
            tbl_tarif.UpdateDataTarifPSB(T.KATEGORI_TARIF, T.BEBAN, T.BIAYA_UJL, T.BIAYA_SAMBUNG, T.IS_TARIF_PSB, T.ID_TARIF);
        }

        public void editDataTarifBulanan(TarifEntity T)
        {
            tbl_tarif.UpdateDataTarifBulanan(T.KATEGORI_TARIF, T.BEBAN, T.BIAYA_BEBAN, T.BIAYA_PEMAKAIAN, T.IS_TARIF_PASCABAYAR, T.ID_TARIF);
        }

        public void deleteDataTarif(int ID_TARIF)
        {
            tbl_tarif.DeleteDataTarif(ID_TARIF);
        }

        public DataTable searchDataTarifPSB(string KEYWORD)
        {
            return tbl_tarif.SearchDataTarifPSB(KEYWORD);
        }

        public DataTable searchDataTarifBulanan(string KEYWORD)
        {
            return tbl_tarif.SearchDataTarifBulanan(KEYWORD);
        }

        public DataTable getDataTarifPascabayar_ByBeban(int beban)
        {
            return tbl_tarif.GetDataTarifPascabayarByBeban(beban);
        }
    }
}
