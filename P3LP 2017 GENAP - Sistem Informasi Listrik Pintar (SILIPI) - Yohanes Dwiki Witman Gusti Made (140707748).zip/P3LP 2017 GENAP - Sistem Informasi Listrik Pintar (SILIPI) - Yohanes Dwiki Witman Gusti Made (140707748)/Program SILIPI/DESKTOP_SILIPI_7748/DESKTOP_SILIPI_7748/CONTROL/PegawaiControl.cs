﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DESKTOP_SILIPI_7748.ENTITY;
using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using System.Data;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class PegawaiControl
    {
        TBL_PEGAWAITableAdapter tbl_pegawai = new TBL_PEGAWAITableAdapter();
        TBL_JABATANTableAdapter tbl_jabatan = new TBL_JABATANTableAdapter();
        
        public DataTable getDataPegawai()
        {
            return tbl_pegawai.GetData();
        }

        public DataTable getDataFinePegawai()
        {
            return tbl_pegawai.GetDataFine();
        }

        public DataTable getJabatanPegawai()
        {
            return tbl_jabatan.GetData();
        }

        public string getNamaJabatan(int id_jabatan)
        {
            return tbl_jabatan.GetNamaJabatan(id_jabatan).ToString();
        }

        public int getIDJabatan(string nama_jabatan)
        {
            return tbl_jabatan.GetIDJabatan(nama_jabatan).Value;
        }

        public void entryDataPegawai(PegawaiEntity P)
        {
            tbl_pegawai.EntryDataPegawai(P.ID_JABATAN, P.NAMA_PEGAWAI, P.TANGGAL_LAHIR_PEGAWAI.Date, P.ALAMAT_PEGAWAI, P.NOMOR_HP_PEGAWAI, P.USERNAME_PEGAWAI, P.PASSWORD_PEGAWAI);
        }

        public void editDataPegawai(PegawaiEntity P)
        {
            tbl_pegawai.UpdateDataPegawai(P.ID_JABATAN, P.NAMA_PEGAWAI, P.TANGGAL_LAHIR_PEGAWAI.Date, P.ALAMAT_PEGAWAI, P.NOMOR_HP_PEGAWAI, P.USERNAME_PEGAWAI, P.PASSWORD_PEGAWAI, P.ID_PEGAWAI);
        }

        public void deleteDataPegawai(int id_pegawai)
        {
            tbl_pegawai.DeleteDataPegawai(id_pegawai);
        }

        public DataTable searchDataPegawai(string keyword)
        {
            return tbl_pegawai.SearchDataPegawai(keyword);
        }
    }
}
