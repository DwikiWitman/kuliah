﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class DetilTransaksiControl
    {
        TBL_DETILTRANSAKSITableAdapter tbl_detil_transaksi = new TBL_DETILTRANSAKSITableAdapter();

        public DataTable getDataDetilTransaksi()
        {
            return tbl_detil_transaksi.GetData();
        }

        public DataTable getDataDetilTransaksiByID(int id_detiltransaksi)
        {
            return tbl_detil_transaksi.GetDataByID(id_detiltransaksi);
        }

        public void entryDataDetilTransaksi(DetilTransaksiEntity DT)
        {
            tbl_detil_transaksi.EntryDataDetilTransaksi(DT.JENIS_TAGIHAN, DT.CHANNEL_PEMBAYARAN);
        }

        public void entryDataDetilTransaksiToken(DetilTransaksiEntity DT)
        {
            
            tbl_detil_transaksi.EntryDataDetilTransaksiToken(DT.JENIS_TAGIHAN, DT.CHANNEL_PEMBAYARAN, DT.JUMLAH_TOKEN);
        }

        public int getLastIDDetilTransaksi()
        {
            return tbl_detil_transaksi.GetLastIDDetilTransaksi().Value;
        }
    }
}
