﻿using DESKTOP_SILIPI_7748.DB_SILIPITableAdapters;
using DESKTOP_SILIPI_7748.ENTITY;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.CONTROL
{
    class TransaksiControl
    {
        TBL_TRANSAKSITableAdapter tbl_transaksi = new TBL_TRANSAKSITableAdapter();

        public DataTable getDataTransaksi()
        {
            return tbl_transaksi.GetData();
        }

        public DataTable getDataTransaksiByID(int id_transaksi)
        {
            return tbl_transaksi.GetDataTransaksiByID(id_transaksi);
        }

        public DataTable getDataTransaksiByIDMember(int id_member)
        {
            return tbl_transaksi.GetDataByIDMember(id_member);
        }

        public void entryDataTransaksiPSB(TransaksiEntity T)
        {
            tbl_transaksi.EntryDataTransaksiPSB(T.ID_DETIL_TRANSAKSI, T.ID_TAGIHAN_PERMOHONAN, T.ID_PEGAWAI, T.TANGGAL_TRANSAKSI, T.TOTAL_PEMBAYARAN);
        }

        public void entryDataTransaksiPascabayar(TransaksiEntity T)
        {
            tbl_transaksi.EntryDataTransaksiPascabayar(T.ID_DETIL_TRANSAKSI, T.ID_TAGIHAN_PASCABAYAR, T.ID_MEMBER, T.ID_PEGAWAI, T.TANGGAL_TRANSAKSI, T.TOTAL_PEMBAYARAN);
        }

        public void entryDataTransaksiToken(TransaksiEntity T)
        {
            tbl_transaksi.EntryDataTransaksiToken(T.ID_DETIL_TRANSAKSI, T.ID_TOKEN, T.ID_MEMBER, T.ID_PEGAWAI, T.TANGGAL_TRANSAKSI, T.TOTAL_PEMBAYARAN);
        }
    }
}
