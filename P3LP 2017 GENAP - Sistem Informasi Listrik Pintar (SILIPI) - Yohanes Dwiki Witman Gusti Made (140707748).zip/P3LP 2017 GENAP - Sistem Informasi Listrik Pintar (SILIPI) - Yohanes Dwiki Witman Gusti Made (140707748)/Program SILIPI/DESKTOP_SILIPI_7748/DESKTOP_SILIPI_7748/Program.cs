﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DESKTOP_SILIPI_7748.BOUNDARY;
using DESKTOP_SILIPI_7748.ENTITY;

namespace DESKTOP_SILIPI_7748
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new CetakKartuMemberUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new PembayaranTagihanPSBUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new CetakTagihanPSBUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new DashboardPetugasLoketUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new PembayaranTagihanPascabayarUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new PembelianTokenUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new StatusPSBUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new LaporanPSBPDLUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new CetakTagihanPDLUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new PembayaranTagihanPSBUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            //Application.Run(new PencatatanTagihanPascabayarUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
            Application.Run(new LoginUI());
            //Application.Run(new LaporanPSBPDLUI(new PegawaiEntity(10, 4, "Sri Indrawati", "PL-01")));
        } 
    }
}
