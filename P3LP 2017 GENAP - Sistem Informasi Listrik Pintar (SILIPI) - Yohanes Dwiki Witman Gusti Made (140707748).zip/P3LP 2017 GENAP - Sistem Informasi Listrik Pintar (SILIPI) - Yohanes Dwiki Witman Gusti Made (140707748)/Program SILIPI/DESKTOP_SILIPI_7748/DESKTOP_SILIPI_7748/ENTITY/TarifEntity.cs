﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TarifEntity
    {
        public int ID_TARIF, BEBAN, BIAYA_UJL, BIAYA_SAMBUNG, IS_TARIF_PSB, BIAYA_BEBAN, BIAYA_PEMAKAIAN, IS_TARIF_PASCABAYAR;
        public string KATEGORI_TARIF;

        public TarifEntity(int ID_TARIF, string KATEGORI_TARIF, int BEBAN, int BIAYA_UJL, int BIAYA_SAMBUNG, int IS_TARIF_PSB, int BIAYA_BEBAN, int BIAYA_PEMAKAIAN, int IS_TARIF_PASCABAYAR)
        {
            this.ID_TARIF = ID_TARIF;
            this.KATEGORI_TARIF = KATEGORI_TARIF;
            this.BEBAN = BEBAN;
            this.BIAYA_UJL = BIAYA_UJL;
            this.BIAYA_SAMBUNG = BIAYA_SAMBUNG;
            this.IS_TARIF_PSB = IS_TARIF_PSB;
            this.BIAYA_BEBAN = BIAYA_BEBAN;
            this.BIAYA_PEMAKAIAN = BIAYA_PEMAKAIAN;
            this.IS_TARIF_PASCABAYAR = IS_TARIF_PASCABAYAR;
        }

        public TarifEntity(string KATEGORI_TARIF, int BEBAN, int BIAYA_UJL, int BIAYA_SAMBUNG, int IS_TARIF_PSB, int BIAYA_BEBAN, int BIAYA_PEMAKAIAN, int IS_TARIF_PASCABAYAR)
        {
            this.KATEGORI_TARIF = KATEGORI_TARIF;
            this.BEBAN = BEBAN;
            this.BIAYA_UJL = BIAYA_UJL;
            this.BIAYA_SAMBUNG = BIAYA_SAMBUNG;
            this.IS_TARIF_PSB = IS_TARIF_PSB;
            this.BIAYA_BEBAN = BIAYA_BEBAN;
            this.BIAYA_PEMAKAIAN = BIAYA_PEMAKAIAN;
            this.IS_TARIF_PASCABAYAR = IS_TARIF_PASCABAYAR;
        }
    }
}
