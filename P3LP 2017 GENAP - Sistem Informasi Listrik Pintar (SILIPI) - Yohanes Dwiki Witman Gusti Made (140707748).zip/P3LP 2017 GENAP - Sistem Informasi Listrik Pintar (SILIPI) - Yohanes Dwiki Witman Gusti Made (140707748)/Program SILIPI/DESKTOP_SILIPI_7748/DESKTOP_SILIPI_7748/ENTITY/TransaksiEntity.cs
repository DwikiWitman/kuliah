﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TransaksiEntity
    {
        public int ID_TRANSAKSI, ID_DETIL_TRANSAKSI, ID_TAGIHAN_PERMOHONAN, ID_TAGIHAN_PASCABAYAR, ID_TOKEN, ID_MEMBER, ID_PEGAWAI;
        public DateTime TANGGAL_TRANSAKSI;
        public decimal TOTAL_PEMBAYARAN;

        public TransaksiEntity(int ID_TRANSAKSI, int ID_DETIL_TRANSAKSI, int ID_TAGIHAN_PERMOHONAN, int ID_TAGIHAN_PASCABAYAR, int ID_TOKEN, int ID_MEMBER, int ID_PEGAWAI, DateTime TANGGAL_TRANSAKSI, decimal TOTAL_PEMBAYARAN)
        {
            this.ID_TRANSAKSI = ID_TRANSAKSI;
            this.ID_DETIL_TRANSAKSI = ID_DETIL_TRANSAKSI;
            this.ID_TAGIHAN_PERMOHONAN = ID_TAGIHAN_PERMOHONAN;
            this.ID_TAGIHAN_PASCABAYAR = ID_TAGIHAN_PASCABAYAR;
            this.ID_TOKEN = ID_TOKEN;
            this.ID_MEMBER = ID_MEMBER;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.TANGGAL_TRANSAKSI = TANGGAL_TRANSAKSI;
            this.TOTAL_PEMBAYARAN = TOTAL_PEMBAYARAN;
        }

        public TransaksiEntity(int ID_DETIL_TRANSAKSI, int ID_TAGIHAN_PERMOHONAN, int ID_TAGIHAN_PASCABAYAR, int ID_TOKEN, int ID_MEMBER, int ID_PEGAWAI, DateTime TANGGAL_TRANSAKSI, decimal TOTAL_PEMBAYARAN)
        {
            this.ID_DETIL_TRANSAKSI = ID_DETIL_TRANSAKSI;
            this.ID_TAGIHAN_PERMOHONAN = ID_TAGIHAN_PERMOHONAN;
            this.ID_TAGIHAN_PASCABAYAR = ID_TAGIHAN_PASCABAYAR;
            this.ID_TOKEN = ID_TOKEN;
            this.ID_MEMBER = ID_MEMBER;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.TANGGAL_TRANSAKSI = TANGGAL_TRANSAKSI;
            this.TOTAL_PEMBAYARAN = TOTAL_PEMBAYARAN;
        }

        public TransaksiEntity(int ID_TAGIHAN_PSB, int ID_PEGAWAI, DateTime TANGGAL_TRANSAKSI, decimal TOTAL_PEMBAYARAN)
        {
            this.ID_TAGIHAN_PERMOHONAN = ID_TAGIHAN_PSB;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.TANGGAL_TRANSAKSI = TANGGAL_TRANSAKSI;
            this.TOTAL_PEMBAYARAN = TOTAL_PEMBAYARAN;
        }

        public TransaksiEntity(int ID_TAGIHAN_PASCABAYAR_ATAU_ID_TOKEN, int ID_MEMBER, int ID_PEGAWAI, DateTime TANGGAL_TRANSAKSI, decimal TOTAL_PEMBAYARAN)
        {
            this.ID_TAGIHAN_PASCABAYAR = ID_TAGIHAN_PASCABAYAR_ATAU_ID_TOKEN;  //pascabayar
            this.ID_TOKEN = ID_TAGIHAN_PASCABAYAR_ATAU_ID_TOKEN; //prabayar
            this.ID_MEMBER = ID_MEMBER;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.TANGGAL_TRANSAKSI = TANGGAL_TRANSAKSI;
            this.TOTAL_PEMBAYARAN = TOTAL_PEMBAYARAN;
        }
        
    }
}
