﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    public class GlobalEntity
    {
        public static string deskripsiPermohonan_1 = "Permohonan belum diverifikasi untuk disetujui atau ditolak.";
        public static string deskripsiPermohonan_2 = "Permohonan telah diterima karena daya listrik di lokasi pemohon mencukupi.";
        public static string deskripsiPermohonan_3 = "Permohonan telah ditolak karena daya listrik di lokasi pemohon tidak mencukupi.";
        public static string deskripsiPermohonan_4 = "Telah resmi menjadi anggota Listrik Pintar.";
        public static string deskripsiTagihan_1 = "Tagihan belum dibayar.";
        public static string deskripsiTagihan_2 = "Tagihan sudah dibayar.";
        public static string deskripsiStatusPemasangan_1 = "Active.";
        public static string deskripsiStatusPemasangan_2 = "Not Active.";
        public static string channelPembayaran_1 = "Petugas Loket.";
        public static string channelPembayaran_2 = "Bank.";
        public static string channelPembayaran_3 = "ATM.";

        //yang kurang
        /*
         *  cetak struk pembayaran pasang baru
         *  kwh terakir tdk boleh kurang dari kwh tercatat sebelumnya
         *  yang menentukan active/inactive si manager
         *  verifikasi oleh manager, tampil dataview diverifikasi otomatis
         *  error deskripsi permohonan (kepotong varchar 50 padahal 100)
         *  cek id kode area: otomatis verifikasi, update trafo, cek ketersedianan trafo
         *  tanggal transaksi ada jam nya, jgn 00:00
         *  nomor resi, nomor pelanggan, nomor kwh, identitas ktp tidak boleh sama
         *  nomor kwh biasanya berdasarkan regional (unik)
         *  di tabel token terdapat id_member, gunanya agar token tdk bisa dipakai oleh org lain.
         *  pl sql entry data member error (jgn coding di sql server)
         *  cetak tagihan psb hanya bisa 1x, report juga tampilkan tanggal hari tagihan dibuat.
         *  pembayaran tagihan psb form uc nya masih disable.   
         *  kalau datagridview diklik usahakan nomor pelanggan atau nomor lainnya terlihat di label agar user tahu yg mana diklik.
         *  binding navigator semuanya diperbaiki.
         *  
         * 
         * 
         * pr
         * -entry data pemakaian listrik pascabayar pelanggan bulanan
         * -melihat detail psb dan pdl dari seluruh pelanggan
         * - minggu depan web (display tarif, display tagihan dsb).
         */
    }
}
