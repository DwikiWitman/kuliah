﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class MemberEntity
    {
        public string NOMOR_KTP, NOMOR_MEMBER, NOMOR_KWH, NAMA_MEMBER, ALAMAT_INSTALASI, NOMOR_HP_MEMBER, PEKERJAAN, TIPE_MEMBER, STATUS;
        public DateTime TANGGAL_LAHIR_MEMBER;
        public int ID_MEMBER, DAYA_LISTRIK;

        public MemberEntity(int ID_MEMBER, string NOMOR_KTP, string NOMOR_MEMBER, string NOMOR_KWH, string NAMA_MEMBER, DateTime TANGGAL_LAHIR_MEMBER, string ALAMAT_INSTALASI, string NOMOR_HP_MEMBER, string PEKERJAAN, int DAYA_LISTRIK, string TIPE_MEMBER, string STATUS)
        {
            this.ID_MEMBER = ID_MEMBER;
            this.NOMOR_KTP = NOMOR_KTP;
            this.NOMOR_MEMBER = NOMOR_MEMBER;
            this.NOMOR_KWH = NOMOR_KWH;
            this.NAMA_MEMBER = NAMA_MEMBER;
            this.ALAMAT_INSTALASI = ALAMAT_INSTALASI;
            this.NOMOR_HP_MEMBER = NOMOR_HP_MEMBER;
            this.PEKERJAAN = PEKERJAAN;
            this.TIPE_MEMBER = TIPE_MEMBER;
            this.TANGGAL_LAHIR_MEMBER = TANGGAL_LAHIR_MEMBER;
            this.DAYA_LISTRIK = DAYA_LISTRIK;
            this.STATUS = STATUS;
        }

        public MemberEntity(string NOMOR_KTP, string NOMOR_MEMBER, string NOMOR_KWH, string NAMA_MEMBER, DateTime TANGGAL_LAHIR_MEMBER, string ALAMAT_INSTALASI, string NOMOR_HP_MEMBER, string PEKERJAAN, int DAYA_LISTRIK, string TIPE_MEMBER, string STATUS)
        {
            this.NOMOR_KTP = NOMOR_KTP;
            this.NOMOR_MEMBER = NOMOR_MEMBER;
            this.NOMOR_KWH = NOMOR_KWH;
            this.NAMA_MEMBER = NAMA_MEMBER;
            this.ALAMAT_INSTALASI = ALAMAT_INSTALASI;
            this.NOMOR_HP_MEMBER = NOMOR_HP_MEMBER;
            this.PEKERJAAN = PEKERJAAN;
            this.TIPE_MEMBER = TIPE_MEMBER;
            this.TANGGAL_LAHIR_MEMBER = TANGGAL_LAHIR_MEMBER;
            this.DAYA_LISTRIK = DAYA_LISTRIK;
            this.STATUS = STATUS;
        }

    }
}
