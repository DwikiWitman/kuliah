﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    public class PegawaiEntity
    {
        public int ID_PEGAWAI, ID_JABATAN;
        public DateTime TANGGAL_LAHIR_PEGAWAI;
        public string NAMA_PEGAWAI, ALAMAT_PEGAWAI, NOMOR_HP_PEGAWAI,
            USERNAME_PEGAWAI, PASSWORD_PEGAWAI;


        public PegawaiEntity(int ID_PEGAWAI, int ID_JABATAN, string NAMA_PEGAWAI,
            DateTime TANGGAL_LAHIR_PEGAWAI, string ALAMAT_PEGAWAI, string NOMOR_HP_PEGAWAI,
            string USERNAME_PEGAWAI, string PASSWORD_PEGAWAI)
        {
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.ID_JABATAN = ID_JABATAN;
            this.NAMA_PEGAWAI = NAMA_PEGAWAI;
            this.TANGGAL_LAHIR_PEGAWAI = TANGGAL_LAHIR_PEGAWAI;
            this.ALAMAT_PEGAWAI = ALAMAT_PEGAWAI;
            this.NOMOR_HP_PEGAWAI = NOMOR_HP_PEGAWAI;
            this.USERNAME_PEGAWAI = USERNAME_PEGAWAI;
            this.PASSWORD_PEGAWAI = PASSWORD_PEGAWAI;
        }

        public PegawaiEntity(int ID_JABATAN, string NAMA_PEGAWAI,
            DateTime TANGGAL_LAHIR_PEGAWAI, string ALAMAT_PEGAWAI, string NOMOR_HP_PEGAWAI,
            string USERNAME_PEGAWAI, string PASSWORD_PEGAWAI)
        {
            this.ID_JABATAN = ID_JABATAN;
            this.NAMA_PEGAWAI = NAMA_PEGAWAI;
            this.TANGGAL_LAHIR_PEGAWAI = TANGGAL_LAHIR_PEGAWAI;
            this.ALAMAT_PEGAWAI = ALAMAT_PEGAWAI;
            this.NOMOR_HP_PEGAWAI = NOMOR_HP_PEGAWAI;
            this.USERNAME_PEGAWAI = USERNAME_PEGAWAI;
            this.PASSWORD_PEGAWAI = PASSWORD_PEGAWAI;
        }

        public PegawaiEntity(int ID_PEGAWAI, int ID_JABATAN, string NAMA_PEGAWAI, string USERNAME_PEGAWAI)
        {
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.ID_JABATAN = ID_JABATAN;
            this.NAMA_PEGAWAI = NAMA_PEGAWAI;
            this.USERNAME_PEGAWAI = USERNAME_PEGAWAI;
        }

        public PegawaiEntity(){}
    }
}
