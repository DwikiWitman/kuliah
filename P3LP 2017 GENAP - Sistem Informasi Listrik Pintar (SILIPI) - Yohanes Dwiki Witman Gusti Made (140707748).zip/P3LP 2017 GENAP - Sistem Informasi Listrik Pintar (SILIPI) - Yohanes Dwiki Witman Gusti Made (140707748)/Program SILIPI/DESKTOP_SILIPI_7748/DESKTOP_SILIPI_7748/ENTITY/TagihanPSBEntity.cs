﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    public class TagihanPSBEntity
    {
        public int ID_TAGIHAN_PERMOHONAN, ID_PERMOHONAN, ID_PEGAWAI, ID_TARIF;
        public decimal TOTAL_TAGIHAN_PERMOHONAN;
        public string STATUS_TAGIHAN_PERMOHOHAN;
        public DateTime TANGGAL_TAGIHAN_PERMOHONAN;

        public TagihanPSBEntity(int ID_TAGIHAN_PERMOHONAN, int ID_PERMOHONAN, int ID_PEGAWAI, int ID_TARIF, decimal TOTAL_TAGIHAN_PERMOHONAN, string STATUS_TAGIHAN_PERMOHOHAN, DateTime TANGGAL_TAGIHAN_PERMOHONAN)
        {
            this.ID_TAGIHAN_PERMOHONAN = ID_TAGIHAN_PERMOHONAN;
            this.ID_PERMOHONAN = ID_PERMOHONAN;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.ID_TARIF = ID_TARIF;
            this.TOTAL_TAGIHAN_PERMOHONAN = TOTAL_TAGIHAN_PERMOHONAN;
            this.STATUS_TAGIHAN_PERMOHOHAN = STATUS_TAGIHAN_PERMOHOHAN;
            this.TANGGAL_TAGIHAN_PERMOHONAN = TANGGAL_TAGIHAN_PERMOHONAN;
        }

        public TagihanPSBEntity(int ID_PERMOHONAN, int ID_PEGAWAI, int ID_TARIF, decimal TOTAL_TAGIHAN_PERMOHONAN, string STATUS_TAGIHAN_PERMOHOHAN, DateTime TANGGAL_TAGIHAN_PERMOHONAN)
        {
            this.ID_PERMOHONAN = ID_PERMOHONAN;
            this.ID_PEGAWAI = ID_PEGAWAI;
            this.ID_TARIF = ID_TARIF;
            this.TOTAL_TAGIHAN_PERMOHONAN = TOTAL_TAGIHAN_PERMOHONAN;
            this.STATUS_TAGIHAN_PERMOHOHAN = STATUS_TAGIHAN_PERMOHOHAN;
            this.TANGGAL_TAGIHAN_PERMOHONAN = TANGGAL_TAGIHAN_PERMOHONAN;
        }

    }
}
