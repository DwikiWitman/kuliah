﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TagihanPascabayarEntity
    {
        public int ID_TAGIHAN_PASCABAYAR, ID_MEMBER, ID_TARIF, KWH_SEBELUM, KWH_SESUDAH, TAHUN_TAGIHAN;
        public decimal TOTAL_TAGIHAN_PASCABAYAR;
        public string BULAN_TAGIHAN, STATUS_TAGIHAN_PASCABAYAR;

        public TagihanPascabayarEntity(int ID_TAGIHAN_PASCABAYAR, int ID_MEMBER, int ID_TARIF, int KWH_SEBELUM,
            int KWH_SESUDAH, string BULAN_TAGIHAN, int TAHUN_TAGIHAN, decimal TOTAL_TAGIHAN_PASCABAYAR, string STATUS_TAGIHAN_PASCABAYAR)
        {
            this.ID_TAGIHAN_PASCABAYAR = ID_TAGIHAN_PASCABAYAR;
            this.ID_MEMBER = ID_MEMBER;
            this.ID_TARIF = ID_TARIF;
            this.KWH_SEBELUM = KWH_SEBELUM;
            this.KWH_SESUDAH = KWH_SESUDAH; 
            this.BULAN_TAGIHAN = BULAN_TAGIHAN;
            this.TAHUN_TAGIHAN = TAHUN_TAGIHAN;
            this.TOTAL_TAGIHAN_PASCABAYAR = TOTAL_TAGIHAN_PASCABAYAR;
            this.STATUS_TAGIHAN_PASCABAYAR = STATUS_TAGIHAN_PASCABAYAR;
        }

        public TagihanPascabayarEntity(int ID_MEMBER, int ID_TARIF, int KWH_SEBELUM,
            int KWH_SESUDAH, string BULAN_TAGIHAN, int TAHUN_TAGIHAN, decimal TOTAL_TAGIHAN_PASCABAYAR, string STATUS_TAGIHAN_PASCABAYAR)
        {
            this.ID_MEMBER = ID_MEMBER;
            this.ID_TARIF = ID_TARIF;
            this.KWH_SEBELUM = KWH_SEBELUM;
            this.KWH_SESUDAH = KWH_SESUDAH;
            this.BULAN_TAGIHAN = BULAN_TAGIHAN;
            this.TAHUN_TAGIHAN = TAHUN_TAGIHAN;
            this.TOTAL_TAGIHAN_PASCABAYAR = TOTAL_TAGIHAN_PASCABAYAR;
            this.STATUS_TAGIHAN_PASCABAYAR = STATUS_TAGIHAN_PASCABAYAR;
        }
    }
}
