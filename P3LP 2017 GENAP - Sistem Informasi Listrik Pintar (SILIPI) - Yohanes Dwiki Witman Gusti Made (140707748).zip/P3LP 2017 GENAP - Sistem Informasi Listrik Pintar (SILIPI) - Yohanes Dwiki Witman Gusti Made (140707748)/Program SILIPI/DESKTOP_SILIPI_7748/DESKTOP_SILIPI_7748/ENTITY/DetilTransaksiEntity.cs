﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class DetilTransaksiEntity
    {
        public int ID_DETIL_TRANSAKSI, JUMLAH_TOKEN;
        public string JENIS_TAGIHAN, CHANNEL_PEMBAYARAN;

        public DetilTransaksiEntity(int ID_DETIL_TRANSAKSI, string JENIS_TAGIHAN, string CHANNEL_PEMBAYARAN, int JUMLAH_TOKEN)
        {
            this.ID_DETIL_TRANSAKSI = ID_DETIL_TRANSAKSI;
            this.JENIS_TAGIHAN = JENIS_TAGIHAN;
            this.CHANNEL_PEMBAYARAN = CHANNEL_PEMBAYARAN;
            this.JUMLAH_TOKEN = JUMLAH_TOKEN;
        }

        public DetilTransaksiEntity(string JENIS_TAGIHAN, string CHANNEL_PEMBAYARAN, int JUMLAH_TOKEN)
        {
            this.JENIS_TAGIHAN = JENIS_TAGIHAN;
            this.CHANNEL_PEMBAYARAN = CHANNEL_PEMBAYARAN;
            this.JUMLAH_TOKEN = JUMLAH_TOKEN;
        }

        public DetilTransaksiEntity(string JENIS_TAGIHAN, string CHANNEL_PEMBAYARAN)
        {
            this.JENIS_TAGIHAN = JENIS_TAGIHAN;
            this.CHANNEL_PEMBAYARAN = CHANNEL_PEMBAYARAN;
        }
    }
}
