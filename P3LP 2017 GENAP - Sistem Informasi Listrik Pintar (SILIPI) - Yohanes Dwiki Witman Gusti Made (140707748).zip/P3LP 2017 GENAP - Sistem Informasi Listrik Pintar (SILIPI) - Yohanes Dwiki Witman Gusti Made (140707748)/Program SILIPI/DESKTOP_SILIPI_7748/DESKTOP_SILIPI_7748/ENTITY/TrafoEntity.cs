﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TrafoEntity
    {
        public int ID_TRAFO, KAPASITAS_DAYA_TOTAL, KAPASITAS_DAYA_TERPAKAI;
        public TrafoEntity(int ID_TRAFO, int KAPASITAS_DAYA_TOTAL, int KAPASITAS_DAYA_TERPAKAI)
        {
            this.ID_TRAFO = ID_TRAFO;
            this.KAPASITAS_DAYA_TERPAKAI = KAPASITAS_DAYA_TERPAKAI;
            this.KAPASITAS_DAYA_TOTAL = KAPASITAS_DAYA_TOTAL;
        }

        public TrafoEntity(int KAPASITAS_DAYA_TOTAL, int KAPASITAS_DAYA_TERPAKAI)
        {
            this.KAPASITAS_DAYA_TERPAKAI = KAPASITAS_DAYA_TERPAKAI;
            this.KAPASITAS_DAYA_TOTAL = KAPASITAS_DAYA_TOTAL;
        }
    }
}
