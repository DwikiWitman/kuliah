﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TambahDayaEntity
    {
        public int ID_PERMOHONAN_TAMBAH_DAYA, DAYA_LISTRIK_BARU;
        public string NOMOR_MEMBER;

        public TambahDayaEntity(int ID_PERMOHONAN_TAMBAH_DAYA, string NOMOR_MEMBER, int DAYA_LISTRIK_BARU)
        {
            this.ID_PERMOHONAN_TAMBAH_DAYA = ID_PERMOHONAN_TAMBAH_DAYA;
            this.NOMOR_MEMBER = NOMOR_MEMBER;
            this.DAYA_LISTRIK_BARU = DAYA_LISTRIK_BARU;
        }

        public TambahDayaEntity(string NOMOR_MEMBER, int DAYA_LISTRIK_BARU)
        {
            this.NOMOR_MEMBER = NOMOR_MEMBER;
            this.DAYA_LISTRIK_BARU = DAYA_LISTRIK_BARU;
        }
    }

}
