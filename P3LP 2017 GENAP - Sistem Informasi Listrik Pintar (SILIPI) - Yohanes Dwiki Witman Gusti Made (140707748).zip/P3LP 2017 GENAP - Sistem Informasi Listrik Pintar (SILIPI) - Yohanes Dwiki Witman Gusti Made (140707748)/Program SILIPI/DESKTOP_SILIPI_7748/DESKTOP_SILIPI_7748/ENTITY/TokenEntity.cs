﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DESKTOP_SILIPI_7748.ENTITY
{
    class TokenEntity
    {
        public int ID_TOKEN, NOMINAL_TOKEN;
        public decimal HARGA_TOKEN;
        public string NOMOR_TOKEN;

        public TokenEntity(int ID_TOKEN, string NOMOR_TOKEN, int NOMINAL_TOKEN, decimal HARGA_TOKEN)
        {
            this.ID_TOKEN = ID_TOKEN;
            this.NOMOR_TOKEN = NOMOR_TOKEN;
            this.NOMINAL_TOKEN = NOMINAL_TOKEN;
            this.HARGA_TOKEN = HARGA_TOKEN;
        }

        public TokenEntity(string NOMOR_TOKEN, int NOMINAL_TOKEN, decimal HARGA_TOKEN)
        {
            this.NOMOR_TOKEN = NOMOR_TOKEN;
            this.NOMINAL_TOKEN = NOMINAL_TOKEN;
            this.HARGA_TOKEN = HARGA_TOKEN;
        }
    }
}
