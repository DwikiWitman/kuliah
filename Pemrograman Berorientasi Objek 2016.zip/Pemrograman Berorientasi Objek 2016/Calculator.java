/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junitsample;

/**
 *
 * @author YULIUS
 */
public class Calculator {

    private double vA;
    private double vB;

    public Calculator() {

    }

    public Calculator(double _vA, double _vB) {
        this.vA = _vA;
        this.vB = _vB;
    }
    
    public void setVariableA(double _vA){
        this.vA = _vA;
    }
    
    public void setVariableB(double _vB){
        this.vB = _vB;
    }
    
    public double getVariableA(){
        return vA;
    }
    
    public double getVariableB(){
        return vA;
    }

    public double penjumlahan() {
        return vA + vB;
    }
    
    public double pengurangan() {
        return vA - vB;
    }
    public double perkalian() {
        return vA * vB;
    }
    public double pembagian() {
        return vA / vB;
    }

}
